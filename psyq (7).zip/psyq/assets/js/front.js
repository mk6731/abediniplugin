/**
 * اسکریپت سمت کاربر PsyQ — مدیریت پرسشنامه و کارنامه
 */
(function () {
	'use strict';

	var charts = [];

	/* ======================================================
	 * نمودارها
	 * ====================================================== */
	function initCharts(root) {
		root = root || document;
		if (typeof window.Chart === 'undefined') { return; }

		root.querySelectorAll('canvas[data-chart]').forEach(function (cv) {
			if (cv.dataset.done) { return; }
			cv.dataset.done = '1';
			var data;
			try { data = JSON.parse(cv.getAttribute('data-chart')); } catch (e) { return; }
			if (!data) { return; }

			var isHist = data.counts !== undefined;
			var cfg = {
				type: 'bar',
				data: {
					labels: data.labels,
					datasets: isHist
						? [{
							label: data.label || 'تعداد',
							data: data.counts,
							backgroundColor: 'rgba(99,102,241,.85)',
							borderRadius: 6,
							borderColor: '#4338ca',
							borderWidth: 1
						}]
						: [{
							label: 'نمره',
							data: data.scores,
							backgroundColor: data.colors.map(function (c) { return c + 'cc'; }),
							borderColor: data.colors,
							borderWidth: 1.5,
							borderRadius: 6
						}, {
							label: 'بیشینه ممکن',
							data: data.maxes,
							backgroundColor: 'rgba(226,232,240,.55)',
							borderColor: '#cbd5e1',
							borderWidth: 1,
							borderRadius: 6
						}]
				},
				options: {
					responsive: true,
					maintainAspectRatio: false,
					indexAxis: isHist ? 'x' : 'y',
					plugins: {
						legend: { display: !isHist, position: 'bottom', labels: { font: { family: 'Tahoma' }, boxWidth: 12 } },
						tooltip: {
							rtl: true,
							textDirection: 'rtl',
							callbacks: {
								label: function (ctx) {
									var lvl = (data.levels && data.levels[ctx.dataIndex]) ? ' — ' + data.levels[ctx.dataIndex] : '';
									return ctx.dataset.label + ': ' + ctx.formattedValue + lvl;
								}
							}
						}
					},
					scales: {
						x: {
							beginAtZero: true,
							grid: { color: '#f1f5f9' },
							ticks: { font: { family: 'Tahoma' } },
							reverse: !isHist
						},
						y: {
							beginAtZero: true,
							grid: { color: '#f1f5f9' },
							ticks: { font: { family: 'Tahoma' }, precision: 0 },
							reverse: isHist
						}
					}
				}
			};
			try { charts.push(new window.Chart(cv.getContext('2d'), cfg)); } catch (e) { /* silent */ }
		});
	}

	/* ======================================================
	 * راه‌اندازی پرسشنامه
	 * ====================================================== */
	function initApp(app) {
		var state;
		try { state = JSON.parse(app.getAttribute('data-state')); } catch (e) { return; }
		if (!state) { return; }

		var screens = app.querySelectorAll('.psyq-screen');
		var pages = app.querySelectorAll('.psyq-page');
		var answers = {};
		var current = 0;
		var startTime = Date.now();
		var timerId = null;
		var profile = {};

		function showScreen(name) {
			screens.forEach(function (s) {
				s.classList.toggle('is-active', s.getAttribute('data-screen') === name);
			});
			window.scrollTo({ top: app.offsetTop - 20, behavior: 'smooth' });
		}

		function showPage(idx) {
			current = Math.max(0, Math.min(pages.length - 1, idx));
			pages.forEach(function (p, i) { p.classList.toggle('is-active', i === current); });
			app.querySelector('.psyq-prev').hidden = (current === 0) || !state.allowBack;
			app.querySelector('.psyq-next').hidden = current >= pages.length - 1;
			app.querySelector('.psyq-submit').hidden = current < pages.length - 1;
			var info = app.querySelector('.psyq-pageinfo');
			if (info) { info.textContent = 'صفحه ' + (current + 1) + ' از ' + pages.length; }
			applyConditions();
			updateProgress();
			window.scrollTo({ top: app.offsetTop - 20, behavior: 'smooth' });
		}

		function totalVisible() {
			var n = 0;
			app.querySelectorAll('.psyq-q').forEach(function (q) { if (!q.hidden) { n++; } });
			return n;
		}

		function updateProgress() {
			var visible = 0, answered = 0;
			app.querySelectorAll('.psyq-q').forEach(function (q) {
				if (q.hidden) { return; }
				visible++;
				if (q.classList.contains('is-answered')) { answered++; }
			});
			var pct = visible ? Math.round(answered / visible * 100) : 0;
			var bar = app.querySelector('.psyq-progress__bar');
			if (bar) { bar.style.width = pct + '%'; }
			var counter = app.querySelector('.psyq-counter');
			if (counter) { counter.textContent = answered + ' / ' + visible; }
		}

		/* -------------- شرط نمایش سوالات -------------- */
		function applyConditions() {
			app.querySelectorAll('.psyq-q[data-cond-item]').forEach(function (q) {
				var refNum = q.getAttribute('data-cond-item');
				var op = q.getAttribute('data-cond-op');
				var val = q.getAttribute('data-cond-val');
				var refQ = app.querySelector('.psyq-q[data-number="' + refNum + '"][data-answer-type="choice"]') || app.querySelector('.psyq-q[data-number="' + refNum + '"]');
				var shown = false;
				if (refQ) {
					var checked = refQ.querySelector('input[type=radio]:checked');
					if (checked) {
						var label = checked.closest('.psyq-opt').querySelector('.psyq-opt__label');
						var text = label ? label.textContent.trim() : '';
						if (op === '=') { shown = (text === val); }
						else if (op === '!=') { shown = (text !== val); }
						else { shown = true; }
					}
				}
				q.hidden = !shown;
				if (!shown) {
					q.querySelectorAll('input[type=radio]').forEach(function (r) { r.checked = false; });
					q.querySelectorAll('textarea.psyq-text-answer').forEach(function (t) { t.value = ''; });
					delete answers[q.getAttribute('data-item-id')];
					q.classList.remove('is-answered');
				}
			});
		}

		/* -------------- پاسخ‌دهی -------------- */
		function markAnswered(q, value) {
			if (!q) { return; }
			var id = q.getAttribute('data-item-id');
			if (String(value || '').trim()) {
				answers[id] = value;
				q.classList.add('is-answered');
				q.classList.remove('is-missing');
			} else {
				delete answers[id];
				q.classList.remove('is-answered');
			}
			updateProgress();
		}
		app.addEventListener('change', function (e) {
			if (e.target.type !== 'radio') { return; }
			var q = e.target.closest('.psyq-q');
			markAnswered(q, e.target.value);
			applyConditions();
		});
		app.addEventListener('input', function (e) {
			if (!e.target.classList || !e.target.classList.contains('psyq-text-answer')) { return; }
			markAnswered(e.target.closest('.psyq-q'), e.target.value);
		});

		/* -------------- دکمه‌ها -------------- */
		var consent = app.querySelector('.psyq-consent-check');
		var startBtn = app.querySelector('.psyq-start');
		if (consent && startBtn) {
			consent.addEventListener('change', function () { startBtn.disabled = !consent.checked; });
		}

		if (startBtn) {
			startBtn.addEventListener('click', function () {
				if (state.collectName || state.demographics) { showScreen('profile'); }
				else { beginQuiz(); }
			});
		}

		var backIntro = app.querySelector('.psyq-back-intro');
		if (backIntro) { backIntro.addEventListener('click', function () { showScreen('intro'); }); }

		var profileNext = app.querySelector('.psyq-profile-next');
		if (profileNext) {
			profileNext.addEventListener('click', function () {
				app.querySelectorAll('[data-field]').forEach(function (f) {
					profile[f.getAttribute('data-field')] = f.value.trim();
				});
				var skip = app.querySelector('.psyq-skip-profile input');
				if (skip && skip.checked) { profile = {}; }
				beginQuiz();
			});
		}

		function beginQuiz() {
			startTime = Date.now();
			showScreen('quiz');
			applyConditions();
			showPage(0);
			if (state.duration > 0) {
				var el = app.querySelector('.psyq-timer');
				el.hidden = false;
				var end = Date.now() + state.duration * 60000;
				timerId = setInterval(function () {
					var left = Math.max(0, end - Date.now());
					var m = Math.floor(left / 60000);
					var s = Math.floor((left % 60000) / 1000);
					el.textContent = '⏱ ' + m + ':' + (s < 10 ? '0' : '') + s;
					if (left <= 0) { clearInterval(timerId); submit(); }
				}, 1000);
			}
		}

		var prevBtn = app.querySelector('.psyq-prev');
		if (prevBtn) { prevBtn.addEventListener('click', function () { showPage(current - 1); }); }

		var nextBtn = app.querySelector('.psyq-next');
		if (nextBtn) {
			nextBtn.addEventListener('click', function () {
				if (!validatePage()) { return; }
				showPage(current + 1);
			});
		}

		function validatePage() {
			var missing = 0;
			pages[current].querySelectorAll('.psyq-q').forEach(function (q) {
				if (q.hidden) { return; }
				if (q.getAttribute('data-required') !== '1') { return; }
				if (!q.classList.contains('is-answered')) {
					q.classList.add('is-missing');
					missing++;
				}
			});
			var alertBox = app.querySelector('.psyq-alert');
			if (missing > 0) {
				alertBox.hidden = false;
				alertBox.textContent = missing + ' سوال بدون پاسخ مانده است. لطفاً همه سوالات این صفحه را پاسخ دهید.';
				var first = pages[current].querySelector('.psyq-q.is-missing');
				if (first) { first.scrollIntoView({ behavior: 'smooth', block: 'center' }); }
				return false;
			}
			alertBox.hidden = true;
			return true;
		}

		var submitBtn = app.querySelector('.psyq-submit');
		if (submitBtn) { submitBtn.addEventListener('click', function () { if (validatePage()) { submit(); } }); }

		/* -------------- ارسال -------------- */
		function submit() {
			if (timerId) { clearInterval(timerId); }
			showScreen('result');
			var loading = app.querySelector('.psyq-loading');
			var resultBox = app.querySelector('.psyq-result');
			loading.hidden = false;
			resultBox.innerHTML = '';

			var body = new URLSearchParams();
			body.append('action', 'psyq_submit');
			body.append('nonce', state.nonce);
			body.append('form_id', state.formId);
			body.append('answers', JSON.stringify(answers));
			body.append('duration', Math.round((Date.now() - startTime) / 1000));
			Object.keys(profile).forEach(function (k) { body.append(k, profile[k]); });

			fetch(state.ajaxUrl, {
				method: 'POST',
				credentials: 'same-origin',
				headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
				body: body.toString()
			}).then(function (r) { return r.json(); }).then(function (res) {
				loading.hidden = true;
				if (!res || !res.success) {
					resultBox.innerHTML = '<div class="psyq-error">' + ((res && res.data && res.data.message) || 'خطا در ثبت پاسخ‌ها. لطفاً دوباره تلاش کنید.') + '</div>';
					return;
				}
				resultBox.innerHTML = res.data.html;
				app.querySelector('.psyq-result-actions').hidden = false;
				var link = app.querySelector('.psyq-report-link');
				if (res.data.link && link) { link.href = res.data.link; link.hidden = false; }
				initCharts(resultBox);
				window.scrollTo({ top: app.offsetTop - 20, behavior: 'smooth' });
			}).catch(function () {
				loading.hidden = true;
				resultBox.innerHTML = '<div class="psyq-error">ارتباط با سرور برقرار نشد. لطفاً اتصال اینترنت را بررسی کنید.</div>';
			});
		}

		/* -------------- چاپ و نمودار -------------- */
		app.addEventListener('click', function (e) {
			var t = e.target;
			if (t.classList.contains('psyq-print')) { window.print(); }
			var toggle = t.closest && t.closest('.psyq-chart-toggle');
			if (toggle) {
				var box = toggle.closest('.psyq-chart');
				box.classList.toggle('is-live');
				if (box.classList.contains('is-live')) { initCharts(box); }
			}
		});

		initCharts(app);
	}

	/* ======================================================
	 * بازیابی کارنامه با توکن
	 * ====================================================== */
	function resume(app, token) {
		var state;
		try { state = JSON.parse(app.getAttribute('data-state')); } catch (e) { return; }
		var body = new URLSearchParams();
		body.append('action', 'psyq_resume');
		body.append('nonce', state.nonce);
		body.append('token', token);

		app.querySelectorAll('.psyq-screen').forEach(function (s) {
			s.classList.toggle('is-active', s.getAttribute('data-screen') === 'result');
		});
		var box = app.querySelector('.psyq-result');
		box.innerHTML = '<div class="psyq-loading"><div class="psyq-spinner"></div></div>';

		fetch(state.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
			body: body.toString()
		}).then(function (r) { return r.json(); }).then(function (res) {
			if (!res || !res.success) {
				box.innerHTML = '<div class="psyq-error">' + ((res && res.data && res.data.message) || 'کارنامه یافت نشد.') + '</div>';
				return;
			}
			box.innerHTML = res.data.html;
			initCharts(box);
		});
	}

	/* ======================================================
	 * راه‌اندازی
	 * ====================================================== */
	function boot() {
		document.querySelectorAll('.psyq-app').forEach(function (app) {
			if (app.getAttribute('data-psyq-ready')) { return; }
			app.setAttribute('data-psyq-ready', '1');
			if (app.querySelector('[data-screen="quiz"]')) { initApp(app); }
			else { initCharts(app); }
			// دکمه چاپ در صفحه گزارش دائمی
			app.querySelectorAll('.psyq-print').forEach(function (b) {
				b.addEventListener('click', function () { window.print(); });
			});
			app.querySelectorAll('.psyq-chart-toggle').forEach(function (t) {
				t.addEventListener('click', function () {
					var box = t.closest('.psyq-chart');
					box.classList.toggle('is-live');
					if (box.classList.contains('is-live')) { initCharts(box); }
				});
			});
		});
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', boot);
	} else {
		boot();
	}

	window.PsyQFront = { initCharts: initCharts, resume: resume, boot: boot };
})();
