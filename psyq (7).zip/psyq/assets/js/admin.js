/**
 * اسکریپت پنل مدیریت PsyQ
 */
(function ($) {
	'use strict';

	var ADMIN = window.PsyQAdmin || {};

	/* ==========================================================
	 * اعلان کوچک (Toast)
	 * ========================================================== */
	window.psyqToast = function (msg, type) {
		var $t = $('#psyq-toast');
		if (!$t.length) {
			$t = $('<div id="psyq-toast" class="psyq-toast"></div>').appendTo('body');
		}
		$t.removeClass('is-error is-ok').addClass(type === 'error' ? 'is-error' : 'is-ok').text(msg).addClass('is-show');
		clearTimeout(window.__psyqToastT);
		window.__psyqToastT = setTimeout(function () { $t.removeClass('is-show'); }, 2600);
	};

	/* ==========================================================
	 * کمکی‌ها
	 * ========================================================== */
	function post(action, data) {
		return $.post(
			ADMIN.ajaxUrl,
			$.extend({ action: 'psyq_' + action, nonce: ADMIN.nonce, form_id: ADMIN.formId }, data)
		);
	}

	function optRow(idx, data) {
		data = data || {};
		var label = data.label || '';
		var value = data.value !== undefined ? data.value : 0;
		var img = data.image_url || '';
		var $row = $('<div class="psyq-optrow">')
			.append('<span class="psyq-optrow__idx">' + (idx + 1) + '</span>')
			.append('<input type="text" class="opt-label" placeholder="متن گزینه" value="' + esc(label) + '">')
			.append('<input type="number" class="opt-value" step="0.5" min="-5" max="7" value="' + esc(value) + '" title="امتیاز این گزینه (۵- تا ۷)">')
			.append('<input type="text" class="opt-image" placeholder="آدرس تصویر گزینه" value="' + esc(img) + '">')
			.append('<button type="button" class="psyq-optrow__img" title="انتخاب تصویر از کتابخانه">🖼</button>')
			.append('<button type="button" class="psyq-optrow__del" title="حذف گزینه">×</button>');
		return $row;
	}

	function esc(s) {
		return String(s === undefined || s === null ? '' : s)
			.replace(/&/g, '&amp;')
			.replace(/</g, '&lt;')
			.replace(/>/g, '&gt;')
			.replace(/"/g, '&quot;');
	}

	function renumber($rows) {
		$rows.find('.psyq-optrow').each(function (i) {
			$(this).find('.psyq-optrow__idx').text(i + 1);
		});
	}

	function loadPreset($rows, count, values) {
		$rows.empty();
		var labels = (ADMIN.presets && ADMIN.presets[count]) || [];
		for (var i = 0; i < count; i++) {
			$rows.append(optRow(i, { label: labels[i] || 'گزینه ' + (i + 1), value: i }));
		}
	}

	function setAnswerType(type) {
		type = type === 'text' ? 'text' : 'choice';
		var isText = type === 'text';
		$('#psyq-item-answer-type').val(type);
		$('#psyq-opts-editor').prop('hidden', isText);
		$('#psyq-item-reversed').prop('disabled', isText);
		if (isText) { $('#psyq-item-reversed').prop('checked', false); }
	}

	/* ==========================================================
	 * کپی شورت‌کد
	 * ========================================================== */
	$(document).on('click', '.psyq-copy', function () {
		var text = $(this).text();
		if (navigator.clipboard) {
			navigator.clipboard.writeText(text);
		} else {
			var $t = $('<textarea>').val(text).appendTo('body').select();
			document.execCommand('copy');
			$t.remove();
		}
		$(this).attr('title', 'کپی شد!');
	});

	/* ==========================================================
	 * کادر «بیشتر»
	 * ========================================================== */
	$(document).on('click', '.psyq-more-btn', function (e) {
		e.stopPropagation();
		$('.psyq-more').not($(this).parent()).removeClass('is-open');
		$(this).parent().toggleClass('is-open');
	});
	$(document).on('click', function () {
		$('.psyq-more').removeClass('is-open');
	});

	/* ==========================================================
	 * مودال
	 * ========================================================== */
	function openModal(id) {
		var $m = $('#' + id);
		if (!$m.length) { return; }
		// انتقال به انتهای body تا از هر stacking context یا overflow والد خارج شود.
		if ($m.parent()[0] !== document.body) { $m.appendTo(document.body); }
		$m.removeAttr('hidden').addClass('is-open').css('display', 'grid');
		$m.find('.psyq-modal__body').scrollTop(0);
		$('body').css('overflow', 'hidden');
		$m.find('input, textarea').filter(':visible').eq(0).trigger('focus');
	}
	function closeModal($m) {
		if (!$m || !$m.length) { return; }
		$m.attr('hidden', 'hidden').removeClass('is-open').css('display', 'none');
		$('body').css('overflow', '');
	}
	var closeTopModal = function () {
		var $open = $('.psyq-modal').filter(function () { return !$(this).is('[hidden]'); });
		if ($open.length) { closeModal($open.last()); }
	};
	$(document).on('click', '.psyq-modal__overlay, .psyq-modal__close, .psyq-modal__cancel', function (e) {
		e.preventDefault();
		closeModal($(this).closest('.psyq-modal'));
	});
	$(document).on('keydown', function (e) {
		if (e.key === 'Escape' || e.keyCode === 27) { closeTopModal(); }
	});
	// اگر مودالی هم‌زمان با بارگذاری باز بود، همه بسته شوند.
	$(function () {
		$('.psyq-modal').attr('hidden', 'hidden').css('display', 'none');
		$('body').css('overflow', '');
	});

	/* ==========================================================
	 * افزودن / ویرایش سوال
	 * ========================================================== */
	$(document).on('click', '.psyq-add-item', function () {
		$('#psyq-item-id').val(0);
		$('#psyq-item-number').val($('.psyq-items-body tr[data-item-id]').length + 1);
		$('#psyq-item-text').val('');
		$('#psyq-item-subscale').val($('.psyq-filter-sub').val() || 0);
		setAnswerType('choice');
		$('#psyq-item-reversed').prop('checked', false);
		$('#psyq-item-required').prop('checked', true);
		$('#psyq-item-condition').val('');
		$('#psyq-item-note').val('');
		$('#psyq-item-img-id').val(0);
		$('#psyq-item-img-url').val('');
		$('#psyq-item-img-preview').attr('src', '').attr('hidden', 'hidden');
		$('#psyq-item-modal .psyq-modal__head h2').text('افزودن سوال جدید');
		var count = parseInt($('#psyq-default-count').val() || 4, 10);
		loadPreset($('#psyq-opt-rows'), count);
		openModal('psyq-item-modal');
	});

	$(document).on('click', '.psyq-edit-item', function () {
		var id = $(this).data('id');
		$(this).prop('disabled', true);
		var $btn = $(this);
		post('get_item', { item_id: id }).done(function (res) {
			$btn.prop('disabled', false);
			if (!res || !res.success) { return; }
			var it = res.data.item;
			$('#psyq-item-id').val(it.id);
			$('#psyq-item-number').val(it.number);
			$('#psyq-item-text').val(it.text);
			$('#psyq-item-subscale').val(it.subscale_id);
			setAnswerType(it.answer_type || 'choice');
			$('#psyq-item-reversed').prop('checked', !!it.reversed);
			$('#psyq-item-required').prop('checked', !!it.is_required);
			$('#psyq-item-condition').val(it.condition);
			$('#psyq-item-note').val(it.note || '');
			$('#psyq-item-img-id').val(it.image_id || 0);
			$('#psyq-item-img-url').val(it.image_url || '');
			if (it.image_url) { $('#psyq-item-img-preview').attr('src', it.image_url).removeAttr('hidden'); }
			else { $('#psyq-item-img-preview').attr('src', '').attr('hidden', 'hidden'); }

			$('#psyq-item-modal .psyq-modal__head h2').text('ویرایش سوال ' + it.number);
			var $rows = $('#psyq-opt-rows').empty();
			if ((it.answer_type || 'choice') !== 'text') {
				(it.options || []).forEach(function (o, i) { $rows.append(optRow(i, o)); });
				if (!$rows.children().length) { loadPreset($rows, 4); }
			}
			openModal('psyq-item-modal');
		});
	});

	$(document).on('change', '#psyq-item-answer-type', function () {
		setAnswerType($(this).val());
	});

	$(document).on('click', '#psyq-add-option', function () {
		var $rows = $('#psyq-opt-rows');
		var i = $rows.children().length;
		$rows.append(optRow(i, { label: '', value: 0 }));
		renumber($rows);
	});

	$(document).on('click', '.psyq-optrow__del', function () {
		$(this).closest('.psyq-optrow').remove();
		renumber($(this).closest('.psyq-opt-rows'));
	});

	$(document).on('change', '#psyq-preset-count', function () {
		var n = parseInt($(this).val(), 10);
		if (n) { loadPreset($('#psyq-opt-rows'), n); }
	});

	$(document).on('click', '#psyq-apply-preset', function () {
		var n = parseInt($('#psyq-preset-count').val() || 0, 10);
		if (!n) { alert(ADMIN.i18n.noOptions); return; }
		loadPreset($('#psyq-opt-rows'), n);
	});

	$(document).on('click', '#psyq-save-item', function () {
		var $btn = $(this).prop('disabled', true);
		var answerType = $('#psyq-item-answer-type').val() === 'text' ? 'text' : 'choice';
		var options = [];
		if (answerType === 'choice') {
			$('#psyq-opt-rows .psyq-optrow').each(function () {
				var label = $(this).find('.opt-label').val().trim();
				var value = $(this).find('.opt-value').val();
				var img = $(this).find('.opt-image').val().trim();
				if (!label && !img) { return; }
				options.push({ label: label, value: value, image_url: img });
			});
			if (!options.length) {
				alert('حداقل یک گزینه وارد کنید.');
				$btn.prop('disabled', false);
				return;
			}
		}
		var payload = {
			id: $('#psyq-item-id').val(),
			number: $('#psyq-item-number').val(),
			text: $('#psyq-item-text').val(),
			answer_type: answerType,
			subscale_id: $('#psyq-item-subscale').val(),
			reversed: $('#psyq-item-reversed').is(':checked') ? 1 : 0,
			is_required: $('#psyq-item-required').is(':checked') ? 1 : 0,
			condition: $('#psyq-item-condition').val(),
			note: $('#psyq-item-note').val(),
			image_id: $('#psyq-item-img-id').val(),
			image_url: $('#psyq-item-img-url').val(),
			options: options
		};
		post('save_item', { item: JSON.stringify(payload) })
			.done(function (res) {
				$btn.prop('disabled', false);
				if (!res || !res.success) {
					alert((res && res.data && res.data.message) || ADMIN.i18n.error);
					return;
				}
				var id = res.data.item.id;
				$('.psyq-items-body .psyq-empty').remove();
				var $existing = $('.psyq-items-body tr[data-item-id="' + id + '"]');
				if ($existing.length) { $existing.replaceWith(res.data.html); }
				else { $('.psyq-items-body').append(res.data.html); }
				closeModal($('#psyq-item-modal'));
				if (window.psyqToast) { window.psyqToast('سوال ذخیره شد ✓'); }
			})
			.fail(function () {
				$btn.prop('disabled', false);
				alert(ADMIN.i18n.error);
			});
	});

	$(document).on('click', '.psyq-del-item', function () {
		if (!confirm(ADMIN.i18n.confirmDelete)) { return; }
		var $row = $(this).closest('tr');
		post('delete_item', { item_id: $row.data('item-id') }).done(function () {
			$row.fadeOut(160, function () { $(this).remove(); });
		});
	});

	/* مرتب‌سازی سوالات */
	if ($.fn.sortable && $('.psyq-items-body').length) {
		$('.psyq-items-body').sortable({
			handle: '.psyq-col-drag',
			axis: 'y',
			helper: function (e, ui) {
				ui.children().each(function () { $(this).width($(this).width()); });
				return ui;
			},
			update: function () {
				var order = [];
				$('.psyq-items-body tr[data-item-id]').each(function () { order.push($(this).data('item-id')); });
				post('reorder_items', { order: order });
			}
		});
	}

	/* فیلتر و جست‌وجو در سوالات */
	$(document).on('input', '.psyq-search-items', function () {
		var q = $(this).val().toLowerCase();
		$('.psyq-items-body tr[data-item-id]').each(function () {
			var t = $(this).find('.psyq-item-text').text().toLowerCase();
			$(this).toggle(t.indexOf(q) !== -1);
		});
	});
	$(document).on('change', '.psyq-filter-sub', function () {
		var v = $(this).val();
		$('.psyq-items-body tr[data-item-id]').each(function () {
			if (!v) { $(this).show(); return; }
			var found = $(this).find('.psyq-col-sub').text().trim();
			var target = $('.psyq-filter-sub option:selected').text().trim();
			$(this).toggle(found === target);
		});
	});

	/* ==========================================================
	 * انتخاب تصویر
	 * ========================================================== */
	var fileFrame = null;
	var imageTarget = null;
	var $optTargetInput = null;

	$(document).on('click', '.psyq-optrow__img', function (e) {
		e.preventDefault();
		imageTarget = 'opt';
		$optTargetInput = $(this).closest('.psyq-optrow').find('.opt-image');
		openMedia();
	});

	function openMedia() {
		if (!fileFrame) {
			fileFrame = wp.media({
				title: ADMIN.i18n.selectImage,
				button: { text: ADMIN.i18n.useImage },
				multiple: false,
				library: { type: 'image' }
			});
			fileFrame.on('select', function () {
				var att = fileFrame.state().get('selection').first().toJSON();
				if (imageTarget === 'item') {
					$('#psyq-item-img-id').val(att.id);
					$('#psyq-item-img-url').val(att.url);
					$('#psyq-item-img-preview').attr('src', att.url).removeAttr('hidden');
				} else if (imageTarget === 'opt' && $optTargetInput) {
					$optTargetInput.val(att.url);
					$optTargetInput.attr('title', att.url);
				}
			});
		}
		fileFrame.open();
	}

	$(document).on('click', '.psyq-pick-image', function (e) {
		e.preventDefault();
		imageTarget = 'item';
		openMedia();
	});

	$(document).on('click', '.psyq-clear-image', function () {
		$('#psyq-item-img-id').val(0);
		$('#psyq-item-img-url').val('');
		$('#psyq-item-img-preview').attr('src', '').attr('hidden', 'hidden');
	});

	$(document).on('input', '#psyq-item-img-url', function () {
		var v = $(this).val();
		if (v) { $('#psyq-item-img-preview').attr('src', v).removeAttr('hidden'); }
		else { $('#psyq-item-img-preview').attr('hidden', 'hidden'); }
	});

	/* ==========================================================
	 * افزودن گروهی
	 * ========================================================== */
	$(document).on('click', '.psyq-bulk-import', function () {
		$('#psyq-bulk-text').val('');
		var n = parseInt($('#psyq-default-count').val() || 4, 10);
		$('#psyq-bulk-preset').val(n);
		loadPreset($('#psyq-bulk-opt-rows'), n);
		$('#psyq-bulk-start').val($('.psyq-items-body tr[data-item-id]').length + 1);
		openModal('psyq-bulk-modal');
	});

	$(document).on('change', '#psyq-bulk-preset', function () {
		var n = parseInt($(this).val(), 10);
		if (n) { loadPreset($('#psyq-bulk-opt-rows'), n); }
	});

	$(document).on('click', '#psyq-bulk-save', function () {
		var lines = $('#psyq-bulk-text').val().split(/\r?\n/).map(function (l) { return l.trim(); }).filter(Boolean);
		if (!lines.length) { alert('متنی وارد نشده است.'); return; }
		var options = [];
		$('#psyq-bulk-opt-rows .psyq-optrow').each(function () {
			var label = $(this).find('.opt-label').val().trim();
			if (!label) { return; }
			options.push({ label: label, value: $(this).find('.opt-value').val(), image_url: $(this).find('.opt-image').val() });
		});
		if (!options.length) { alert('گزینه‌ها را کامل کنید.'); return; }

		var start = parseInt($('#psyq-bulk-start').val() || 1, 10);
		var sub = $('#psyq-bulk-sub').val();
		var $btn = $(this).prop('disabled', true).text('در حال ذخیره…');
		var i = 0;

		function next() {
			if (i >= lines.length) {
				$btn.prop('disabled', false).text('افزودن سوالات');
				closeModal($('#psyq-bulk-modal'));
				location.reload();
				return;
			}
			var payload = {
				id: 0,
				number: start + i,
				text: lines[i].replace(/^[\d۰-۹]+[\.\)\-–]\s*/, ''),
				subscale_id: sub,
				is_required: 1,
				options: options
			};
			post('save_item', { item: JSON.stringify(payload) }).always(function () {
				i++;
				next();
			});
		}
		next();
	});

	/* ==========================================================
	 * زیرمقیاس‌ها
	 * ========================================================== */
	function bandRow(b) {
		b = b || {};
		var $r = $('<div class="psyq-band">');
		$r.append('<span class="psyq-band__idx"></span>');
		$r.append('<input type="number" step="0.01" class="psyq-band__min" value="' + esc(b.min !== undefined ? b.min : 0) + '">');
		$r.append('<input type="number" step="0.01" class="psyq-band__max" value="' + esc(b.max !== undefined && b.max < 99999 ? b.max : '') + '" placeholder="∞">');
		$r.append('<input type="text" class="psyq-band__label" value="' + esc(b.label || '') + '" placeholder="برچسب">');
		$r.append('<input type="color" class="psyq-band__color" value="' + esc(b.color || '#22c55e') + '">');
		$r.append('<textarea class="psyq-band__interp" rows="2" placeholder="تفسیر این بازه">' + esc(b.interpretation || '') + '</textarea>');
		$r.append('<button type="button" class="psyq-band__del">×</button>');
		return $r;
	}

	function renumberBands($box) {
		$box.find('.psyq-band').each(function (i) {
			$(this).find('.psyq-band__idx').text(i + 1);
		});
	}

	$(document).on('click', '.psyq-band__add', function () {
		var $rows = $(this).closest('.psyq-bands').find('.psyq-bands__rows');
		var $last = $rows.find('.psyq-band').last();
		var nextMin = 0;
		if ($last.length) { nextMin = parseFloat($last.find('.psyq-band__max').val() || 0) || 0; }
		$rows.append(bandRow({ min: nextMin, color: '#f59e0b' }));
		renumberBands($rows);
	});

	$(document).on('click', '.psyq-band__del', function () {
		var $rows = $(this).closest('.psyq-bands__rows');
		$(this).closest('.psyq-band').remove();
		renumberBands($rows);
	});

	$(document).on('click', '.psyq-band__suggest', function () {
		var $sub = $(this).closest('.psyq-sub');
		var sid = $sub.data('sub-id');
		var $rows = $sub.find('.psyq-bands__rows').empty();
		post('suggest_bands', { subscale_id: sid, count: 4 }).done(function (res) {
			if (res && res.success) {
				res.data.bands.forEach(function (b) { $rows.append(bandRow(b)); });
			}
		});
	});

	function collectBands($sub) {
		var bands = [];
		$sub.find('.psyq-band').each(function () {
			bands.push({
				min: $(this).find('.psyq-band__min').val(),
				max: $(this).find('.psyq-band__max').val(),
				label: $(this).find('.psyq-band__label').val(),
				color: $(this).find('.psyq-band__color').val(),
				interpretation: $(this).find('.psyq-band__interp').val()
			});
		});
		return bands;
	}

	$(document).on('click', '.psyq-sub__save', function () {
		var $sub = $(this).closest('.psyq-sub');
		var $btn = $(this).prop('disabled', true);
		var payload = {
			id: $sub.data('sub-id'),
			title: $sub.find('.psyq-sub__title').val(),
			name: $sub.find('.psyq-sub__name').val() || $sub.find('.psyq-sub__title').val(),
			description: $sub.find('.psyq-sub__desc').val(),
			color: $sub.find('.psyq-sub__color').val(),
			include_in_total: $sub.find('.psyq-sub__intotal').is(':checked') ? 1 : 0,
			bands: collectBands($sub)
		};
		post('save_subscale', { subscale: JSON.stringify(payload) })
			.done(function (res) {
				$btn.prop('disabled', false);
				if (!res || !res.success) {
					alert((res && res.data && res.data.message) || ADMIN.i18n.error);
					return;
				}
				if ($sub.data('is-total') !== 1) { $sub.data('sub-id', res.data.id); $sub.attr('data-sub-id', res.data.id); }
				$btn.text('ذخیره شد ✓').addClass('button-primary');
				setTimeout(function () { $btn.text('ذخیره').removeClass('button-primary'); }, 1600);
				if (window.psyqToast) { window.psyqToast('زیرمقیاس و ' + (res.data.band_cnt || 0) + ' بازه ذخیره شد ✓'); }
			})
			.fail(function () { $btn.prop('disabled', false); alert(ADMIN.i18n.error); });
	});

	$(document).on('click', '.psyq-sub__delete', function () {
		if (!confirm('این زیرمقیاس و نقاط برش آن حذف شود؟ سوالات مربوطه بدون زیرمقیاس خواهند شد.')) { return; }
		var $sub = $(this).closest('.psyq-sub');
		post('delete_subscale', { subscale_id: $sub.data('sub-id') }).done(function () {
			$sub.slideUp(160, function () { $(this).remove(); });
		});
	});

	function subscaleTemplate(idx, color) {
		return ''
			+ '<div class="psyq-sub" data-sub-id="0" data-is-total="0">'
			+ '  <header class="psyq-sub__head">'
			+ '    <span class="psyq-sub__swatch" style="background:' + color + '"></span>'
			+ '    <input type="text" class="psyq-sub__title" value="زیرمقیاس ' + idx + '" placeholder="عنوان زیرمقیاس">'
			+ '    <input type="text" class="psyq-sub__name" value="SUB' + idx + '" placeholder="کد" title="کد یکتا">'
			+ '    <label class="psyq-check psyq-check--sm"><input type="checkbox" class="psyq-sub__intotal" value="1" checked><span>در نمره کل لحاظ شود</span></label>'
			+ '    <input type="color" class="psyq-sub__color" value="' + color + '">'
			+ '    <span class="psyq-sub__count">0 سوال</span>'
			+ '    <button type="button" class="button button-small psyq-sub__save">ذخیره</button>'
			+ '    <button type="button" class="button button-small psyq-sub__delete">حذف</button>'
			+ '  </header>'
			+ '  <div class="psyq-sub__body">'
			+ '    <textarea class="psyq-sub__desc" rows="2" placeholder="توضیح کوتاه زیرمقیاس (اختیاری)"></textarea>'
			+ '    <div class="psyq-bands">'
			+ '      <div class="psyq-bands__head"><span>بازه</span><span>از (شامل)</span><span>تا (غیرشامل)</span><span>برچسب سطح</span><span>رنگ</span><span>تفسیر اختصاصی این بازه</span><span></span></div>'
			+ '      <div class="psyq-bands__rows"></div>'
			+ '      <div class="psyq-bands__foot">'
			+ '        <button type="button" class="button button-small psyq-band__add">+ افزودن بازه</button>'
			+ '        <button type="button" class="button button-small psyq-band__suggest">پیشنهاد خودکار ۴ بازه</button>'
			+ '        <span class="psyq-muted psyq-small">در متن تفسیر می‌توانید از متغیرهای {score}، {max}، {percent}، {name} استفاده کنید.</span>'
			+ '      </div>'
			+ '    </div>'
			+ '  </div>'
			+ '</div>';
	}

	$(document).on('click', '.psyq-add-subscale', function () {
		var idx = $('.psyq-sub').length + 1;
		var colors = ['#3b82f6', '#8b5cf6', '#ec4899', '#f59e0b', '#10b981', '#ef4444', '#0ea5e9'];
		var color = colors[idx % colors.length];
		$('.psyq-subs .psyq-empty-box').remove();
		var $sub = $(subscaleTemplate(idx, color));
		var $rows = $sub.find('.psyq-bands__rows');
		[0, 25, 50, 75].forEach(function (m, i) {
			$rows.append(bandRow({
				min: m,
				max: i === 3 ? '' : m + 25,
				label: ['طبیعی', 'خفیف', 'متوسط', 'شدید'][i],
				color: ['#16a34a', '#84cc16', '#f59e0b', '#ef4444'][i]
			}));
		});
		var $total = $('.psyq-sub[data-is-total="1"]');
		if ($total.length) { $sub.insertBefore($total); } else { $('.psyq-subs').append($sub); }
		$sub.hide().slideDown(160);
		$sub.find('.psyq-sub__title').trigger('focus').select();
	});

	$(document).on('input', '.psyq-sub__color', function () {
		$(this).closest('.psyq-sub').find('.psyq-sub__swatch').css('background', $(this).val());
	});

	/* ==========================================================
	 * پیش‌نمایش گزارش
	 * ========================================================== */
	function preview(mode) {
		var $box = $('#psyq-preview-box');
		$box.html('<div class="psyq-empty-box">در حال تولید…</div>');
		post('preview_report', { mode: mode }).done(function (res) {
			if (!res || !res.success) {
				$box.html('<div class="psyq-empty-box">' + ((res && res.data && res.data.message) || 'خطا') + '</div>');
				return;
			}
			$box.html(res.data.html);
			if (window.PsyQFront && window.PsyQFront.initCharts) { window.PsyQFront.initCharts($box[0]); }
		});
	}
	$(document).on('click', '#psyq-preview-mid', function () { preview('mid'); });
	$(document).on('click', '#psyq-preview-random', function () { preview('random'); });

	/* ==========================================================
	 * آپلود فایل اکسل
	 * ========================================================== */
	if ($('#psyq-dropzone').length) {
		var $dz = $('#psyq-dropzone');
		var $input = $('#psyq-file-input');
		$dz.on('click', function (e) {
			if (e.target.tagName !== 'INPUT') { $input.trigger('click'); }
		});
		$input.on('change', function () {
			if (this.files && this.files[0]) {
				$('#psyq-file-name').text(this.files[0].name + ' — ' + Math.round(this.files[0].size / 1024) + ' KB');
			}
		});
		$dz.on('dragover dragenter', function (e) { e.preventDefault(); $dz.addClass('is-over'); });
		$dz.on('dragleave drop', function (e) { e.preventDefault(); $dz.removeClass('is-over'); });
		$dz.on('drop', function (e) {
			var files = e.originalEvent.dataTransfer.files;
			if (files && files.length) {
				$input[0].files = files;
				$('#psyq-file-name').text(files[0].name);
			}
		});
		$(document).on('change', '#psyq-import-form', function () {
			if ($(this).val() !== '0') { $('#psyq-import-mode').val('replace'); }
			else { $('#psyq-import-mode').val('new'); }
		});
	}


	// درخواست ورود فایل یک POST معمولی است؛ با وضعیت واضح از برداشت «کلیک عمل نکرد» جلوگیری کن.
	$(document).on('submit', '#psyq-import-upload-form', function () {
		var input = document.getElementById('psyq-file-input');
		if (!input || !input.files || !input.files.length) { return; }
		var $button = $('#psyq-import-submit');
		$button.data('psyq-original-label', $button.text()).text('در حال خواندن و ورود فایل…').prop('disabled', true).addClass('is-busy');
		$('#psyq-import-status').text('فایل در حال ارسال و بررسی است؛ لطفاً این صفحه را نبندید.').removeAttr('hidden');
	});

})(jQuery);
