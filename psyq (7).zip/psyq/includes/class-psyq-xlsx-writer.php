<?php
/**
 * نویسنده سبک فایل XLSX بدون وابستگی به Composer.
 *
 * @package PsyQ
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class PsyQ_XLSX_Writer {

	/** @var array شیت‌ها */
	private $sheets = array();

	/**
	 * افزودن شیت.
	 *
	 * @param string $name    نام شیت.
	 * @param array  $rows    ردیف‌ها؛ هر سلول: null | string | number | array( 'v'=>, 't'=>'s|n', 's'=>style, 'f'=>formula ).
	 * @param array  $options گزینه‌ها: header_rows, col_widths, wrap_cols, validations, freeze_row, autofilter.
	 */
	public function add_sheet( $name, $rows, $options = array() ) {
		$this->sheets[] = array(
			'name'    => $this->safe_sheet_name( $name ),
			'rows'    => $rows,
			'options' => wp_parse_args(
				$options,
				array(
					'header_rows' => 1,
					'col_widths'  => array(),
					'wrap_cols'   => array(),
					'validations' => array(),
					'freeze_row'  => 1,
					'autofilter'  => false,
					'landscape'   => false,
				)
			),
		);
	}

	private function safe_sheet_name( $name ) {
		$name = preg_replace( '/[\\\\\\/\\?\\*\\[\\]:]/u', ' ', (string) $name );
		$name = trim( $name );
		if ( '' === $name ) {
			$name = 'Sheet';
		}
		return mb_substr( $name, 0, 31, 'UTF-8' );
	}

	/**
	 * ذخیره فایل.
	 *
	 * @param string $path مسیر.
	 * @return bool
	 * @throws Exception اگر ZipArchive نبود.
	 */
	public function save( $path ) {
		if ( ! class_exists( 'ZipArchive' ) ) {
			throw new Exception( 'برای ساخت فایل اکسل، افزونه php-zip روی سرور لازم است.' );
		}
		$zip = new ZipArchive();
		if ( true !== $zip->open( $path, ZipArchive::CREATE | ZipArchive::OVERWRITE ) ) {
			throw new Exception( 'امکان ساخت فایل اکسل در مسیر موقت نیست.' );
		}

		// ابتدا شیت‌ها سریال می‌شوند تا جدول رشته‌های مشترک پر شود.
		$sheet_xml = array();
		foreach ( $this->sheets as $i => $sheet ) {
			$sheet_xml[ $i ] = $this->sheet_xml( $sheet );
		}

		$zip->addFromString( '[Content_Types].xml', $this->content_types() );
		$zip->addFromString( '_rels/.rels', $this->root_rels() );
		$zip->addFromString( 'xl/workbook.xml', $this->workbook() );
		$zip->addFromString( 'xl/_rels/workbook.xml.rels', $this->workbook_rels() );
		$zip->addFromString( 'xl/styles.xml', $this->styles() );
		$zip->addFromString( 'xl/sharedStrings.xml', $this->shared_strings() );
		foreach ( $sheet_xml as $i => $xml ) {
			$zip->addFromString( 'xl/worksheets/sheet' . ( $i + 1 ) . '.xml', $xml );
		}
		$zip->close();
		return true;
	}

	/* ------------------------------------------------------------------ */

	private function content_types() {
		$s = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
			. '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
			. '<Default Extension="xml" ContentType="application/xml"/>'
			. '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
			. '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
			. '<Override PartName="/xl/sharedStrings.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/>';
		foreach ( $this->sheets as $i => $sheet ) {
			$s .= '<Override PartName="/xl/worksheets/sheet' . ( $i + 1 ) . '.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>';
		}
		return $s . '</Types>';
	}

	private function root_rels() {
		return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
			. '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
			. '</Relationships>';
	}

	private function workbook() {
		$s = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
			. '<workbookPr/>'
			. '<bookViews><workbookView/></bookViews>'
			. '<sheets>';
		foreach ( $this->sheets as $i => $sheet ) {
			$s .= '<sheet name="' . $this->esc( $sheet['name'] ) . '" sheetId="' . ( $i + 1 ) . '" r:id="rId' . ( $i + 1 ) . '"/>';
		}
		$s .= '</sheets></workbook>';
		return $s;
	}

	private function workbook_rels() {
		$s = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">';
		$n = count( $this->sheets );
		foreach ( $this->sheets as $i => $sheet ) {
			$s .= '<Relationship Id="rId' . ( $i + 1 ) . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet' . ( $i + 1 ) . '.xml"/>';
		}
		$s .= '<Relationship Id="rId' . ( $n + 1 ) . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>';
		$s .= '<Relationship Id="rId' . ( $n + 2 ) . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings" Target="sharedStrings.xml"/>';
		$s .= '</Relationships>';
		return $s;
	}

	/**
	 * استایل‌ها:
	 * 0 = پیش‌فرض | 1 = سرستون | 2 = متن راست‌چین با کادر | 3 = عدد وسط‌چین با کادر
	 * 4 = عنوان | 5 = یادداشت | 6 = زیرعنوان | 7 = متن ساده راست‌چین.
	 */
	private function styles() {
		return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
			. '<fonts count="6">'
			. '<font><sz val="11"/><name val="Tahoma"/><family val="2"/></font>'
			. '<font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Tahoma"/><family val="2"/></font>' // 1 header
			. '<font><b/><sz val="14"/><color rgb="FF312E81"/><name val="Tahoma"/><family val="2"/></font>' // 2 title
			. '<font><i/><sz val="10"/><color rgb="FF64748B"/><name val="Tahoma"/><family val="2"/></font>' // 3 note
			. '<font><b/><sz val="11"/><color rgb="FF1E293B"/><name val="Tahoma"/><family val="2"/></font>' // 4 sub
			. '<font><u/><sz val="11"/><color rgb="FF2563EB"/><name val="Tahoma"/><family val="2"/></font>' // 5 link
			. '</fonts>'
			. '<fills count="4">'
			. '<fill><patternFill patternType="none"/></fill>'
			. '<fill><patternFill patternType="gray125"/></fill>'
			. '<fill><patternFill patternType="solid"><fgColor rgb="FF4338CA"/><bgColor indexed="64"/></patternFill></fill>'
			. '<fill><patternFill patternType="solid"><fgColor rgb="FFEEF2FF"/><bgColor indexed="64"/></patternFill></fill>'
			. '</fills>'
			. '<borders count="2">'
			. '<border><left/><right/><top/><bottom/><diagonal/></border>'
			. '<border><left style="thin"><color rgb="FFCBD5E1"/></left><right style="thin"><color rgb="FFCBD5E1"/></right><top style="thin"><color rgb="FFCBD5E1"/></top><bottom style="thin"><color rgb="FFCBD5E1"/></bottom><diagonal/></border>'
			. '</borders>'
			. '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
			. '<cellXfs count="9">'
			// 0 default
			. '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
			// 1 header
			. '<xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1" readingOrder="2"/></xf>'
			// 2 text cell
			. '<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="top" wrapText="1" readingOrder="2"/></xf>'
			// 3 number cell
			. '<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>'
			// 4 title
			. '<xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="right" vertical="center" readingOrder="2"/></xf>'
			// 5 note
			. '<xf numFmtId="0" fontId="3" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="right" vertical="center" readingOrder="2"/></xf>'
			// 6 subheader (light bg)
			. '<xf numFmtId="0" fontId="4" fillId="3" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1" readingOrder="2"/></xf>'
			// 7 plain right
			. '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment horizontal="right" vertical="center" wrapText="1" readingOrder="2"/></xf>'
			// 8 decimal number
			. '<xf numFmtId="2" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>'
			. '</cellXfs>'
			. '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
			. '</styleSheet>';
	}

	/** @var array رشته‌های مشترک */
	private $sst = array();
	/** @var array نگاشت رشته به اندیس */
	private $sst_map = array();

	private function str_index( $value ) {
		$value = (string) $value;
		if ( isset( $this->sst_map[ $value ] ) ) {
			return $this->sst_map[ $value ];
		}
		$idx                  = count( $this->sst );
		$this->sst[]          = $value;
		$this->sst_map[ $value ] = $idx;
		return $idx;
	}

	private function shared_strings() {
		$s = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="' . count( $this->sst ) . '" uniqueCount="' . count( $this->sst ) . '">';
		foreach ( $this->sst as $str ) {
			$s .= '<si><t xml:space="preserve">' . $this->esc( $str ) . '</t></si>';
		}
		return $s . '</sst>';
	}

	private function sheet_xml( $sheet ) {
		$rows   = $sheet['rows'];
		$opt    = $sheet['options'];
		$xml    = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
			. '<sheetPr><pageSetUpPr fitToPage="1"/></sheetPr>'
			. '<sheetViews><sheetView rightToLeft="1" workbookViewId="0"';
		if ( ! empty( $opt['freeze_row'] ) ) {
			$xml .= '><pane ySplit="' . (int) $opt['freeze_row'] . '" topLeftCell="A' . ( (int) $opt['freeze_row'] + 1 ) . '" activePane="bottomLeft" state="frozen"/><selection pane="bottomLeft" activeCell="A' . ( (int) $opt['freeze_row'] + 1 ) . '" sqref="A' . ( (int) $opt['freeze_row'] + 1 ) . '"/></sheetView>';
		} else {
			$xml .= '/>';
		}
		$xml .= '</sheetViews>';

		// ستون‌ها.
		$max_cols = 0;
		foreach ( $rows as $r ) {
			if ( count( $r ) > $max_cols ) {
				$max_cols = count( $r );
			}
		}
		$widths = isset( $opt['col_widths'] ) ? $opt['col_widths'] : array();
		if ( $max_cols > 0 ) {
			$xml .= '<cols>';
			for ( $c = 0; $c < max( $max_cols, count( $widths ) ); $c++ ) {
				$w = isset( $widths[ $c ] ) ? (float) $widths[ $c ] : 18;
				$xml .= '<col min="' . ( $c + 1 ) . '" max="' . ( $c + 1 ) . '" width="' . $w . '" customWidth="1"/>';
			}
			$xml .= '</cols>';
		}

		$xml .= '<sheetData>';
		foreach ( $rows as $ri => $row ) {
			$row_num = $ri + 1;
			$xml    .= '<row r="' . $row_num . '"' . ( $ri < $opt['header_rows'] ? ' ht="30" customHeight="1"' : '' ) . '>';
			foreach ( $row as $ci => $cell ) {
				if ( null === $cell || '' === $cell ) {
					continue;
				}
				$ref   = PsyQ_XLSX_Reader::col_letter( $ci ) . $row_num;
				$value = $cell;
				$style = $ri < $opt['header_rows'] ? 1 : 2;
				$type  = 's';

				if ( is_array( $cell ) ) {
					$value = isset( $cell['v'] ) ? $cell['v'] : '';
					$style = isset( $cell['s'] ) ? (int) $cell['s'] : $style;
					$type  = isset( $cell['t'] ) ? $cell['t'] : ( is_numeric( $value ) ? 'n' : 's' );
				} elseif ( is_int( $cell ) || is_float( $cell ) ) {
					$type  = 'n';
					$style = $ri < $opt['header_rows'] ? 1 : 3;
				} elseif ( is_numeric( $cell ) && preg_match( '/^-?\d+(\.\d+)?$/', $cell ) ) {
					$type  = 'n';
					$style = $ri < $opt['header_rows'] ? 1 : 3;
				}

				if ( 'n' === $type ) {
					$xml .= '<c r="' . $ref . '" s="' . $style . '"><v>' . ( 0 + $value ) . '</v></c>';
				} else {
					$idx  = $this->str_index( $value );
					$xml .= '<c r="' . $ref . '" s="' . $style . '" t="s"><v>' . $idx . '</v></c>';
				}
			}
			$xml .= '</row>';
		}
		$xml .= '</sheetData>';

		// اعتبارسنجی داده (لیست کشویی).
		if ( ! empty( $opt['validations'] ) ) {
			$xml .= '<dataValidations count="' . count( $opt['validations'] ) . '">';
			foreach ( $opt['validations'] as $v ) {
				$formula = '"' . implode( ',', array_map( array( $this, 'esc' ), $v['options'] ) ) . '"';
				$xml    .= '<dataValidation type="list" allowBlank="1" showInputMessage="1" showErrorMessage="1" sqref="' . $this->esc( $v['sqref'] ) . '">'
					. '<formula1>' . $formula . '</formula1></dataValidation>';
			}
			$xml .= '</dataValidations>';
		}

		if ( ! empty( $opt['autofilter'] ) ) {
			$xml .= '<autoFilter ref="A1:' . PsyQ_XLSX_Reader::col_letter( max( 0, $max_cols - 1 ) ) . max( 1, count( $rows ) ) . '"/>';
		}

		$xml .= '<pageMargins left="0.4" right="0.4" top="0.6" bottom="0.6" header="0.3" footer="0.3"/>';
		$xml .= '<pageSetup orientation="' . ( ! empty( $opt['landscape'] ) ? 'landscape' : 'portrait' ) . '" fitToWidth="1" fitToHeight="0"/>';
		$xml .= '</worksheet>';
		return $xml;
	}

	private function esc( $s ) {
		$s = (string) $s;
		$s = str_replace( array( '&', '<', '>' ), array( '&amp;', '&lt;', '&gt;' ), $s );
		// حذف کاراکترهای غیرمجاز XML.
		$s = preg_replace( '/[^\x{0009}\x{000A}\x{000D}\x{0020}-\x{D7FF}\x{E000}-\x{FFFD}]/u', '', $s );
		return $s;
	}
}
