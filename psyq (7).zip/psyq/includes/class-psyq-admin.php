<?php
/**
 * پنل مدیریت.
 *
 * @package PsyQ
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class PsyQ_Admin {

	const CAP = 'manage_options';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'admin_post_psyq_action', array( __CLASS__, 'handle_action' ) );
		add_action( 'admin_post_psyq_excel', array( __CLASS__, 'handle_excel' ) );
		add_action( 'admin_post_psyq_import', array( __CLASS__, 'handle_import' ) );
		add_action( 'admin_notices', array( __CLASS__, 'notices' ) );
	}

	public static function menu() {
		$cap = self::CAP;

		add_menu_page(
			__( 'پرسشنامه‌های روان‌شناسی', 'psyq' ),
			__( 'پرسشنامه‌ها', 'psyq' ),
			$cap,
			'psyq',
			array( __CLASS__, 'page_dashboard' ),
			'dashicons-clipboard',
			26
		);

		add_submenu_page( 'psyq', __( 'پیشخوان', 'psyq' ), __( 'پیشخوان', 'psyq' ), $cap, 'psyq', array( __CLASS__, 'page_dashboard' ) );
		add_submenu_page( 'psyq', __( 'همه پرسشنامه‌ها', 'psyq' ), __( 'همه پرسشنامه‌ها', 'psyq' ), $cap, 'psyq-forms', array( __CLASS__, 'page_forms' ) );
		add_submenu_page( 'psyq', __( 'افزودن پرسشنامه', 'psyq' ), __( 'افزودن پرسشنامه', 'psyq' ), $cap, 'psyq-form', array( __CLASS__, 'page_form' ) );
		add_submenu_page( 'psyq', __( 'ورود از اکسل', 'psyq' ), __( 'ورود از اکسل', 'psyq' ), $cap, 'psyq-import', array( __CLASS__, 'page_import' ) );
		add_submenu_page( 'psyq', __( 'قالب خام اکسل', 'psyq' ), __( 'قالب خام اکسل', 'psyq' ), $cap, 'psyq-templates', array( __CLASS__, 'page_templates' ) );
		add_submenu_page( 'psyq', __( 'پاسخ‌ها و نتایج', 'psyq' ), __( 'پاسخ‌ها و نتایج', 'psyq' ), $cap, 'psyq-responses', array( __CLASS__, 'page_responses' ) );
		add_submenu_page( 'psyq', __( 'گزارش یک آزمودنی', 'psyq' ), __( 'گزارش آزمودنی', 'psyq' ), $cap, 'psyq-report', array( __CLASS__, 'page_report' ) );
		add_submenu_page( 'psyq', __( 'تنظیمات', 'psyq' ), __( 'تنظیمات', 'psyq' ), $cap, 'psyq-settings', array( __CLASS__, 'page_settings' ) );
	}

	public static function assets( $hook ) {
		if ( false === strpos( (string) $hook, 'psyq' ) ) {
			return;
		}
		wp_enqueue_media();
		wp_enqueue_style( 'psyq-admin', PSYQ_URL . 'assets/css/admin.css', array(), PSYQ_VERSION );
		wp_enqueue_style( 'psyq-front', PSYQ_URL . 'assets/css/front.css', array(), PSYQ_VERSION );
		wp_enqueue_script( 'psyq-chartjs', PSYQ_URL . 'assets/vendor/chart.umd.min.js', array(), '4.4.1', true );
		wp_enqueue_script( 'psyq-front', PSYQ_URL . 'assets/js/front.js', array(), PSYQ_VERSION, true );
		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_script( 'psyq-admin', PSYQ_URL . 'assets/js/admin.js', array( 'jquery', 'wp-color-picker', 'jquery-ui-sortable' ), PSYQ_VERSION, true );

		$form_id = isset( $_GET['form_id'] ) ? (int) $_GET['form_id'] : 0; // phpcs:ignore
		$bundle  = $form_id ? PsyQ_Scoring::bundle( $form_id ) : false;

		wp_localize_script(
			'psyq-admin',
			'PsyQAdmin',
			array(
				'ajaxUrl'  => admin_url( 'admin-ajax.php' ),
				'nonce'    => wp_create_nonce( 'psyq_admin' ),
				'formId'   => $form_id,
				'urls'     => array(
					'form'      => admin_url( 'admin.php?page=psyq-form' ),
					'responses' => admin_url( 'admin.php?page=psyq-responses' ),
					'report'    => admin_url( 'admin.php?page=psyq-report' ),
					'ajax'      => admin_url( 'admin-ajax.php' ),
				),
				'presets'  => PsyQ_DB::option_presets(),
				'brand'    => array(
					'name'    => get_bloginfo( 'name' ),
					'color'   => get_option( 'psyq_brand_color', '#4338ca' ),
					'logo'    => get_option( 'psyq_brand_logo', '' ),
				),
				'totalId'  => $bundle && $bundle['total'] ? $bundle['total']['id'] : 0,
				'i18n'     => array(
					'confirmDelete' => __( 'آیا از حذف این مورد مطمئن هستید؟ این عمل قابل بازگشت نیست.', 'psyq' ),
					'confirmImport' => __( 'با ورود فایل اکسل، داده‌های فعلی پرسشنامه (در حالت جایگزینی) پاک می‌شوند. ادامه می‌دهید؟', 'psyq' ),
					'saved'         => __( 'ذخیره شد.', 'psyq' ),
					'error'         => __( 'خطا در ذخیره‌سازی.', 'psyq' ),
					'selectImage'   => __( 'انتخاب تصویر', 'psyq' ),
					'useImage'      => __( 'استفاده از این تصویر', 'psyq' ),
					'noOptions'     => __( 'ابتدا تعداد گزینه را انتخاب کنید.', 'psyq' ),
				),
			)
		);
	}

	/* ==================================================================
	 * پیام‌ها
	 * ================================================================== */

	public static function notices() {
		$notice = isset( $_GET['psyq_notice'] ) ? sanitize_text_field( wp_unslash( $_GET['psyq_notice'] ) ) : ''; // phpcs:ignore
		if ( $notice ) {
			// redirect() علاوه بر transient یک نسخه base64url در URL می‌گذارد تا
			// پیام در سایت‌هایی که transient/object cache آن‌ها مشکل دارد هم دیده شود.
			$decoded = self::decode_notice( $notice );
			if ( '' !== $decoded ) {
				$notice = $decoded;
			}
			delete_transient( 'psyq_notice_' . get_current_user_id() );
		}
		if ( ! $notice ) {
			$notice = get_transient( 'psyq_notice_' . get_current_user_id() );
			delete_transient( 'psyq_notice_' . get_current_user_id() );
		}
		if ( ! $notice ) {
			return;
		}
		$data = json_decode( (string) $notice, true );
		if ( ! is_array( $data ) ) {
			echo '<div class="notice notice-info is-dismissible"><p>' . esc_html( $notice ) . '</p></div>';
			return;
		}
		$type = isset( $data['type'] ) ? $data['type'] : 'success';
		if ( ! in_array( $type, array( 'success', 'error', 'warning', 'info' ), true ) ) {
			$type = 'info';
		}
		echo '<div class="notice notice-' . esc_attr( $type ) . ' is-dismissible"><p>' . esc_html( isset( $data['msg'] ) ? $data['msg'] : '' ) . '</p>';
		if ( ! empty( $data['warnings'] ) ) {
			echo '<ul style="margin-inline-start:18px;list-style:disc">';
			foreach ( (array) $data['warnings'] as $w ) {
				echo '<li>' . esc_html( $w ) . '</li>';
			}
			echo '</ul>';
		}
		echo '</div>';
	}

	/**
	 * کدگذاری قابل‌قرارگیری در URL برای fallback پیام‌های redirect.
	 *
	 * @param string $notice JSON پیام.
	 * @return string
	 */
	private static function encode_notice( $notice ) {
		return rtrim( strtr( base64_encode( (string) $notice ), '+/', '-_' ), '=' );
	}

	/**
	 * بازکردن fallback URL پیام.
	 *
	 * @param string $notice مقدار URL.
	 * @return string
	 */
	private static function decode_notice( $notice ) {
		$notice = (string) $notice;
		if ( ! preg_match( '/^[A-Za-z0-9_-]+$/', $notice ) ) {
			return '';
		}
		$notice .= str_repeat( '=', ( 4 - strlen( $notice ) % 4 ) % 4 );
		$decoded = base64_decode( strtr( $notice, '-_', '+/' ), true );
		return false === $decoded ? '' : $decoded;
	}

	private static function redirect( $url, $msg = '', $type = 'success', $warnings = array() ) {
		if ( $msg ) {
			$notice = wp_json_encode(
				array(
					'type'     => $type,
					'msg'      => $msg,
					'warnings' => $warnings,
				)
			);
			set_transient( 'psyq_notice_' . get_current_user_id(), $notice, 60 );
			// transient بعضی میزبان‌ها/کش‌ها ممکن است در redirect در دسترس نباشد.
			// این fallback متن را فقط در URL مقصد مدیریت نگه می‌دارد و با esc_html چاپ می‌شود.
			$url = add_query_arg( 'psyq_notice', self::encode_notice( $notice ), $url );
		}
		wp_safe_redirect( $url );
		exit;
	}

	/* ==================================================================
	 * پردازش اکشن‌ها
	 * ================================================================== */

	public static function handle_action() {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( esc_html__( 'دسترسی مجاز نیست.', 'psyq' ) );
		}
		$action = isset( $_POST['psyq_action'] ) ? sanitize_key( wp_unslash( $_POST['psyq_action'] ) ) : '';
		if ( ! $action ) {
			$action = isset( $_GET['psyq_action'] ) ? sanitize_key( wp_unslash( $_GET['psyq_action'] ) ) : '';
		}
		check_admin_referer( 'psyq_action' );

		$form_id = isset( $_POST['form_id'] ) ? (int) $_POST['form_id'] : ( isset( $_GET['form_id'] ) ? (int) $_GET['form_id'] : 0 );

		switch ( $action ) {

			case 'save_form':
				$data = array(
					'title'                => sanitize_text_field( wp_unslash( $_POST['title'] ?? '' ) ),
					'code'                 => sanitize_text_field( wp_unslash( $_POST['code'] ?? '' ) ),
					'description'          => wp_kses_post( wp_unslash( $_POST['description'] ?? '' ) ),
					'status'               => sanitize_key( wp_unslash( $_POST['status'] ?? 'draft' ) ),
					'scoring_mode'         => sanitize_key( wp_unslash( $_POST['scoring_mode'] ?? 'option' ) ),
					'default_option_count' => max( 2, min( 10, (int) ( $_POST['default_option_count'] ?? 4 ) ) ),
					'randomize_options'    => empty( $_POST['randomize_options'] ) ? 0 : 1,
					'randomize_items'      => empty( $_POST['randomize_items'] ) ? 0 : 1,
					'items_per_page'       => max( 1, min( 400, (int) ( $_POST['items_per_page'] ?? 20 ) ) ),
					'require_all'          => empty( $_POST['require_all'] ) ? 0 : 1,
					'allow_back'           => empty( $_POST['allow_back'] ) ? 0 : 1,
					'collect_name'         => empty( $_POST['collect_name'] ) ? 0 : 1,
					'collect_demographics' => empty( $_POST['collect_demographics'] ) ? 0 : 1,
					'duration_minutes'     => (int) ( $_POST['duration_minutes'] ?? 0 ),
					'intro_html'           => wp_kses_post( wp_unslash( $_POST['intro_html'] ?? '' ) ),
					'consent_html'         => wp_kses_post( wp_unslash( $_POST['consent_html'] ?? '' ) ),
					'show_total'           => empty( $_POST['show_total'] ) ? 0 : 1,
					'total_subscale_id'    => (int) ( $_POST['total_subscale_id'] ?? 0 ),
					'show_charts'          => empty( $_POST['show_charts'] ) ? 0 : 1,
					'chart_engine'         => sanitize_key( wp_unslash( $_POST['chart_engine'] ?? 'both' ) ),
					'report_footer_html'   => wp_kses_post( wp_unslash( $_POST['report_footer_html'] ?? '' ) ),
				);
				if ( '' === $data['title'] ) {
					$data['title'] = __( 'پرسشنامه بدون عنوان', 'psyq' );
				}
				$new_id = PsyQ_DB::save_form( $data, $form_id );
				self::redirect( admin_url( 'admin.php?page=psyq-form&form_id=' . $new_id . '&tab=items' ), __( 'اطلاعات پرسشنامه ذخیره شد.', 'psyq' ) );
				break;

			case 'create_sample':
				$sample_type = PsyQ_Excel::sample_type( sanitize_key( wp_unslash( $_POST['sample_type'] ?? 'pas34' ) ) );
				$result = PsyQ_Excel::create_sample( 'draft', $sample_type );
				if ( is_wp_error( $result ) ) {
					self::redirect( admin_url( 'admin.php?page=psyq-form' ), $result->get_error_message(), 'error' );
				}
				$label = 'scasp38' === $sample_type ? __( 'SCAS-Parent: ۳۸ گویه نمره‌دار + سؤال باز اختیاری', 'psyq' ) : __( 'PAS والد: ۳۴ گویه نمره‌دار + شرح رویداد اختیاری', 'psyq' );
				self::redirect(
					admin_url( 'admin.php?page=psyq-form&form_id=' . $result['form_id'] . '&tab=items' ),
					sprintf( __( '%1$s ساخته شد: %2$d ردیف، %3$d زیرمقیاس و %4$d نقطه برش.', 'psyq' ), $label, $result['items'], $result['subs'], $result['bands'] ),
					'success',
					$result['warnings']
				);
				break;

			case 'delete_form':
				PsyQ_DB::delete_form( $form_id );
				self::redirect( admin_url( 'admin.php?page=psyq-forms' ), __( 'پرسشنامه حذف شد.', 'psyq' ) );
				break;

			case 'duplicate_form':
				$new = PsyQ_DB::duplicate_form( $form_id );
				self::redirect( admin_url( 'admin.php?page=psyq-forms' ), __( 'نسخه کپی ساخته شد.', 'psyq' ), 'success', $new ? array() : array( 'کپی ناموفق بود.' ) );
				break;

			case 'publish_form':
			case 'unpublish_form':
				$form = PsyQ_DB::get_form( $form_id );
				if ( $form ) {
					$data = (array) $form;
					$data['status'] = 'publish_form' === $action ? 'publish' : 'draft';
					PsyQ_DB::save_form( $data, $form_id );
				}
				self::redirect( admin_url( 'admin.php?page=psyq-forms' ), __( 'وضعیت پرسشنامه به‌روزرسانی شد.', 'psyq' ) );
				break;

			case 'bulk_add_options':
				// افزودن گزینه‌های یکسان به همه سوالات انتخاب‌شده.
				$item_ids = isset( $_POST['item_ids'] ) ? array_map( 'intval', (array) $_POST['item_ids'] ) : array();
				$labels   = isset( $_POST['opt_label'] ) ? (array) wp_unslash( $_POST['opt_label'] ) : array();
				$values   = isset( $_POST['opt_value'] ) ? (array) wp_unslash( $_POST['opt_value'] ) : array();
				$count    = 0;
				foreach ( $item_ids as $iid ) {
					global $wpdb;
					$wpdb->delete( PsyQ_DB::table( 'options' ), array( 'item_id' => $iid ) );
					$order = 0;
					foreach ( $labels as $k => $label ) {
						$label = sanitize_text_field( $label );
						if ( '' === $label ) {
							continue;
						}
						PsyQ_DB::save_option(
							$iid,
							$form_id,
							array(
								'label'      => $label,
								'value'      => max( -5, min( 7, PsyQ_Excel::num( $values[ $k ] ?? 0 ) ) ),
								'sort_order' => $order,
							)
						);
						$order++;
					}
					$wpdb->update( PsyQ_DB::table( 'items' ), array( 'option_count' => $order ), array( 'id' => $iid ) );
					$count++;
				}
				PsyQ_Scoring::clear_cache();
				$back = wp_get_referer() ? wp_get_referer() : admin_url( 'admin.php?page=psyq-form&form_id=' . $form_id . '&tab=items' );
				self::redirect( $back, sprintf( __( 'گزینه‌ها برای %d سوال اعمال شد.', 'psyq' ), $count ) );
				break;

			case 'delete_items':
				$item_ids = isset( $_POST['item_ids'] ) ? array_map( 'intval', (array) $_POST['item_ids'] ) : array();
				foreach ( $item_ids as $iid ) {
					PsyQ_DB::delete_item( $iid );
				}
				PsyQ_Scoring::clear_cache();
				$back = wp_get_referer() ? wp_get_referer() : admin_url( 'admin.php?page=psyq-form&form_id=' . $form_id . '&tab=items' );
				self::redirect( $back, sprintf( __( '%d سوال حذف شد.', 'psyq' ), count( $item_ids ) ) );
				break;

			case 'delete_response':
				PsyQ_DB::delete_response( $form_id );
				self::redirect( admin_url( 'admin.php?page=psyq-responses' ), __( 'پاسخ حذف شد.', 'psyq' ) );
				break;

			case 'rescore_response':
				$resp = PsyQ_DB::get_response( $form_id );
				if ( $resp ) {
					$answers = json_decode( (string) $resp->answers, true );
					$scores  = PsyQ_Scoring::score( (int) $resp->form_id, $answers ? $answers : array() );
					if ( ! is_wp_error( $scores ) ) {
						global $wpdb;
						$wpdb->update(
							PsyQ_DB::table( 'responses' ),
							array(
								'scores'    => wp_json_encode( $scores ),
								'raw_total' => $scores['grand_total'],
							),
							array( 'id' => $resp->id )
						);
					}
				}
				self::redirect( admin_url( 'admin.php?page=psyq-responses' ), __( 'نمرات بازمحاسبه شد.', 'psyq' ) );
				break;

			case 'save_settings':
				update_option( 'psyq_report_page', (int) ( $_POST['report_page'] ?? 0 ), false );
				update_option( 'psyq_brand_color', sanitize_hex_color( wp_unslash( $_POST['brand_color'] ?? '#4338ca' ) ), false );
				update_option( 'psyq_brand_logo', esc_url_raw( wp_unslash( $_POST['brand_logo'] ?? '' ) ), false );
				update_option( 'psyq_allow_guest', empty( $_POST['allow_guest'] ) ? 0 : 1, false );
				update_option( 'psyq_show_disclaimer', wp_kses_post( wp_unslash( $_POST['disclaimer'] ?? '' ) ), false );
				self::redirect( admin_url( 'admin.php?page=psyq-settings' ), __( 'تنظیمات ذخیره شد.', 'psyq' ) );
				break;

			default:
				self::redirect( admin_url( 'admin.php?page=psyq' ), __( 'درخواست نامعتبر.', 'psyq' ), 'error' );
		}
	}

	/**
	 * دانلود اکسل (قالب خام یا خروجی).
	 */
	public static function handle_excel() {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( esc_html__( 'دسترسی مجاز نیست.', 'psyq' ) );
		}
		check_admin_referer( 'psyq_excel' );

		$type    = isset( $_GET['type'] ) ? sanitize_key( wp_unslash( $_GET['type'] ) ) : 'template';
		$count   = isset( $_GET['count'] ) ? max( 2, min( PsyQ_Excel::MAX_OPTIONS, (int) $_GET['count'] ) ) : 4;
		$form_id = isset( $_GET['form_id'] ) ? (int) $_GET['form_id'] : 0;

		try {
			if ( 'export' === $type && $form_id ) {
				$form = PsyQ_DB::get_form( $form_id );
				if ( ! $form ) {
					wp_die( esc_html__( 'پرسشنامه یافت نشد.', 'psyq' ) );
				}
				$path     = PsyQ_Excel::build( $form->default_option_count, $form, 'export' );
				$filename = 'psyq-form-' . $form->id . '-' . $form->code . '.xlsx';
				PsyQ_Excel::stream( $path, $filename );
			}
			if ( 'results' === $type && $form_id ) {
				$path     = PsyQ_Excel::export_results( $form_id );
				$form     = PsyQ_DB::get_form( $form_id );
				$filename = 'psyq-results-' . ( $form ? $form->code : $form_id ) . '-' . date_i18n( 'Ymd' ) . '.xlsx';
				PsyQ_Excel::stream( $path, $filename );
			}
			if ( in_array( $type, array( 'sample', 'sample-pas', 'sample-scas' ), true ) ) {
				$sample_type = 'sample-scas' === $type ? 'scasp38' : 'pas34';
				$path = PsyQ_Excel::build_sample_file( $sample_type );
				$filename = 'scasp38' === $sample_type ? 'psyq-sample-scas-parent-38-items.xlsx' : 'psyq-sample-spence-pas-parent-34-items.xlsx';
				PsyQ_Excel::stream( $path, $filename );
			}
			$path = PsyQ_Excel::build( $count );
			PsyQ_Excel::stream( $path, 'psyq-template-' . $count . '-options.xlsx' );
		} catch ( Exception $e ) {
			wp_die( esc_html( $e->getMessage() ) );
		}
	}

	/**
	 * ورود فایل اکسل.
	 */
	public static function handle_import() {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( esc_html__( 'دسترسی مجاز نیست.', 'psyq' ) );
		}
		check_admin_referer( 'psyq_import' );

		$form_id = (int) ( $_POST['form_id'] ?? 0 );
		$mode    = sanitize_key( wp_unslash( $_POST['mode'] ?? 'new' ) );
		$status  = sanitize_key( wp_unslash( $_POST['status'] ?? 'draft' ) );

		$upload_error = isset( $_FILES['psyq_file']['error'] ) ? (int) $_FILES['psyq_file']['error'] : UPLOAD_ERR_NO_FILE; // phpcs:ignore
		if ( UPLOAD_ERR_OK !== $upload_error ) {
			self::redirect( admin_url( 'admin.php?page=psyq-import' ), self::upload_error_message( $upload_error ), 'error' );
		}
		if ( empty( $_FILES['psyq_file']['tmp_name'] ) ) {
			self::redirect( admin_url( 'admin.php?page=psyq-import' ), __( 'فایل بارگذاری‌شده در سرور پیدا نشد. دوباره تلاش کنید.', 'psyq' ), 'error' );
		}
		$file = $_FILES['psyq_file']['tmp_name']; // phpcs:ignore
		$name = sanitize_file_name( wp_unslash( $_FILES['psyq_file']['name'] ) );
		$ext  = strtolower( pathinfo( $name, PATHINFO_EXTENSION ) );
		if ( ! in_array( $ext, array( 'xlsx', 'xlsm' ), true ) ) {
			self::redirect( admin_url( 'admin.php?page=psyq-import' ), __( 'فقط فایل xlsx پشتیبانی می‌شود. فایل را در اکسل با فرمت «Excel Workbook (.xlsx)» ذخیره کنید.', 'psyq' ), 'error' );
		}

		// انتقال به مسیر امن موقت.
		$tmp = trailingslashit( get_temp_dir() ) . 'psyq-import-' . wp_generate_password( 8, false, false ) . '.xlsx';
		if ( ! @move_uploaded_file( $file, $tmp ) && ! @copy( $file, $tmp ) ) { // phpcs:ignore
			self::redirect( admin_url( 'admin.php?page=psyq-import' ), __( 'انتقال فایل ناموفق بود.', 'psyq' ), 'error' );
		}

		try {
			$result = PsyQ_Excel::import( $tmp, array( 'form_id' => $form_id, 'mode' => $mode, 'status' => $status ) );
		} catch ( Throwable $e ) {
			@unlink( $tmp ); // phpcs:ignore
			error_log( 'PsyQ import failed: ' . $e->getMessage() ); // phpcs:ignore WordPress has no logger wrapper.
			self::redirect( admin_url( 'admin.php?page=psyq-import' ), __( 'خطای غیرمنتظره‌ای هنگام خواندن فایل رخ داد. جزئیات در گزارش خطای سرور ثبت شده است.', 'psyq' ), 'error' );
		}
		@unlink( $tmp ); // phpcs:ignore

		if ( is_wp_error( $result ) ) {
			self::redirect( admin_url( 'admin.php?page=psyq-import' ), $result->get_error_message(), 'error' );
		}

		$msg = sprintf(
			__( 'ورود موفق: %1$d سوال، %2$d گزینه، %3$d زیرمقیاس و %4$d نقطه برش ثبت شد.', 'psyq' ),
			$result['items'],
			$result['options'],
			$result['subs'],
			$result['bands']
		);
		self::redirect( admin_url( 'admin.php?page=psyq-form&form_id=' . $result['form_id'] . '&tab=items' ), $msg, 'success', $result['warnings'] );
	}

	/**
	 * پیام قابل‌فهم برای خطای آپلود PHP.
	 *
	 * @param int $code کد UPLOAD_ERR_*.
	 * @return string
	 */
	private static function upload_error_message( $code ) {
		switch ( (int) $code ) {
			case UPLOAD_ERR_INI_SIZE:
			case UPLOAD_ERR_FORM_SIZE:
				return __( 'حجم فایل از سقف مجاز هاست بیشتر است. فایل را کوچک‌تر کنید یا محدودیت upload_max_filesize را افزایش دهید.', 'psyq' );
			case UPLOAD_ERR_PARTIAL:
				return __( 'فایل به‌طور کامل بارگذاری نشد. اتصال اینترنت را بررسی و دوباره تلاش کنید.', 'psyq' );
			case UPLOAD_ERR_NO_FILE:
				return __( 'فایلی انتخاب نشده است.', 'psyq' );
			case UPLOAD_ERR_NO_TMP_DIR:
				return __( 'پوشه موقت سرور برای بارگذاری فایل در دسترس نیست.', 'psyq' );
			case UPLOAD_ERR_CANT_WRITE:
				return __( 'سرور نتوانست فایل را روی دیسک ذخیره کند. دسترسی پوشه موقت را بررسی کنید.', 'psyq' );
			case UPLOAD_ERR_EXTENSION:
				return __( 'یک افزونه PHP بارگذاری فایل را متوقف کرده است.', 'psyq' );
			default:
				return __( 'بارگذاری فایل ناموفق بود. دوباره تلاش کنید.', 'psyq' );
		}
	}

	/* ==================================================================
	 * صفحات
	 * ================================================================== */

	private static function view( $file, $args = array() ) {
		$path = PSYQ_DIR . 'includes/admin/views/' . $file . '.php';
		if ( ! file_exists( $path ) ) {
			wp_die( 'View not found: ' . esc_html( $file ) );
		}
		$args = is_array( $args ) ? $args : array();
		extract( $args, EXTR_SKIP ); // phpcs:ignore
		include $path;
	}

	public static function page_dashboard() {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( esc_html__( 'دسترسی مجاز نیست.', 'psyq' ) );
		}
		$stats = PsyQ_DB::stats();
		$forms = PsyQ_DB::get_forms( array() );
		self::view( 'dashboard', array( 'stats' => $stats, 'forms' => $forms ) );
	}

	public static function page_forms() {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( esc_html__( 'دسترسی مجاز نیست.', 'psyq' ) );
		}
		$search = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : ''; // phpcs:ignore
		$forms  = PsyQ_DB::get_forms( array( 'search' => $search ) );
		self::view( 'forms', array( 'forms' => $forms, 'search' => $search ) );
	}

	public static function page_form() {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( esc_html__( 'دسترسی مجاز نیست.', 'psyq' ) );
		}
		$form_id = isset( $_GET['form_id'] ) ? (int) $_GET['form_id'] : 0; // phpcs:ignore
		$tab     = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'settings'; // phpcs:ignore

		if ( ! $form_id ) {
			self::view( 'form-new' );
			return;
		}
		$bundle = PsyQ_Scoring::bundle( $form_id );
		if ( ! $bundle ) {
			self::view( 'form-new' );
			return;
		}
		self::view( 'form-edit', array( 'bundle' => $bundle, 'tab' => $tab ) );
	}

	public static function page_import() {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( esc_html__( 'دسترسی مجاز نیست.', 'psyq' ) );
		}
		$forms = PsyQ_DB::get_forms();
		self::view( 'import', array( 'forms' => $forms ) );
	}

	public static function page_templates() {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( esc_html__( 'دسترسی مجاز نیست.', 'psyq' ) );
		}
		self::view( 'templates', array() );
	}

	public static function page_responses() {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( esc_html__( 'دسترسی مجاز نیست.', 'psyq' ) );
		}
		$form_id = isset( $_GET['form_id'] ) ? (int) $_GET['form_id'] : 0; // phpcs:ignore
		$search  = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : ''; // phpcs:ignore
		$paged   = isset( $_GET['paged'] ) ? max( 1, (int) $_GET['paged'] ) : 1; // phpcs:ignore

		$per_page = 30;
		$args     = array( 'form_id' => $form_id, 'search' => $search, 'limit' => $per_page, 'page' => $paged );
		$rows     = PsyQ_DB::get_responses( $args );
		$total    = PsyQ_DB::count_responses( array( 'form_id' => $form_id, 'search' => $search ) );
		$forms    = PsyQ_DB::get_forms();
		$subs     = $form_id ? PsyQ_DB::get_subscales( $form_id ) : array();

		self::view(
			'responses',
			array(
				'rows'      => $rows,
				'total'     => $total,
				'paged'     => $paged,
				'per_page'  => $per_page,
				'forms'     => $forms,
				'form_id'   => $form_id,
				'search'    => $search,
				'subs'      => $subs,
			)
		);
	}

	public static function page_report() {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( esc_html__( 'دسترسی مجاز نیست.', 'psyq' ) );
		}
		$response_id = isset( $_GET['response_id'] ) ? (int) $_GET['response_id'] : 0; // phpcs:ignore
		$response    = $response_id ? PsyQ_DB::get_response( $response_id ) : null;
		if ( ! $response ) {
			self::view( 'report', array( 'response' => null, 'html' => '', 'scores' => null, 'form' => null ) );
			return;
		}
		$form   = PsyQ_DB::get_form( (int) $response->form_id );
		$scores = json_decode( (string) $response->scores, true );
		if ( empty( $scores ) ) {
			$answers = json_decode( (string) $response->answers, true );
			$scores  = PsyQ_Scoring::score( (int) $response->form_id, $answers ? $answers : array() );
		}
		$html = is_array( $scores ) ? PsyQ_Scoring::render_report( (int) $response->form_id, $scores, array( 'response' => $response, 'context' => 'admin', 'answers_table' => true ) ) : '';
		self::view(
			'report',
			array(
				'response' => $response,
				'html'     => $html,
				'scores'   => $scores,
				'form'     => $form,
			)
		);
	}

	public static function page_settings() {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( esc_html__( 'دسترسی مجاز نیست.', 'psyq' ) );
		}
		self::view(
			'settings',
			array(
				'report_page'  => (int) get_option( 'psyq_report_page', 0 ),
				'brand_color'  => get_option( 'psyq_brand_color', '#4338ca' ),
				'brand_logo'   => get_option( 'psyq_brand_logo', '' ),
				'allow_guest'  => (int) get_option( 'psyq_allow_guest', 1 ),
				'disclaimer'   => get_option( 'psyq_show_disclaimer', '' ),
			)
		);
	}
}
