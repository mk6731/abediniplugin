<?php
/**
 * لایه داده: جدول‌ها و CRUD.
 *
 * @package PsyQ
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class PsyQ_DB {

	/**
	 * نام جدول‌ها.
	 */
	public static function table( $name ) {
		global $wpdb;
		return $wpdb->prefix . 'psyq_' . $name;
	}

	/**
	 * ساخت جدول‌ها.
	 */
	public static function install() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$charset = $wpdb->get_charset_collate();

		$forms   = self::table( 'forms' );
		$subs    = self::table( 'subscales' );
		$bands   = self::table( 'bands' );
		$items   = self::table( 'items' );
		$options = self::table( 'options' );
		$resp    = self::table( 'responses' );

		$sql = array();

		$sql[] = "CREATE TABLE {$forms} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			code VARCHAR(64) NOT NULL DEFAULT '',
			title VARCHAR(255) NOT NULL DEFAULT '',
			description LONGTEXT NULL,
			slug VARCHAR(191) NOT NULL DEFAULT '',
			family_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			version VARCHAR(32) NOT NULL DEFAULT '1',
			status VARCHAR(20) NOT NULL DEFAULT 'draft',
			scoring_mode VARCHAR(20) NOT NULL DEFAULT 'option',
			default_option_count TINYINT UNSIGNED NOT NULL DEFAULT 4,
			randomize_options TINYINT(1) NOT NULL DEFAULT 0,
			randomize_items TINYINT(1) NOT NULL DEFAULT 0,
			items_per_page SMALLINT UNSIGNED NOT NULL DEFAULT 20,
			require_all TINYINT(1) NOT NULL DEFAULT 1,
			allow_back TINYINT(1) NOT NULL DEFAULT 1,
			collect_name TINYINT(1) NOT NULL DEFAULT 1,
			collect_demographics TINYINT(1) NOT NULL DEFAULT 1,
			duration_minutes SMALLINT UNSIGNED NOT NULL DEFAULT 0,
			intro_html LONGTEXT NULL,
			consent_html LONGTEXT NULL,
			show_total TINYINT(1) NOT NULL DEFAULT 1,
			total_subscale_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			show_charts TINYINT(1) NOT NULL DEFAULT 1,
			chart_engine VARCHAR(20) NOT NULL DEFAULT 'both',
			report_footer_html LONGTEXT NULL,
			created_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			updated_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			KEY status (status),
			KEY family_id (family_id),
			KEY slug (slug)
		) {$charset};";

		$sql[] = "CREATE TABLE {$subs} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			form_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			name VARCHAR(191) NOT NULL DEFAULT '',
			title VARCHAR(255) NOT NULL DEFAULT '',
			description LONGTEXT NULL,
			color VARCHAR(20) NOT NULL DEFAULT '#4f46e5',
			sort_order SMALLINT NOT NULL DEFAULT 0,
			include_in_total TINYINT(1) NOT NULL DEFAULT 1,
			PRIMARY KEY  (id),
			KEY form_id (form_id)
		) {$charset};";

		$sql[] = "CREATE TABLE {$bands} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			subscale_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			form_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			sort_order TINYINT NOT NULL DEFAULT 0,
			min_value DECIMAL(10,2) NOT NULL DEFAULT 0,
			max_value DECIMAL(10,2) NOT NULL DEFAULT 0,
			label VARCHAR(191) NOT NULL DEFAULT '',
			severity VARCHAR(30) NOT NULL DEFAULT 'normal',
			color VARCHAR(20) NOT NULL DEFAULT '#22c55e',
			interpretation LONGTEXT NULL,
			PRIMARY KEY  (id),
			KEY subscale_id (subscale_id)
		) {$charset};";

		$sql[] = "CREATE TABLE {$items} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			form_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			number INT NOT NULL DEFAULT 0,
			sort_order INT NOT NULL DEFAULT 0,
			text LONGTEXT NULL,
			answer_type VARCHAR(20) NOT NULL DEFAULT 'choice',
			image_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			image_url VARCHAR(500) NOT NULL DEFAULT '',
			subscale_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			option_count TINYINT UNSIGNED NOT NULL DEFAULT 0,
			scoring VARCHAR(20) NOT NULL DEFAULT 'inherit',
			reverse TINYINT(1) NOT NULL DEFAULT 0,
			reversed TINYINT(1) NOT NULL DEFAULT 0,
			is_required TINYINT(1) NOT NULL DEFAULT 1,
			condition TEXT NULL,
			note TEXT NULL,
			PRIMARY KEY  (id),
			KEY form_id (form_id),
			KEY subscale_id (subscale_id)
		) {$charset};";

		$sql[] = "CREATE TABLE {$options} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			item_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			form_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			sort_order TINYINT NOT NULL DEFAULT 0,
			label VARCHAR(255) NOT NULL DEFAULT '',
			value DECIMAL(10,2) NOT NULL DEFAULT 0,
			image_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			image_url VARCHAR(500) NOT NULL DEFAULT '',
			PRIMARY KEY  (id),
			KEY item_id (item_id),
			KEY form_id (form_id)
		) {$charset};";

		$sql[] = "CREATE TABLE {$resp} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			form_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			guest_token VARCHAR(64) NOT NULL DEFAULT '',
			first_name VARCHAR(191) NOT NULL DEFAULT '',
			last_name VARCHAR(191) NOT NULL DEFAULT '',
			gender VARCHAR(20) NOT NULL DEFAULT '',
			age SMALLINT UNSIGNED NOT NULL DEFAULT 0,
			education VARCHAR(191) NOT NULL DEFAULT '',
			phone VARCHAR(50) NOT NULL DEFAULT '',
			email VARCHAR(191) NOT NULL DEFAULT '',
			answers LONGTEXT NULL,
			raw_total DECIMAL(12,2) NOT NULL DEFAULT 0,
			scores LONGTEXT NULL,
			report_html LONGTEXT NULL,
			duration_sec INT UNSIGNED NOT NULL DEFAULT 0,
			ip VARCHAR(64) NOT NULL DEFAULT '',
			user_agent VARCHAR(255) NOT NULL DEFAULT '',
			created_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			KEY form_id (form_id),
			KEY user_id (user_id),
			KEY guest_token (guest_token),
			KEY created_at (created_at)
		) {$charset};";

		foreach ( $sql as $q ) {
			dbDelta( $q );
		}

		// بعضی نصب‌های قدیمی ممکن است هنگام ارتقا با dbDelta ستون جدید را
		// دریافت نکرده باشند. این بررسی محافظه‌کارانه مانع از شکست خاموش
		// ورود سؤال‌ها در آن نصب‌ها می‌شود.
		self::ensure_item_answer_type_column();
	}

	/**
	 * آیا ستون نوع پاسخ در جدول سؤال‌ها وجود دارد؟
	 *
	 * @return bool
	 */
	private static function has_item_answer_type_column() {
		global $wpdb;
		$items = self::table( 'items' );
		$items = str_replace( '`', '', $items );
		$column = $wpdb->get_var( "SHOW COLUMNS FROM `{$items}` LIKE 'answer_type'" );
		return 'answer_type' === $column;
	}

	/**
	 * اطمینان از وجود ستون answer_type در نصب‌های ارتقایافته.
	 *
	 * dbDelta معمولاً این کار را انجام می‌دهد؛ ALTER صریح فقط fallback است.
	 * در صورت خطا false برمی‌گردد تا در درخواست‌های بعدی هم دوباره تلاش شود.
	 *
	 * @return bool
	 */
	private static function ensure_item_answer_type_column() {
		global $wpdb;
		if ( self::has_item_answer_type_column() ) {
			return true;
		}
		$items = str_replace( '`', '', self::table( 'items' ) );
		$result = $wpdb->query( "ALTER TABLE `{$items}` ADD COLUMN `answer_type` VARCHAR(20) NOT NULL DEFAULT 'choice' AFTER `text`" );
		if ( false === $result ) {
			return false;
		}
		return self::has_item_answer_type_column();
	}

	/**
	 * ارتقای خودکار ساختار.
	 */
	public static function maybe_upgrade() {
		if ( get_option( 'psyq_db_version' ) !== PSYQ_DB_VERSION ) {
			self::install();
			update_option( 'psyq_db_version', PSYQ_DB_VERSION, false );
			return;
		}

		// اگر نصب قبلی به‌اشتباه نسخه جدید را ثبت کرده اما ستون را ندارد،
		// بدون نیاز به غیرفعال‌سازی افزونه ترمیمش کن.
		self::ensure_item_answer_type_column();
	}

	/**
	 * حالت امتیازدهی پیش‌فرض قالب‌ها.
	 *
	 * @return array
	 */
	public static function scoring_modes() {
		return array(
			'option'  => __( 'امتیاز برای هر گزینه (لیکرت)', 'psyq' ),
			'item'    => __( 'امتیاز برای هر سوال (بدون امتیاز گزینه‌ای)', 'psyq' ),
			'mixed'   => __( 'ترکیبی — هر سوال جداگانه', 'psyq' ),
		);
	}

	/**
	 * انواع گزینه پیش‌فرض (فقط برای ساخت سریع گزینه‌ها).
	 *
	 * @return array
	 */
	public static function option_presets() {
		$p = array();
		$p[2] = array( 'بله', 'خیر' );
		$p[3] = array( 'بله', 'تا حدودی', 'خیر' );
		$p[4] = array( 'اصلاً', 'کمی', 'زیاد', 'خیلی زیاد' );
		$p[5] = array( 'اصلاً', 'کمی', 'تا حدودی', 'زیاد', 'خیلی زیاد' );
		$p[6] = array( 'کاملاً مخالفم', 'مخالفم', 'تا حدودی مخالفم', 'تا حدودی موافقم', 'موافقم', 'کاملاً موافقم' );
		$p[7] = array( 'کاملاً مخالفم', 'مخالفم', 'تا حدودی مخالفم', 'نظری ندارم', 'تا حدودی موافقم', 'موافقم', 'کاملاً موافقم' );

		/**
		 * افزودن قالب‌های گزینه‌ای دلخواه.
		 *
		 * @param array $p قالب‌ها.
		 */
		return apply_filters( 'psyq_option_presets', $p );
	}

	/* ------------------------------------------------------------------
	 * فرم‌ها
	 * ------------------------------------------------------------------ */

	public static function get_forms( $args = array() ) {
		global $wpdb;
		$t   = self::table( 'forms' );
		$sql = "SELECT * FROM {$t} WHERE 1=1";
		if ( ! empty( $args['status'] ) ) {
			$sql .= $wpdb->prepare( ' AND status = %s', $args['status'] );
		}
		if ( ! empty( $args['search'] ) ) {
			$like = '%' . $wpdb->esc_like( $args['search'] ) . '%';
			$sql .= $wpdb->prepare( ' AND (title LIKE %s OR code LIKE %s)', $like, $like );
		}
		$sql .= ' ORDER BY id DESC';
		return $wpdb->get_results( $sql );
	}

	public static function get_form( $id ) {
		global $wpdb;
		$t = self::table( 'forms' );
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id = %d", $id ) );
	}

	public static function get_form_by_code( $code ) {
		global $wpdb;
		$t = self::table( 'forms' );
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE code = %s", $code ) );
	}

	public static function save_form( $data, $id = 0 ) {
		global $wpdb;
		$t       = self::table( 'forms' );
		$now     = current_time( 'mysql' );
		$defaults = array(
			'code'                 => '',
			'title'                => '',
			'description'          => '',
			'family_id'            => 0,
			'version'              => '1',
			'status'               => 'draft',
			'scoring_mode'         => 'option',
			'default_option_count' => 4,
			'randomize_options'    => 0,
			'randomize_items'      => 0,
			'items_per_page'       => 20,
			'require_all'          => 1,
			'allow_back'           => 1,
			'collect_name'         => 1,
			'collect_demographics' => 1,
			'duration_minutes'     => 0,
			'intro_html'           => '',
			'consent_html'         => '',
			'show_total'           => 1,
			'total_subscale_id'    => 0,
			'show_charts'          => 1,
			'chart_engine'         => 'both',
			'report_footer_html'   => '',
		);
		$data = wp_parse_args( $data, $defaults );

		// یکتا کردن slug.
		$base = sanitize_title( $data['code'] ? $data['code'] : $data['title'] );
		$base = $base ? $base : 'psyq-form';
		$slug = $base;
		$i    = 2;
		while ( true ) {
			$exists = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t} WHERE slug = %s AND id <> %d", $slug, $id ) );
			if ( ! $exists ) {
				break;
			}
			$slug = $base . '-' . $i;
			$i++;
		}
		$data['slug'] = $slug;

		$fields = array(
			'code'                 => '%s',
			'title'                => '%s',
			'description'          => '%s',
			'slug'                 => '%s',
			'family_id'            => '%d',
			'version'              => '%s',
			'status'               => '%s',
			'scoring_mode'         => '%s',
			'default_option_count' => '%d',
			'randomize_options'    => '%d',
			'randomize_items'      => '%d',
			'items_per_page'       => '%d',
			'require_all'          => '%d',
			'allow_back'           => '%d',
			'collect_name'         => '%d',
			'collect_demographics' => '%d',
			'duration_minutes'     => '%d',
			'intro_html'           => '%s',
			'consent_html'         => '%s',
			'show_total'           => '%d',
			'total_subscale_id'    => '%d',
			'show_charts'          => '%d',
			'chart_engine'         => '%s',
			'report_footer_html'   => '%s',
		);
		$row = array();
		foreach ( $fields as $k => $f ) {
			$row[ $k ] = $data[ $k ];
		}
		$row['updated_at'] = $now;

		if ( $id ) {
			$wpdb->update( $t, $row, array( 'id' => $id ) );
			return $id;
		}
		$row['created_at'] = $now;
		$wpdb->insert( $t, $row );
		return (int) $wpdb->insert_id;
	}

	public static function delete_form( $id ) {
		global $wpdb;
		$id = (int) $id;
		$wpdb->delete( self::table( 'forms' ), array( 'id' => $id ) );
		$wpdb->delete( self::table( 'subscales' ), array( 'form_id' => $id ) );
		$wpdb->delete( self::table( 'bands' ), array( 'form_id' => $id ) );
		$item_ids = $wpdb->get_col( $wpdb->prepare( 'SELECT id FROM ' . self::table( 'items' ) . ' WHERE form_id = %d', $id ) );
		foreach ( $item_ids as $iid ) {
			$wpdb->delete( self::table( 'options' ), array( 'item_id' => (int) $iid ) );
		}
		$wpdb->delete( self::table( 'items' ), array( 'form_id' => $id ) );
	}

	public static function duplicate_form( $id ) {
		$form = self::get_form( $id );
		if ( ! $form ) {
			return 0;
		}
		$data = (array) $form;
		unset( $data['id'], $data['created_at'], $data['updated_at'] );
		$data['title']  = $data['title'] . ' (کپی)';
		$data['code']   = $data['code'] . '-copy';
		$data['status'] = 'draft';
		$new_id         = self::save_form( $data );

		$map = array();
		foreach ( self::get_subscales( $id ) as $s ) {
			$old = $s->id;
			$sid = self::save_subscale( $new_id, (array) $s );
			$map[ $old ] = $sid;
		}
		foreach ( self::get_items( $id ) as $it ) {
			$item = (array) $it;
			unset( $item['id'], $item['form_id'] );
			$item['subscale_id'] = isset( $map[ (int) $it->subscale_id ] ) ? $map[ (int) $it->subscale_id ] : 0;
			$opts                = self::get_options( $it->id );
			$new_item            = self::save_item( $new_id, $item );
			foreach ( $opts as $o ) {
				$od = (array) $o;
				unset( $od['id'], $od['form_id'], $od['item_id'] );
				self::save_option( $new_item, $new_id, $od );
			}
		}
		return $new_id;
	}

	/* ------------------------------------------------------------------
	 * زیرمقیاس‌ها
	 * ------------------------------------------------------------------ */

	public static function get_subscales( $form_id, $include_hidden = false ) {
		global $wpdb;
		$t   = self::table( 'subscales' );
		$sql = $wpdb->prepare( "SELECT * FROM {$t} WHERE form_id = %d", $form_id );
		if ( ! $include_hidden ) {
			$sql .= " AND name NOT LIKE '\\_\\_%'";
		}
		$sql .= ' ORDER BY sort_order ASC, id ASC';
		return $wpdb->get_results( $sql );
	}

	/**
	 * زیرمقیاس مخفی «نمره کل».
	 */
	public static function get_total_subscale( $form_id ) {
		global $wpdb;
		$t = self::table( 'subscales' );
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE form_id = %d AND name = %s", $form_id, '__TOTAL__' ) );
	}

	public static function get_subscale( $id ) {
		global $wpdb;
		$t = self::table( 'subscales' );
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id = %d", $id ) );
	}

	public static function save_subscale( $form_id, $data, $id = 0 ) {
		global $wpdb;
		$t   = self::table( 'subscales' );
		$row = array(
			'form_id'          => (int) $form_id,
			'name'             => isset( $data['name'] ) ? $data['name'] : '',
			'title'            => isset( $data['title'] ) ? $data['title'] : '',
			'description'      => isset( $data['description'] ) ? $data['description'] : '',
			'color'            => isset( $data['color'] ) && $data['color'] ? $data['color'] : '#4f46e5',
			'sort_order'       => isset( $data['sort_order'] ) ? (int) $data['sort_order'] : 0,
			'include_in_total' => isset( $data['include_in_total'] ) ? (int) $data['include_in_total'] : 1,
		);
		if ( $id ) {
			$wpdb->update( $t, $row, array( 'id' => $id ) );
			return $id;
		}
		$wpdb->insert( $t, $row );
		return (int) $wpdb->insert_id;
	}

	public static function delete_subscale( $id ) {
		global $wpdb;
		$id = (int) $id;
		$wpdb->delete( self::table( 'subscales' ), array( 'id' => $id ) );
		$wpdb->delete( self::table( 'bands' ), array( 'subscale_id' => $id ) );
		$wpdb->query( $wpdb->prepare( 'UPDATE ' . self::table( 'items' ) . ' SET subscale_id = 0 WHERE subscale_id = %d', $id ) );
	}

	/* ------------------------------------------------------------------
	 * نقاط برش
	 * ------------------------------------------------------------------ */

	public static function get_bands( $subscale_id ) {
		global $wpdb;
		$t = self::table( 'bands' );
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t} WHERE subscale_id = %d ORDER BY sort_order ASC, id ASC", $subscale_id ) );
	}

	public static function delete_bands( $subscale_id ) {
		global $wpdb;
		$wpdb->delete( self::table( 'bands' ), array( 'subscale_id' => (int) $subscale_id ) );
	}

	public static function save_band( $form_id, $subscale_id, $data, $order = 0 ) {
		global $wpdb;
		$t   = self::table( 'bands' );
		$row = array(
			'form_id'        => (int) $form_id,
			'subscale_id'    => (int) $subscale_id,
			'sort_order'     => (int) $order,
			'min_value'      => isset( $data['min_value'] ) ? (float) $data['min_value'] : 0,
			'max_value'      => isset( $data['max_value'] ) ? (float) $data['max_value'] : 0,
			'label'          => isset( $data['label'] ) ? $data['label'] : '',
			'severity'       => isset( $data['severity'] ) ? $data['severity'] : 'normal',
			'color'          => isset( $data['color'] ) && $data['color'] ? $data['color'] : '#22c55e',
			'interpretation' => isset( $data['interpretation'] ) ? $data['interpretation'] : '',
		);
		$wpdb->insert( $t, $row );
		return (int) $wpdb->insert_id;
	}

	/* ------------------------------------------------------------------
	 * سوالات
	 * ------------------------------------------------------------------ */

	public static function get_items( $form_id ) {
		global $wpdb;
		$t = self::table( 'items' );
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t} WHERE form_id = %d ORDER BY sort_order ASC, id ASC", $form_id ) );
	}

	public static function get_item( $id ) {
		global $wpdb;
		$t = self::table( 'items' );
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id = %d", $id ) );
	}

	public static function save_item( $form_id, $data, $id = 0 ) {
		global $wpdb;
		$t = self::table( 'items' );

		$reverse  = isset( $data['reverse'] ) ? (int) ! empty( $data['reverse'] ) : 0;
		$reversed = isset( $data['reversed'] ) ? (int) ! empty( $data['reversed'] ) : 0;
		if ( ! empty( $data['id_reversed'] ) ) {
			$reversed = (int) $data['id_reversed'];
		}
		if ( $reverse && $reversed ) { // فرمول وارونه‌سازی بر اساس شناسه.
			$reverse = 1;
		}

		$row = array(
			'form_id'      => (int) $form_id,
			'number'       => isset( $data['number'] ) ? (int) $data['number'] : 0,
			'sort_order'   => isset( $data['sort_order'] ) ? (int) $data['sort_order'] : 0,
			'text'         => isset( $data['text'] ) ? $data['text'] : '',
			'answer_type'  => isset( $data['answer_type'] ) && 'text' === $data['answer_type'] ? 'text' : 'choice',
			'image_id'     => isset( $data['image_id'] ) ? (int) $data['image_id'] : 0,
			'image_url'    => isset( $data['image_url'] ) ? $data['image_url'] : '',
			'subscale_id'  => isset( $data['subscale_id'] ) ? (int) $data['subscale_id'] : 0,
			'option_count' => isset( $data['option_count'] ) ? (int) $data['option_count'] : 0,
			'scoring'      => isset( $data['scoring'] ) && $data['scoring'] ? $data['scoring'] : 'inherit',
			'reverse'      => $reverse,
			'reversed'     => $reversed,
			'is_required'  => isset( $data['is_required'] ) ? (int) $data['is_required'] : 1,
			'condition'    => isset( $data['condition'] ) ? $data['condition'] : '',
			'note'         => isset( $data['note'] ) ? $data['note'] : '',
		);

		if ( $id ) {
			$result = $wpdb->update( $t, $row, array( 'id' => $id ) );
			return false === $result ? 0 : $id;
		}
		$result = $wpdb->insert( $t, $row );
		return false === $result ? 0 : (int) $wpdb->insert_id;
	}

	public static function delete_item( $id ) {
		global $wpdb;
		$id = (int) $id;
		$wpdb->delete( self::table( 'options' ), array( 'item_id' => $id ) );
		$wpdb->delete( self::table( 'items' ), array( 'id' => $id ) );
	}

	/**
	 * پاک کردن کامل سوالات و گزینه‌های یک پرسشنامه (برای بازخوانی اکسل).
	 */
	public static function clear_items( $form_id ) {
		global $wpdb;
		$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . self::table( 'options' ) . ' WHERE form_id = %d', $form_id ) );
		$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . self::table( 'items' ) . ' WHERE form_id = %d', $form_id ) );
		delete_transient( 'psyq_thumb_' . $form_id );
	}

	/* ------------------------------------------------------------------
	 * گزینه‌ها
	 * ------------------------------------------------------------------ */

	public static function get_options( $item_id ) {
		global $wpdb;
		$t = self::table( 'options' );
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t} WHERE item_id = %d ORDER BY sort_order ASC, id ASC", $item_id ) );
	}

	public static function get_options_for_form( $form_id ) {
		global $wpdb;
		$t = self::table( 'options' );
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t} WHERE form_id = %d ORDER BY item_id ASC, sort_order ASC", $form_id ) );
	}

	public static function save_option( $item_id, $form_id, $data, $id = 0 ) {
		global $wpdb;
		$t   = self::table( 'options' );
		$row = array(
			'item_id'    => (int) $item_id,
			'form_id'    => (int) $form_id,
			'sort_order' => isset( $data['sort_order'] ) ? (int) $data['sort_order'] : 0,
			'label'      => isset( $data['label'] ) ? $data['label'] : '',
			'value'      => isset( $data['value'] ) ? (float) $data['value'] : 0,
			'image_id'   => isset( $data['image_id'] ) ? (int) $data['image_id'] : 0,
			'image_url'  => isset( $data['image_url'] ) ? $data['image_url'] : '',
		);
		if ( $id ) {
			$wpdb->update( $t, $row, array( 'id' => $id ) );
			return $id;
		}
		$wpdb->insert( $t, $row );
		return (int) $wpdb->insert_id;
	}

	public static function delete_option( $id ) {
		global $wpdb;
		$wpdb->delete( self::table( 'options' ), array( 'id' => (int) $id ) );
	}

	/* ------------------------------------------------------------------
	 * پاسخ‌ها
	 * ------------------------------------------------------------------ */

	public static function save_response( $data ) {
		global $wpdb;
		$t   = self::table( 'responses' );
		$row = array(
			'form_id'     => (int) $data['form_id'],
			'user_id'     => get_current_user_id(),
			'guest_token' => isset( $data['guest_token'] ) ? $data['guest_token'] : '',
			'first_name'  => isset( $data['first_name'] ) ? $data['first_name'] : '',
			'last_name'   => isset( $data['last_name'] ) ? $data['last_name'] : '',
			'gender'      => isset( $data['gender'] ) ? $data['gender'] : '',
			'age'         => isset( $data['age'] ) ? (int) $data['age'] : 0,
			'education'   => isset( $data['education'] ) ? $data['education'] : '',
			'phone'       => isset( $data['phone'] ) ? $data['phone'] : '',
			'email'       => isset( $data['email'] ) ? $data['email'] : '',
			'answers'     => wp_json_encode( isset( $data['answers'] ) ? $data['answers'] : array() ),
			'raw_total'   => isset( $data['raw_total'] ) ? $data['raw_total'] : 0,
			'scores'      => wp_json_encode( isset( $data['scores'] ) ? $data['scores'] : array() ),
			'duration_sec' => isset( $data['duration_sec'] ) ? (int) $data['duration_sec'] : 0,
			'ip'          => isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '',
			'user_agent'  => isset( $_SERVER['HTTP_USER_AGENT'] ) ? substr( sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ), 0, 250 ) : '',
			'created_at'  => current_time( 'mysql' ),
		);
		$wpdb->insert( $t, $row );
		$id = (int) $wpdb->insert_id;

		if ( $id && ! $row['guest_token'] ) {
			$token = wp_generate_password( 32, false, false );
			$wpdb->update( $t, array( 'guest_token' => $token ), array( 'id' => $id ) );
			$row['guest_token'] = $token;
		}
		return array( 'id' => $id, 'token' => $row['guest_token'] );
	}

	public static function update_response_report( $id, $report_html ) {
		global $wpdb;
		$wpdb->update( self::table( 'responses' ), array( 'report_html' => $report_html ), array( 'id' => (int) $id ) );
	}

	public static function get_response( $id ) {
		global $wpdb;
		$t = self::table( 'responses' );
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id = %d", $id ) );
	}

	public static function get_responses( $args = array() ) {
		global $wpdb;
		$t   = self::table( 'responses' );
		$sql = "SELECT * FROM {$t} WHERE 1=1";
		if ( ! empty( $args['form_id'] ) ) {
			$sql .= $wpdb->prepare( ' AND form_id = %d', $args['form_id'] );
		}
		if ( ! empty( $args['search'] ) ) {
			$like = '%' . $wpdb->esc_like( $args['search'] ) . '%';
			$sql .= $wpdb->prepare( ' AND (first_name LIKE %s OR last_name LIKE %s OR phone LIKE %s OR email LIKE %s)', $like, $like, $like, $like );
		}
		$sql .= ' ORDER BY id DESC';
		$limit = isset( $args['limit'] ) ? (int) $args['limit'] : 50;
		$page  = isset( $args['page'] ) && $args['page'] > 0 ? (int) $args['page'] : 1;
		$sql  .= $wpdb->prepare( ' LIMIT %d OFFSET %d', $limit, ( $page - 1 ) * $limit );
		return $wpdb->get_results( $sql );
	}

	public static function count_responses( $args = array() ) {
		global $wpdb;
		$t   = self::table( 'responses' );
		$sql = "SELECT COUNT(*) FROM {$t} WHERE 1=1";
		if ( ! empty( $args['form_id'] ) ) {
			$sql .= $wpdb->prepare( ' AND form_id = %d', $args['form_id'] );
		}
		if ( ! empty( $args['search'] ) ) {
			$like = '%' . $wpdb->esc_like( $args['search'] ) . '%';
			$sql .= $wpdb->prepare( ' AND (first_name LIKE %s OR last_name LIKE %s OR phone LIKE %s OR email LIKE %s)', $like, $like, $like, $like );
		}
		return (int) $wpdb->get_var( $sql );
	}

	public static function delete_response( $id ) {
		global $wpdb;
		$wpdb->delete( self::table( 'responses' ), array( 'id' => (int) $id ) );
	}

	/* ------------------------------------------------------------------
	 * آمار کلی
	 * ------------------------------------------------------------------ */

	public static function stats() {
		global $wpdb;
		$forms = self::table( 'forms' );
		$items = self::table( 'items' );
		$resp  = self::table( 'responses' );
		return array(
			'forms'      => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$forms}" ),
			'published'  => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$forms} WHERE status = 'publish'" ),
			'items'      => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$items}" ),
			'responses'  => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$resp}" ),
			'today'      => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$resp} WHERE DATE(created_at) = %s", current_time( 'Y-m-d' ) ) ),
		);
	}
}
