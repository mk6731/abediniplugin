<?php
/**
 * تولید نمودار میله‌ای و هیستوگرام به صورت SVG بومی + داده Chart.js.
 *
 * @package PsyQ
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class PsyQ_Charts {

	/**
	 * داده نمودار میله‌ای برای Chart.js.
	 *
	 * @param array      $subs  زیرمقیاس‌ها.
	 * @param array|null $total نمره کل.
	 * @param object|null $form فرم.
	 * @return array
	 */
	public static function bar_data( $subs, $total = null, $form = null ) {
		$labels = array();
		$scores = array();
		$maxes  = array();
		$colors = array();
		$levels = array();

		foreach ( $subs as $s ) {
			$labels[] = $s['title'];
			$scores[] = (float) $s['score'];
			$maxes[]  = (float) $s['max'];
			$colors[] = $s['band'] ? $s['band']['color'] : $s['color'];
			$levels[] = $s['band'] ? $s['band']['label'] : '';
		}
		if ( $total ) {
			$labels[] = $total['title'];
			$scores[] = (float) $total['score'];
			$maxes[]  = (float) $total['max'];
			$colors[] = $total['band'] ? $total['band']['color'] : $total['color'];
			$levels[] = $total['band'] ? $total['band']['label'] : '';
		}

		return array(
			'type' => 'bar',
			'labels' => $labels,
			'scores' => $scores,
			'maxes'  => $maxes,
			'colors' => $colors,
			'levels' => $levels,
		);
	}

	/**
	 * نمودار میله‌ای SVG (مستقل، قابل چاپ).
	 *
	 * @param array      $subs  زیرمقیاس‌ها.
	 * @param array|null $total نمره کل.
	 * @return string
	 */
	public static function bar_svg( $subs, $total = null ) {
		$data = self::bar_data( $subs, $total );
		return self::render_bar_svg( $data, __( 'نمره هر زیرمقیاس', 'psyq' ) );
	}

	/**
	 * ساخت SVG میله‌ای.
	 *
	 * @param array  $data   داده.
	 * @param string $title  عنوان.
	 * @param bool   $grouped آیا دو سری (درصد و خام) رسم شود.
	 * @return string
	 */
	public static function render_bar_svg( $data, $title = '', $grouped = false ) {
		$labels = $data['labels'];
		$scores = $data['scores'];
		$maxes  = $data['maxes'];
		$colors = $data['colors'];

		$n = max( 1, count( $labels ) );
		$row_h     = 46;
		$pad_top   = 46;
		$pad_bot   = 18;
		$label_w   = 190;
		$value_w   = 92;
		$width     = 860;
		$plot_w    = $width - $label_w - $value_w - 24;
		$height    = $pad_top + $pad_bot + $n * $row_h;
		$max_scale = max( 1, max( $maxes ) );
		$max_scale = self::nice_max( $max_scale );

		$svg  = '<svg class="psyq-svg" viewBox="0 0 ' . $width . ' ' . $height . '" width="100%" height="' . $height . '" role="img" aria-label="' . esc_attr( $title ) . '" xmlns="http://www.w3.org/2000/svg" font-family="Tahoma, Vazirmatn, Arial, sans-serif">';
		$svg .= '<rect x="0" y="0" width="' . $width . '" height="' . $height . '" fill="#ffffff"/>';
		if ( $title ) {
			$svg .= '<text x="' . ( $width - 12 ) . '" y="26" text-anchor="end" font-size="15" font-weight="bold" fill="#111827">' . esc_html( $title ) . '</text>';
		}

		// خطوط شبکه.
		$ticks = 5;
		for ( $t = 0; $t <= $ticks; $t++ ) {
			$x    = $label_w + ( $plot_w * $t / $ticks ) - ( $label_w * 0 );
			$x    = $width - $value_w - ( $plot_w * $t / $ticks );
			$val  = $max_scale * $t / $ticks;
			$svg .= '<line x1="' . round( $x, 1 ) . '" y1="' . $pad_top . '" x2="' . round( $x, 1 ) . '" y2="' . ( $height - $pad_bot ) . '" stroke="#e5e7eb" stroke-width="1"/>';
			$svg .= '<text x="' . round( $x, 1 ) . '" y="' . ( $height - 4 ) . '" text-anchor="middle" font-size="10" fill="#9ca3af">' . esc_html( PsyQ_Scoring::fmt( round( $val, 1 ) ) ) . '</text>';
		}

		foreach ( $labels as $i => $label ) {
			$y      = $pad_top + $i * $row_h;
			$cy     = $y + $row_h / 2;
			$score  = isset( $scores[ $i ] ) ? (float) $scores[ $i ] : 0;
			$max    = isset( $maxes[ $i ] ) ? (float) $maxes[ $i ] : 0;
			$color  = isset( $colors[ $i ] ) ? $colors[ $i ] : '#4f46e5';
			$bar_w  = $max_scale > 0 ? ( min( $score, $max_scale ) / $max_scale ) * $plot_w : 0;
			$bg_w   = $max_scale > 0 ? ( min( $max, $max_scale ) / $max_scale ) * $plot_w : 0;
			$x0     = $width - $value_w;

			// برچسب.
			$short = mb_strimwidth( $label, 0, 34, '…', 'UTF-8' );
			$svg  .= '<text x="' . ( $width - 12 ) . '" y="' . round( $cy + 5, 1 ) . '" text-anchor="end" font-size="12.5" fill="#1f2937">' . esc_html( $short ) . '</text>';

			// مسیر خاکستری (بازه ممکن).
			$svg .= '<rect x="' . round( $x0 - $bg_w, 1 ) . '" y="' . round( $cy - 11, 1 ) . '" width="' . round( $bg_w, 1 ) . '" height="22" rx="6" fill="#f1f5f9"/>';
			// میله اصلی.
			$svg .= '<rect x="' . round( $x0 - $bar_w, 1 ) . '" y="' . round( $cy - 11, 1 ) . '" width="' . round( max( 0, $bar_w ), 1 ) . '" height="22" rx="6" fill="' . esc_attr( $color ) . '"><title>' . esc_html( $label . ': ' . PsyQ_Scoring::fmt( $score ) . ' / ' . PsyQ_Scoring::fmt( $max ) ) . '</title></rect>';
			// مقدار.
			$svg .= '<text x="' . ( $width - 6 ) . '" y="' . round( $cy + 5, 1 ) . '" text-anchor="end" font-size="12" font-weight="bold" fill="#111827" direction="ltr">' . esc_html( PsyQ_Scoring::fmt( $score ) . '/' . PsyQ_Scoring::fmt( $max ) ) . '</text>';
			// جداکننده ردیف.
			if ( $i < count( $labels ) - 1 ) {
				$svg .= '<line x1="' . ( $width - $plot_w - $value_w ) . '" y1="' . ( $y + $row_h ) . '" x2="' . ( $width - $value_w ) . '" y2="' . ( $y + $row_h ) . '" stroke="#f1f5f9" stroke-width="1"/>';
			}
		}

		$svg .= '</svg>';
		return $svg;
	}

	/**
	 * داده هیستوگرام (توزیع فراوانی امتیازهای گزینه‌ها).
	 *
	 * @param array $scores خروجی نمره‌گذاری.
	 * @return array
	 */
	public static function histogram_data( $scores ) {
		$freq = array();
		foreach ( $scores['items'] as $d ) {
			if ( $d['skipped'] || null === $d['earned'] ) {
				continue;
			}
			$key = PsyQ_Scoring::fmt( $d['earned'] );
			if ( ! isset( $freq[ $key ] ) ) {
				$freq[ $key ] = 0;
			}
			$freq[ $key ]++;
		}
		// مرتب‌سازی عددی.
		uksort(
			$freq,
			function ( $a, $b ) {
				return (float) $a <=> (float) $b;
			}
		);
		$labels = array();
		$counts = array();
		foreach ( $freq as $k => $v ) {
			$labels[] = (string) $k;
			$counts[] = (int) $v;
		}
		return array(
			'type'   => 'bar',
			'labels' => $labels,
			'counts' => $counts,
			'label'  => __( 'تعداد پاسخ‌ها', 'psyq' ),
		);
	}

	/**
	 * هیستوگرام SVG.
	 *
	 * @param array $scores نمرات.
	 * @return string
	 */
	public static function histogram_svg( $scores ) {
		$data   = self::histogram_data( $scores );
		$labels = $data['labels'];
		$counts = $data['counts'];
		$n      = max( 1, count( $labels ) );

		$width   = 860;
		$height  = 300;
		$pad_l   = 46;
		$pad_r   = 16;
		$pad_t   = 44;
		$pad_b   = 56;
		$plot_w  = $width - $pad_l - $pad_r;
		$plot_h  = $height - $pad_t - $pad_b;
		$max_c   = max( 1, max( $counts ) );
		$max_c   = self::nice_max( $max_c );
		$bar_w   = $plot_w / $n;

		$svg  = '<svg class="psyq-svg" viewBox="0 0 ' . $width . ' ' . $height . '" width="100%" height="' . $height . '" role="img" aria-label="' . esc_attr__( 'هیستوگرام توزیع پاسخ‌ها', 'psyq' ) . '" xmlns="http://www.w3.org/2000/svg" font-family="Tahoma, Vazirmatn, Arial, sans-serif">';
		$svg .= '<rect x="0" y="0" width="' . $width . '" height="' . $height . '" fill="#ffffff"/>';
		$svg .= '<text x="' . ( $width - 12 ) . '" y="26" text-anchor="end" font-size="15" font-weight="bold" fill="#111827">' . esc_html__( 'توزیع فراوانی امتیازهای پاسخ', 'psyq' ) . '</text>';

		// محور Y.
		$ticks = 4;
		for ( $t = 0; $t <= $ticks; $t++ ) {
			$y   = $pad_t + $plot_h - ( $plot_h * $t / $ticks );
			$val = $max_c * $t / $ticks;
			$svg .= '<line x1="' . $pad_l . '" y1="' . round( $y, 1 ) . '" x2="' . ( $width - $pad_r ) . '" y2="' . round( $y, 1 ) . '" stroke="#e5e7eb" stroke-width="1"/>';
			$svg .= '<text x="' . ( $pad_l - 8 ) . '" y="' . round( $y + 4, 1 ) . '" text-anchor="end" font-size="10" fill="#9ca3af">' . esc_html( PsyQ_Scoring::fmt( round( $val, 1 ) ) ) . '</text>';
		}

		// میله‌ها (از راست به چپ برای هماهنگی با RTL).
		foreach ( $labels as $i => $label ) {
			$count = (int) $counts[ $i ];
			$h     = $count / $max_c * $plot_h;
			$x     = $width - $pad_r - ( $i + 1 ) * $bar_w + ( $bar_w * 0.12 );
			$w     = $bar_w * 0.76;
			$y     = $pad_t + $plot_h - $h;
			$svg  .= '<rect x="' . round( $x, 1 ) . '" y="' . round( $y, 1 ) . '" width="' . round( $w, 1 ) . '" height="' . round( max( 0, $h ), 1 ) . '" rx="4" fill="#6366f1" opacity="0.9"><title>' . esc_html( sprintf( __( 'امتیاز %1$s: %2$s پاسخ', 'psyq' ), $label, $count ) ) . '</title></rect>';
			if ( $count > 0 ) {
				$svg .= '<text x="' . round( $x + $w / 2, 1 ) . '" y="' . round( $y - 6, 1 ) . '" text-anchor="middle" font-size="10.5" font-weight="bold" fill="#4338ca">' . esc_html( $count ) . '</text>';
			}
			$svg .= '<text x="' . round( $x + $w / 2, 1 ) . '" y="' . ( $pad_t + $plot_h + 20 ) . '" text-anchor="middle" font-size="11" fill="#374151" direction="ltr">' . esc_html( $label ) . '</text>';
		}

		$svg .= '<line x1="' . $pad_l . '" y1="' . ( $pad_t + $plot_h ) . '" x2="' . ( $width - $pad_r ) . '" y2="' . ( $pad_t + $plot_h ) . '" stroke="#9ca3af" stroke-width="1"/>';
		$svg .= '<text x="' . ( $width / 2 ) . '" y="' . ( $height - 12 ) . '" text-anchor="middle" font-size="11" fill="#6b7280">' . esc_html__( 'امتیاز گزینه انتخاب‌شده', 'psyq' ) . '</text>';
		$svg .= '</svg>';
		return $svg;
	}

	private static function nice_max( $value ) {
		$value = (float) $value;
		if ( $value <= 0 ) {
			return 1;
		}
		$mag  = pow( 10, floor( log10( $value ) ) );
		$norm = $value / $mag;
		if ( $norm <= 1 ) {
			$nice = 1;
		} elseif ( $norm <= 2 ) {
			$nice = 2;
		} elseif ( $norm <= 2.5 ) {
			$nice = 2.5;
		} elseif ( $norm <= 5 ) {
			$nice = 5;
		} else {
			$nice = 10;
		}
		return $nice * $mag;
	}
}
