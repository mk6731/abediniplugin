<?php
/**
 * درخواست‌های AJAX (پنل و سمت کاربر).
 *
 * @package PsyQ
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class PsyQ_Ajax {

	public static function init() {
		$admin_actions = array(
			'save_item',
			'get_item',
			'delete_item',
			'reorder_items',
			'save_subscale',
			'delete_subscale',
			'suggest_bands',
			'preview_report',
			'clear_items',
			'save_item_option',
		);
		foreach ( $admin_actions as $a ) {
			add_action( 'wp_ajax_psyq_' . $a, array( __CLASS__, 'admin_' . $a ) );
		}

		add_action( 'wp_ajax_psyq_submit', array( __CLASS__, 'front_submit' ) );
		add_action( 'wp_ajax_nopriv_psyq_submit', array( __CLASS__, 'front_submit' ) );
		add_action( 'wp_ajax_psyq_resume', array( __CLASS__, 'front_resume' ) );
		add_action( 'wp_ajax_nopriv_psyq_resume', array( __CLASS__, 'front_resume' ) );
	}

	private static function guard() {
		if ( ! current_user_can( PsyQ_Admin::CAP ) ) {
			wp_send_json_error( array( 'message' => __( 'دسترسی مجاز نیست.', 'psyq' ) ), 403 );
		}
		check_ajax_referer( 'psyq_admin', 'nonce' );
	}

	/* ==================================================================
	 * سوالات
	 * ================================================================== */

	public static function admin_save_item() {
		self::guard();
		$form_id = (int) ( $_POST['form_id'] ?? 0 );
		if ( ! $form_id || ! PsyQ_DB::get_form( $form_id ) ) {
			wp_send_json_error( array( 'message' => __( 'پرسشنامه یافت نشد.', 'psyq' ) ) );
		}
		$raw = isset( $_POST['item'] ) ? json_decode( wp_unslash( $_POST['item'] ), true ) : array();
		if ( ! is_array( $raw ) ) {
			wp_send_json_error( array( 'message' => __( 'داده نامعتبر.', 'psyq' ) ) );
		}

		$item_id     = (int) ( $raw['id'] ?? 0 );
		$number      = (int) ( $raw['number'] ?? 0 );
		$text        = wp_kses_post( $raw['text'] ?? '' );
		$answer_type = isset( $raw['answer_type'] ) && 'text' === $raw['answer_type'] ? 'text' : 'choice';

		if ( '' === trim( wp_strip_all_tags( $text ) ) ) {
			wp_send_json_error( array( 'message' => __( 'متن سوال را وارد کنید.', 'psyq' ) ) );
		}
		if ( $number <= 0 ) {
			$existing = PsyQ_DB::get_items( $form_id );
			$number   = count( $existing ) + 1;
		}

		$img = PsyQ_Excel::resolve_image( ! empty( $raw['image_id'] ) ? (string) $raw['image_id'] : ( $raw['image_url'] ?? '' ) );

		$options = isset( $raw['options'] ) && is_array( $raw['options'] ) ? $raw['options'] : array();
		$clean   = array();
		$order   = 0;
		foreach ( $options as $o ) {
			$label = sanitize_text_field( $o['label'] ?? '' );
			if ( '' === trim( $label ) && empty( $o['image_url'] ) && empty( $o['image_id'] ) ) {
				continue;
			}
			$val = PsyQ_Excel::num( $o['value'] ?? 0 );
			if ( $val < -5 ) {
				$val = -5;
			}
			if ( $val > 7 ) {
				$val = 7;
			}
			$oimg    = PsyQ_Excel::resolve_image( ! empty( $o['image_id'] ) ? (string) $o['image_id'] : ( $o['image_url'] ?? '' ) );
			$clean[] = array(
				'label'      => $label,
				'value'      => $val,
				'image_url'  => $oimg['image_url'],
				'image_id'   => $oimg['image_id'],
				'sort_order' => $order,
			);
			$order++;
		}

		if ( 'choice' === $answer_type && empty( $clean ) ) {
			wp_send_json_error( array( 'message' => __( 'حداقل یک گزینه برای سوال لازم است.', 'psyq' ) ) );
		}

		$saved_id = PsyQ_DB::save_item(
			$form_id,
			array(
				'number'       => $number,
				'text'         => $text,
				'answer_type'  => $answer_type,
				'subscale_id'  => (int) ( $raw['subscale_id'] ?? 0 ),
				'image_id'     => $img['image_id'],
				'image_url'    => $img['image_url'],
				'option_count' => 'choice' === $answer_type ? count( $clean ) : 0,
				'reversed'     => ! empty( $raw['reversed'] ) ? 1 : 0,
				'is_required'  => empty( $raw['is_required'] ) ? 0 : 1,
				'condition'    => sanitize_text_field( $raw['condition'] ?? '' ),
				'note'         => sanitize_text_field( $raw['note'] ?? '' ),
				'sort_order'   => (int) ( $raw['sort_order'] ?? $number ),
			),
			$item_id
		);
		if ( ! $saved_id ) {
			wp_send_json_error( array( 'message' => __( 'ذخیره سوال ناموفق بود. لطفاً ساختار پایگاه‌داده افزونه را به‌روزرسانی کنید.', 'psyq' ) ) );
		}

		// جایگزینی گزینه‌ها.
		global $wpdb;
		$wpdb->delete( PsyQ_DB::table( 'options' ), array( 'item_id' => (int) $saved_id ) );
		foreach ( $clean as $c ) {
			PsyQ_DB::save_option(
				(int) $saved_id,
				$form_id,
				array(
					'label'      => $c['label'],
					'value'      => $c['value'],
					'sort_order' => $c['sort_order'],
					'image_url'  => $c['image_url'],
					'image_id'   => $c['image_id'],
				)
			);
		}

		PsyQ_Scoring::clear_cache();
		$bundle = PsyQ_Scoring::bundle( $form_id );
		$item   = null;
		foreach ( $bundle['items'] as $it ) {
			if ( $it['id'] === (int) $saved_id ) {
				$item = $it;
				break;
			}
		}

		wp_send_json_success(
			array(
				'message' => __( 'سوال ذخیره شد.', 'psyq' ),
				'item'    => $item,
				'html'    => self::item_row_html( $item, $bundle ),
			)
		);
	}

	public static function admin_get_item() {
		self::guard();
		$item_id = (int) ( $_POST['item_id'] ?? 0 );
		$item    = PsyQ_DB::get_item( $item_id );
		if ( ! $item ) {
			wp_send_json_error( array( 'message' => __( 'سوال یافت نشد.', 'psyq' ) ) );
		}
		$options = array();
		foreach ( PsyQ_DB::get_options( $item_id ) as $o ) {
			$options[] = array(
				'label'     => $o->label,
				'value'     => (float) $o->value,
				'image_url' => $o->image_url,
				'image_id'  => (int) $o->image_id,
			);
		}
		wp_send_json_success(
			array(
				'item' => array(
					'id'          => (int) $item->id,
					'number'      => (int) $item->number,
					'text'        => $item->text,
					'answer_type' => isset( $item->answer_type ) && 'text' === $item->answer_type ? 'text' : 'choice',
					'subscale_id' => (int) $item->subscale_id,
					'image_url'   => $item->image_url,
					'image_id'    => (int) $item->image_id,
					'reversed'    => (int) $item->reversed,
					'is_required' => (int) $item->is_required,
					'condition'   => $item->condition,
					'note'        => $item->note,
					'options'     => $options,
				),
			)
		);
	}

	public static function admin_delete_item() {
		self::guard();
		$item_id = (int) ( $_POST['item_id'] ?? 0 );
		if ( $item_id ) {
			PsyQ_DB::delete_item( $item_id );
			PsyQ_Scoring::clear_cache();
		}
		wp_send_json_success( array( 'message' => __( 'سوال حذف شد.', 'psyq' ) ) );
	}

	public static function admin_reorder_items() {
		self::guard();
		$form_id = (int) ( $_POST['form_id'] ?? 0 );
		$order   = isset( $_POST['order'] ) ? array_map( 'intval', (array) $_POST['order'] ) : array();
		global $wpdb;
		$i = 0;
		foreach ( $order as $item_id ) {
			$wpdb->update( PsyQ_DB::table( 'items' ), array( 'sort_order' => $i ), array( 'id' => (int) $item_id, 'form_id' => $form_id ) );
			$i++;
		}
		PsyQ_Scoring::clear_cache();
		wp_send_json_success( array( 'message' => __( 'ترتیب ذخیره شد.', 'psyq' ) ) );
	}

	/* ==================================================================
	 * زیرمقیاس‌ها و نقاط برش
	 * ================================================================== */

	public static function admin_save_subscale() {
		self::guard();
		$form_id = (int) ( $_POST['form_id'] ?? 0 );
		$raw     = isset( $_POST['subscale'] ) ? json_decode( wp_unslash( $_POST['subscale'] ), true ) : array();
		if ( ! $form_id || ! is_array( $raw ) ) {
			wp_send_json_error( array( 'message' => __( 'داده نامعتبر.', 'psyq' ) ) );
		}

		$id    = (int) ( $raw['id'] ?? 0 );
		$title = sanitize_text_field( $raw['title'] ?? '' );
		$name  = sanitize_text_field( $raw['name'] ?? '' );
		if ( '' === $title ) {
			wp_send_json_error( array( 'message' => __( 'عنوان زیرمقیاس را وارد کنید.', 'psyq' ) ) );
		}
		if ( '' === $name ) {
			$name = $title;
		}

		$sid = PsyQ_DB::save_subscale(
			$form_id,
			array(
				'name'             => $name,
				'title'            => $title,
				'description'      => wp_kses_post( $raw['description'] ?? '' ),
				'color'            => sanitize_hex_color( $raw['color'] ?? '#4f46e5' ),
				'include_in_total' => empty( $raw['include_in_total'] ) ? 0 : 1,
				'sort_order'       => (int) ( $raw['sort_order'] ?? 0 ),
			),
			$id
		);

		// بازه‌ها (نقاط برش).
		PsyQ_DB::delete_bands( $sid );
		$bands = isset( $raw['bands'] ) && is_array( $raw['bands'] ) ? $raw['bands'] : array();
		$order = 0;
		$saved_bands = array();
		foreach ( $bands as $b ) {
			$label = sanitize_text_field( $b['label'] ?? '' );
			$min   = PsyQ_Excel::num( $b['min'] ?? 0 );
			$max   = ( '' === trim( (string) ( $b['max'] ?? '' ) ) ) ? 99999 : PsyQ_Excel::num( $b['max'] );
			$interp = wp_kses_post( $b['interpretation'] ?? '' );
			if ( '' === $label && '' === trim( wp_strip_all_tags( $interp ) ) ) {
				continue;
			}
			PsyQ_DB::save_band(
				$form_id,
				$sid,
				array(
					'min_value'      => $min,
					'max_value'      => $max,
					'label'          => $label,
					'severity'       => sanitize_key( $b['severity'] ?? 'normal' ),
					'color'          => sanitize_hex_color( $b['color'] ?? '#22c55e' ),
					'interpretation' => $interp,
				),
				$order
			);
			$saved_bands[] = array(
				'min'   => $min,
				'max'   => $max,
				'label' => $label,
			);
			$order++;
		}

		PsyQ_Scoring::clear_cache();
		wp_send_json_success(
			array(
				'message'  => __( 'زیرمقیاس و نقاط برش ذخیره شد.', 'psyq' ),
				'id'       => (int) $sid,
				'band_cnt' => count( $saved_bands ),
			)
		);
	}

	public static function admin_delete_subscale() {
		self::guard();
		$id = (int) ( $_POST['subscale_id'] ?? 0 );
		if ( $id ) {
			PsyQ_DB::delete_subscale( $id );
			PsyQ_Scoring::clear_cache();
		}
		wp_send_json_success( array( 'message' => __( 'زیرمقیاس حذف شد.', 'psyq' ) ) );
	}

	public static function admin_suggest_bands() {
		self::guard();
		$form_id = (int) ( $_POST['form_id'] ?? 0 );
		$sid     = (int) ( $_POST['subscale_id'] ?? 0 );
		$count   = max( 2, min( 6, (int) ( $_POST['count'] ?? 4 ) ) );
		$bundle  = PsyQ_Scoring::bundle( $form_id );

		// بیشینه ممکن زیرمقیاس بر اساس بیشینه امتیاز گزینه‌ها.
		$max = 0;
		if ( $bundle ) {
			foreach ( $bundle['items'] as $it ) {
				if ( (int) $it['subscale_id'] === $sid ) {
					$max += (float) $it['max_value'];
				}
			}
		}
		if ( $max <= 0 ) {
			$max = 100;
		}
		wp_send_json_success( array( 'bands' => PsyQ_Scoring::suggest_bands( $max, $count ), 'max' => $max ) );
	}

	public static function admin_clear_items() {
		self::guard();
		$form_id = (int) ( $_POST['form_id'] ?? 0 );
		if ( $form_id ) {
			PsyQ_DB::clear_items( $form_id );
			PsyQ_Scoring::clear_cache();
		}
		wp_send_json_success( array( 'message' => __( 'همه سوالات حذف شد.', 'psyq' ) ) );
	}

	public static function admin_save_item_option() {
		self::guard();
		wp_send_json_success();
	}

	/**
	 * پیش‌نمایش گزارش با پاسخ‌های فرضی (برای طراح).
	 */
	public static function admin_preview_report() {
		self::guard();
		$form_id = (int) ( $_POST['form_id'] ?? 0 );
		$answers = isset( $_POST['answers'] ) ? json_decode( wp_unslash( $_POST['answers'] ), true ) : array();
		$bundle  = PsyQ_Scoring::bundle( $form_id );
		if ( ! $bundle ) {
			wp_send_json_error( array( 'message' => __( 'پرسشنامه یافت نشد.', 'psyq' ) ) );
		}

		// ساخت پاسخ تصادفی برای سوالاتی که پاسخی ندارند.
		if ( empty( $answers ) ) {
			$answers = array();
			$mode    = isset( $_POST['mode'] ) ? sanitize_key( wp_unslash( $_POST['mode'] ) ) : 'mid';
			foreach ( $bundle['items'] as $it ) {
				if ( empty( $it['options'] ) ) {
					continue;
				}
				if ( 'random' === $mode ) {
					$pick = $it['options'][ wp_rand( 0, count( $it['options'] ) - 1 ) ];
				} else {
					$pick = $it['options'][ (int) floor( count( $it['options'] ) / 2 ) ];
				}
				$answers[ $it['id'] ] = $pick['id'];
			}
		} else {
			// تبدیل کلیدهای شماره‌ای به شناسه سوال.
			$norm = array();
			foreach ( $bundle['items'] as $it ) {
				$k = (string) $it['id'];
				if ( isset( $answers[ $k ] ) ) {
					$norm[ $it['id'] ] = $answers[ $k ];
				}
			}
			$answers = $norm;
		}

		$scores = PsyQ_Scoring::score( $form_id, $answers );
		if ( is_wp_error( $scores ) ) {
			wp_send_json_error( array( 'message' => $scores->get_error_message() ) );
		}
		$html = PsyQ_Scoring::render_report( $form_id, $scores, array( 'context' => 'admin', 'answers_table' => true ) );
		wp_send_json_success( array( 'html' => $html, 'scores' => $scores ) );
	}

	/* ==================================================================
	 * سمت کاربر
	 * ================================================================== */

	/**
	 * ثبت پاسخ‌های آزمودنی.
	 */
	public static function front_submit() {
		check_ajax_referer( 'psyq_front', 'nonce' );

		$form_id = (int) ( $_POST['form_id'] ?? 0 );
		$bundle  = PsyQ_Scoring::bundle( $form_id );
		if ( ! $bundle ) {
			wp_send_json_error( array( 'message' => __( 'پرسشنامه یافت نشد.', 'psyq' ) ) );
		}
		if ( 'publish' !== $bundle['form']->status && ! current_user_can( PsyQ_Admin::CAP ) ) {
			wp_send_json_error( array( 'message' => __( 'این پرسشنامه در دسترس نیست.', 'psyq' ) ) );
		}
		if ( ! get_option( 'psyq_allow_guest', 1 ) && ! is_user_logged_in() ) {
			wp_send_json_error( array( 'message' => __( 'برای شرکت در آزمون باید وارد شوید.', 'psyq' ) ) );
		}

		$raw_answers = isset( $_POST['answers'] ) ? json_decode( wp_unslash( $_POST['answers'] ), true ) : array();
		if ( ! is_array( $raw_answers ) ) {
			wp_send_json_error( array( 'message' => __( 'پاسخ‌ها نامعتبر است.', 'psyq' ) ) );
		}

		$answers = array();
		$missing = 0;
		$items_by_id = array();
		foreach ( $bundle['items'] as $bundle_item ) {
			$items_by_id[ (int) $bundle_item['id'] ] = $bundle_item;
		}
		foreach ( $raw_answers as $item_id => $raw_answer ) {
			$item_id = (int) $item_id;
			if ( ! $item_id || ! isset( $items_by_id[ $item_id ] ) ) {
				continue;
			}
			$item = $items_by_id[ $item_id ];
			if ( 'text' === ( $item['answer_type'] ?? 'choice' ) ) {
				$text_answer = is_scalar( $raw_answer ) ? sanitize_textarea_field( wp_unslash( (string) $raw_answer ) ) : '';
				if ( '' !== trim( $text_answer ) ) {
					$answers[ $item_id ] = $text_answer;
				}
				continue;
			}
			$opt_id = (int) $raw_answer;
			if ( ! $opt_id ) {
				continue;
			}
			foreach ( $item['options'] as $option ) {
				if ( (int) $option['id'] === $opt_id ) {
					$answers[ $item_id ] = $opt_id;
					break;
				}
			}
		}

		// بررسی اجباری بودن.
		if ( ! empty( $bundle['form']->require_all ) ) {
			foreach ( $bundle['items'] as $it ) {
				if ( empty( $it['is_required'] ) ) {
					continue;
				}
				if ( ! PsyQ_Scoring::is_item_visible( $it, $answers, $bundle ) ) {
					continue;
				}
				if ( ! isset( $answers[ $it['id'] ] ) ) {
					$missing++;
				}
			}
		}
		if ( $missing > 0 ) {
			wp_send_json_error(
				array(
					'message' => sprintf( __( '%d سوال اجباری بدون پاسخ مانده است.', 'psyq' ), $missing ),
					'missing' => $missing,
				)
			);
		}

		$scores = PsyQ_Scoring::score( $form_id, $answers );
		if ( is_wp_error( $scores ) ) {
			wp_send_json_error( array( 'message' => $scores->get_error_message() ) );
		}

		$saved = PsyQ_DB::save_response(
			array(
				'form_id'      => $form_id,
				'first_name'   => sanitize_text_field( wp_unslash( $_POST['first_name'] ?? '' ) ),
				'last_name'    => sanitize_text_field( wp_unslash( $_POST['last_name'] ?? '' ) ),
				'gender'       => sanitize_key( wp_unslash( $_POST['gender'] ?? '' ) ),
				'age'          => (int) ( $_POST['age'] ?? 0 ),
				'education'    => sanitize_text_field( wp_unslash( $_POST['education'] ?? '' ) ),
				'phone'        => sanitize_text_field( wp_unslash( $_POST['phone'] ?? '' ) ),
				'email'        => sanitize_email( wp_unslash( $_POST['email'] ?? '' ) ),
				'answers'      => $answers,
				'scores'       => $scores,
				'raw_total'    => $scores['grand_total'],
				'duration_sec' => (int) ( $_POST['duration'] ?? 0 ),
			)
		);

		$html = PsyQ_Scoring::render_report( $form_id, $scores, array( 'context' => 'front' ) );
		PsyQ_DB::update_response_report( $saved['id'], $html );

		$report_page = (int) get_option( 'psyq_report_page', 0 );
		$permalink   = '';
		if ( $report_page ) {
			$permalink = add_query_arg( array( 'psyq_result' => $saved['token'] ), get_permalink( $report_page ) );
		}

		/**
		 * امکان ارسال گزارش با ایمیل/پیامک توسط افزونه‌های دیگر.
		 */
		do_action( 'psyq_response_saved', $saved['id'], $form_id, $scores, $answers );

		wp_send_json_success(
			array(
				'html'    => $html,
				'response_id' => $saved['id'],
				'token'   => $saved['token'],
				'link'    => $permalink,
				'message' => __( 'پاسخ‌های شما ثبت شد.', 'psyq' ),
			)
		);
	}

	/**
	 * بازیابی گزارش با توکن.
	 */
	public static function front_resume() {
		check_ajax_referer( 'psyq_front', 'nonce' );
		$token = sanitize_text_field( wp_unslash( $_POST['token'] ?? '' ) );
		if ( ! $token ) {
			wp_send_json_error( array( 'message' => __( 'توکن نامعتبر است.', 'psyq' ) ) );
		}
		global $wpdb;
		$t   = PsyQ_DB::table( 'responses' );
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE guest_token = %s", $token ) );
		if ( ! $row ) {
			wp_send_json_error( array( 'message' => __( 'گزارشی با این شناسه یافت نشد.', 'psyq' ) ) );
		}
		$html = $row->report_html;
		if ( ! $html ) {
			$scores = json_decode( (string) $row->scores, true );
			$html   = PsyQ_Scoring::render_report( (int) $row->form_id, $scores, array( 'response' => $row, 'context' => 'front' ) );
		}
		wp_send_json_success( array( 'html' => $html, 'form_id' => (int) $row->form_id ) );
	}

	/* ==================================================================
	 * کمکی
	 * ================================================================== */

	/**
	 * HTML یک ردیف سوال در فهرست پنل.
	 *
	 * @param array $item   سوال.
	 * @param array $bundle بسته.
	 * @return string
	 */
	public static function item_row_html( $item, $bundle ) {
		if ( ! $item ) {
			return '';
		}
		$sub_title = '';
		if ( $item['subscale_id'] && isset( $bundle['subscales'][ $item['subscale_id'] ] ) ) {
			$sub_title = $bundle['subscales'][ $item['subscale_id'] ]['title'];
			$sub_color = $bundle['subscales'][ $item['subscale_id'] ]['color'];
		} else {
			$sub_color = '#94a3b8';
		}
		ob_start();
		?>
		<tr data-item-id="<?php echo esc_attr( $item['id'] ); ?>">
			<td class="psyq-col-drag"><span class="dashicons dashicons-menu"></span></td>
			<td class="psyq-col-num"><strong><?php echo esc_html( $item['number'] ); ?></strong></td>
			<td class="psyq-col-text">
				<div class="psyq-item-text"><?php echo esc_html( wp_trim_words( wp_strip_all_tags( $item['text'] ), 22 ) ); ?></div>
				<?php if ( ! empty( $item['image_url'] ) ) : ?>
					<span class="psyq-chip"><span class="dashicons dashicons-format-image"></span> <?php esc_html_e( 'تصویر دارد', 'psyq' ); ?></span>
				<?php endif; ?>
				<?php if ( ! empty( $item['reversed'] ) ) : ?>
					<span class="psyq-chip psyq-chip--warn"><?php esc_html_e( 'معکوس', 'psyq' ); ?></span>
				<?php endif; ?>
				<?php if ( ! empty( $item['condition'] ) ) : ?>
					<span class="psyq-chip"><?php echo esc_html( $item['condition']['raw'] ); ?></span>
				<?php endif; ?>
			</td>
			<td class="psyq-col-sub">
				<?php if ( $sub_title ) : ?>
					<span class="psyq-dot" style="background:<?php echo esc_attr( $sub_color ); ?>"></span><?php echo esc_html( $sub_title ); ?>
				<?php else : ?>
					<span class="psyq-muted">—</span>
				<?php endif; ?>
			</td>
			<td class="psyq-col-opts">
				<?php if ( isset( $item['answer_type'] ) && 'text' === $item['answer_type'] ) : ?>
					<span class="psyq-chip"><?php esc_html_e( 'پاسخ متنی · بدون نمره', 'psyq' ); ?></span>
				<?php else : ?>
				<div class="psyq-mini-opts">
					<?php foreach ( $item['options'] as $o ) : ?>
						<span class="psyq-mini-opt" title="<?php echo esc_attr( $o['label'] . ' = ' . PsyQ_Scoring::fmt( $o['value'] ) ); ?>">
							<?php echo esc_html( mb_strimwidth( $o['label'], 0, 14, '…', 'UTF-8' ) ); ?>
							<em><?php echo esc_html( PsyQ_Scoring::fmt( $o['value'] ) ); ?></em>
						</span>
					<?php endforeach; ?>
				</div>
				<?php endif; ?>
			</td>
			<td class="psyq-col-actions">
				<button type="button" class="button button-small psyq-edit-item" data-id="<?php echo esc_attr( $item['id'] ); ?>"><?php esc_html_e( 'ویرایش', 'psyq' ); ?></button>
				<button type="button" class="button button-small psyq-del-item" data-id="<?php echo esc_attr( $item['id'] ); ?>"><?php esc_html_e( 'حذف', 'psyq' ); ?></button>
			</td>
		</tr>
		<?php
		return ob_get_clean();
	}
}
