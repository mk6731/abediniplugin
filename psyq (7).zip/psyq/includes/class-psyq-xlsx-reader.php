<?php
/**
 * خواننده سبک فایل XLSX بدون وابستگی به Composer.
 * با ZipArchive + SimpleXML کار می‌کند (روی اکثر هاست‌ها موجود است).
 *
 * @package PsyQ
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class PsyQ_XLSX_Reader {

	/** @var array رشته‌های مشترک */
	private $shared = array();

	/** @var string مسیر فایل */
	private $file = '';

	/**
	 * خواندن فایل و برگرداندن ردیف‌های شیت اول.
	 *
	 * @param string $file مسیر فایل.
	 * @param int    $sheet_index شماره شیت (۰ = اول).
	 * @return array 배열 ردیف‌ها؛ هر ردیف آرایه‌ای با کلید ستون (۰..n)  →  مقدار رشته.
	 * @throws Exception در صورت خطا.
	 */
	public function read( $file, $sheet_index = 0 ) {
		if ( ! class_exists( 'ZipArchive' ) ) {
			throw new Exception( 'افزونه php-zip روی سرور فعال نیست. لطفاً از هاست بخواهید ZipArchive را فعال کند.' );
		}
		if ( ! is_readable( $file ) ) {
			throw new Exception( 'فایل قابل خواندن نیست.' );
		}
		$this->file = $file;

		$zip = new ZipArchive();
		if ( true !== $zip->open( $file ) ) {
			throw new Exception( 'فایل اکسل باز نشد. مطمئن شوید فایل xlsx سالم است (فایل‌های xls قدیمی پشتیبانی نمی‌شوند).' );
		}

		// رشته‌های مشترک.
		$ss = $zip->getFromName( 'xl/sharedStrings.xml' );
		if ( false !== $ss ) {
			$this->parse_shared_strings( $ss );
		}

		// نگاشت شیت‌ها.
		$sheet_path = 'xl/worksheets/sheet' . ( $sheet_index + 1 ) . '.xml';
		$wb         = $zip->getFromName( 'xl/workbook.xml' );
		$rels       = $zip->getFromName( 'xl/_rels/workbook.xml.rels' );
		if ( $wb && $rels ) {
			$sheet_path = $this->resolve_sheet_path( $wb, $rels, $sheet_index );
		}

		$sheet = $zip->getFromName( $sheet_path );
		$zip->close();

		if ( false === $sheet ) {
			throw new Exception( 'شیت مورد نظر در فایل پیدا نشد.' );
		}

		return $this->parse_sheet( $sheet );
	}

	/**
	 * فهرست نام شیت‌ها.
	 *
	 * @param string $file فایل.
	 * @return array
	 */
	public function sheet_names( $file ) {
		$out = array();
		if ( ! class_exists( 'ZipArchive' ) ) {
			return $out;
		}
		$zip = new ZipArchive();
		if ( true !== $zip->open( $file ) ) {
			return $out;
		}
		$wb = $zip->getFromName( 'xl/workbook.xml' );
		$zip->close();
		if ( ! $wb ) {
			return $out;
		}
		$xml = @simplexml_load_string( $wb );
		if ( $xml && isset( $xml->sheets->sheet ) ) {
			foreach ( $xml->sheets->sheet as $s ) {
				$out[] = (string) $s['name'];
			}
		}
		return $out;
	}

	private function parse_shared_strings( $xml_string ) {
		$xml = @simplexml_load_string( $xml_string );
		if ( ! $xml || ! isset( $xml->si ) ) {
			return;
		}
		foreach ( $xml->si as $si ) {
			$text = '';
			if ( isset( $si->t ) ) {
				$text = (string) $si->t;
			} elseif ( isset( $si->r ) ) {
				foreach ( $si->r as $r ) {
					$text .= isset( $r->t ) ? (string) $r->t : '';
				}
			}
			$this->shared[] = $text;
		}
	}

	private function resolve_sheet_path( $wb_xml, $rels_xml, $index ) {
		$wb   = @simplexml_load_string( $wb_xml );
		$rels = @simplexml_load_string( $rels_xml );
		$path = 'xl/worksheets/sheet' . ( $index + 1 ) . '.xml';
		if ( ! $wb || ! $rels || ! isset( $wb->sheets->sheet[ $index ] ) ) {
			return $path;
		}
		$sheet = $wb->sheets->sheet[ $index ];
		$rid   = '';
		foreach ( $sheet->attributes( 'http://schemas.openxmlformats.org/officeDocument/2006/relationships' ) as $k => $v ) {
			if ( 'id' === $k ) {
				$rid = (string) $v;
			}
		}
		if ( ! $rid ) {
			return $path;
		}
		foreach ( $rels->Relationship as $rel ) {
			if ( (string) $rel['Id'] === $rid ) {
				$target = (string) $rel['Target'];
				$target = ltrim( str_replace( '\\', '/', $target ), '/' );
				if ( 0 !== strpos( $target, 'xl/' ) ) {
					$target = 'xl/' . $target;
				}
				return $target;
			}
		}
		return $path;
	}

	private function parse_sheet( $xml_string ) {
		$rows = array();
		$xml  = @simplexml_load_string( $xml_string );
		if ( ! $xml || ! isset( $xml->sheetData->row ) ) {
			return $rows;
		}
		foreach ( $xml->sheetData->row as $row ) {
			$cells = array();
			$max   = 0;
			foreach ( $row->c as $c ) {
				$ref  = (string) $c['r'];
				$col  = $this->col_index( $ref );
				$type = (string) $c['t'];
				$val  = '';
				if ( 'inlineStr' === $type && isset( $c->is ) ) {
					if ( isset( $c->is->t ) ) {
						$val = (string) $c->is->t;
					} elseif ( isset( $c->is->r ) ) {
						foreach ( $c->is->r as $r ) {
							$val .= isset( $r->t ) ? (string) $r->t : '';
						}
					}
				} elseif ( 's' === $type ) {
					$idx = (int) $c->v;
					$val = isset( $this->shared[ $idx ] ) ? $this->shared[ $idx ] : '';
				} else {
					$val = isset( $c->v ) ? (string) $c->v : '';
					if ( '' === $val && isset( $c->is->t ) ) {
						$val = (string) $c->is->t;
					}
				}
				$val = preg_replace( '/[\x{200B}-\x{200D}\x{FEFF}]/u', '', $val );
				$cells[ $col ] = trim( $val );
				if ( $col > $max ) {
					$max = $col;
				}
			}
			// پر کردن ستون‌های خالی.
			$padded = array();
			for ( $i = 0; $i <= $max; $i++ ) {
				$padded[ $i ] = isset( $cells[ $i ] ) ? $cells[ $i ] : '';
			}
			$rows[] = $padded;
		}
		return $rows;
	}

	/**
	 * تبدیل A1 به اندیس ستون (۰-پایه).
	 */
	public function col_index( $ref ) {
		if ( ! preg_match( '/([A-Z]+)/i', $ref, $m ) ) {
			return 0;
		}
		$letters = strtoupper( $m[1] );
		$num     = 0;
		for ( $i = 0; $i < strlen( $letters ); $i++ ) {
			$num = $num * 26 + ( ord( $letters[ $i ] ) - 64 );
		}
		return $num - 1;
	}

	/**
	 * تبدیل اندیس ستون به حرف (۰ → A).
	 */
	public static function col_letter( $index ) {
		$index = (int) $index;
		$out   = '';
		do {
			$out = chr( 65 + ( $index % 26 ) ) . $out;
			$index = intdiv( $index, 26 ) - 1;
		} while ( $index >= 0 );
		return $out;
	}
}
