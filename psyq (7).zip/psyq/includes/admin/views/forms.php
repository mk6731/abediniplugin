<?php
/**
 * فهرست پرسشنامه‌ها.
 *
 * @package PsyQ
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="wrap psyq-wrap psyq-wrap--wide" dir="rtl">
	<h1 class="psyq-page-title">
		<span class="dashicons dashicons-forms"></span> <?php esc_html_e( 'همه پرسشنامه‌ها', 'psyq' ); ?>
		<a class="page-title-action" href="<?php echo esc_url( admin_url( 'admin.php?page=psyq-form' ) ); ?>"><?php esc_html_e( 'افزودن پرسشنامه', 'psyq' ); ?></a>
	</h1>

	<form method="get" class="psyq-toolbar">
		<input type="hidden" name="page" value="psyq-forms">
		<input type="search" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="<?php esc_attr_e( 'جست‌وجوی عنوان یا کد…', 'psyq' ); ?>">
		<button class="button"><?php esc_html_e( 'جست‌وجو', 'psyq' ); ?></button>
		<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=psyq-templates' ) ); ?>"><?php esc_html_e( 'قالب خام اکسل', 'psyq' ); ?></a>
		<a class="button button-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=psyq-import' ) ); ?>"><?php esc_html_e( 'ورود از اکسل', 'psyq' ); ?></a>
	</form>

	<div class="psyq-table-wrap">
		<table class="wp-list-table widefat striped psyq-table">
			<thead>
				<tr>
					<th style="width:56px">#</th>
					<th><?php esc_html_e( 'عنوان پرسشنامه', 'psyq' ); ?></th>
					<th style="width:120px"><?php esc_html_e( 'کد', 'psyq' ); ?></th>
					<th style="width:90px"><?php esc_html_e( 'سوالات', 'psyq' ); ?></th>
					<th style="width:110px"><?php esc_html_e( 'زیرمقیاس', 'psyq' ); ?></th>
					<th style="width:90px"><?php esc_html_e( 'گزینه‌ها', 'psyq' ); ?></th>
					<th style="width:120px"><?php esc_html_e( 'وضعیت', 'psyq' ); ?></th>
					<th style="width:210px"><?php esc_html_e( 'شورت‌کد', 'psyq' ); ?></th>
					<th style="width:330px"><?php esc_html_e( 'عملیات', 'psyq' ); ?></th>
				</tr>
			</thead>
			<tbody>
			<?php if ( empty( $forms ) ) : ?>
				<tr><td colspan="9"><?php esc_html_e( 'پرسشنامه‌ای یافت نشد.', 'psyq' ); ?></td></tr>
			<?php endif; ?>
			<?php foreach ( $forms as $f ) : ?>
				<?php
				$items = PsyQ_DB::get_items( $f->id );
				$subs  = PsyQ_DB::get_subscales( $f->id );
				$bands = 0;
				foreach ( $subs as $s ) {
					$bands += count( PsyQ_DB::get_bands( $s->id ) );
				}
				?>
				<tr>
					<td data-label="#"><?php echo esc_html( $f->id ); ?></td>
					<td data-label="<?php esc_attr_e( 'عنوان پرسشنامه', 'psyq' ); ?>">
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=psyq-form&form_id=' . $f->id ) ); ?>"><strong><?php echo esc_html( $f->title ); ?></strong></a>
						<div class="psyq-muted psyq-small"><?php echo esc_html( wp_trim_words( wp_strip_all_tags( (string) $f->description ), 16 ) ); ?></div>
					</td>
					<td data-label="<?php esc_attr_e( 'کد', 'psyq' ); ?>"><code><?php echo esc_html( $f->code ); ?></code></td>
					<td data-label="<?php esc_attr_e( 'سوالات', 'psyq' ); ?>"><?php echo esc_html( count( $items ) ); ?></td>
					<td data-label="<?php esc_attr_e( 'زیرمقیاس', 'psyq' ); ?>"><?php echo esc_html( count( $subs ) ); ?></td>
					<td data-label="<?php esc_attr_e( 'گزینه‌ها', 'psyq' ); ?>">
						<span class="psyq-badge psyq-badge--info"><?php echo esc_html( $f->default_option_count ); ?> <?php esc_html_e( 'گزینه‌ای', 'psyq' ); ?></span>
					</td>
					<td data-label="<?php esc_attr_e( 'وضعیت', 'psyq' ); ?>">
						<span class="psyq-badge psyq-badge--<?php echo 'publish' === $f->status ? 'ok' : 'draft'; ?>">
							<?php echo 'publish' === $f->status ? esc_html__( 'منتشرشده', 'psyq' ) : esc_html__( 'پیش‌نویس', 'psyq' ); ?>
						</span>
					</td>
					<td data-label="<?php esc_attr_e( 'شورت‌کد', 'psyq' ); ?>">
						<code class="psyq-copy" title="<?php esc_attr_e( 'کلیک برای کپی', 'psyq' ); ?>">[psyq_form id="<?php echo esc_html( $f->id ); ?>"]</code>
						<?php if ( ! empty( $bands ) ) : ?>
							<div class="psyq-muted psyq-small"><?php echo esc_html( $bands ); ?> <?php esc_html_e( 'بازه برش', 'psyq' ); ?></div>
						<?php endif; ?>
					</td>
					<td class="psyq-actions" data-label="<?php esc_attr_e( 'عملیات', 'psyq' ); ?>">
						<a class="button button-small" href="<?php echo esc_url( admin_url( 'admin.php?page=psyq-form&form_id=' . $f->id . '&tab=items' ) ); ?>"><?php esc_html_e( 'سوالات', 'psyq' ); ?></a>
						<a class="button button-small" href="<?php echo esc_url( admin_url( 'admin.php?page=psyq-form&form_id=' . $f->id . '&tab=subscales' ) ); ?>"><?php esc_html_e( 'زیرمقیاس‌ها', 'psyq' ); ?></a>
						<a class="button button-small" href="<?php echo esc_url( admin_url( 'admin.php?page=psyq-responses&form_id=' . $f->id ) ); ?>"><?php esc_html_e( 'پاسخ‌ها', 'psyq' ); ?></a>

						<div class="psyq-more">
							<button type="button" class="button button-small psyq-more-btn">⋯</button>
							<div class="psyq-more-menu">
								<a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=psyq_excel&type=export&form_id=' . $f->id ), 'psyq_excel' ) ); ?>"><?php esc_html_e( 'خروجی اکسل پرسشنامه', 'psyq' ); ?></a>
								<a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=psyq_excel&type=results&form_id=' . $f->id ), 'psyq_excel' ) ); ?>"><?php esc_html_e( 'خروجی اکسل نتایج', 'psyq' ); ?></a>
								<a href="<?php echo esc_url( admin_url( 'admin.php?page=psyq-import&form_id=' . $f->id ) ); ?>"><?php esc_html_e( 'به‌روزرسانی با اکسل', 'psyq' ); ?></a>

								<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
									<?php wp_nonce_field( 'psyq_action' ); ?>
									<input type="hidden" name="action" value="psyq_action">
									<input type="hidden" name="psyq_action" value="duplicate_form">
									<input type="hidden" name="form_id" value="<?php echo esc_attr( $f->id ); ?>">
									<button type="submit" class="psyq-linkbtn"><?php esc_html_e( 'ایجاد کپی', 'psyq' ); ?></button>
								</form>

								<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
									<?php wp_nonce_field( 'psyq_action' ); ?>
									<input type="hidden" name="action" value="psyq_action">
									<input type="hidden" name="psyq_action" value="<?php echo 'publish' === $f->status ? 'unpublish_form' : 'publish_form'; ?>">
									<input type="hidden" name="form_id" value="<?php echo esc_attr( $f->id ); ?>">
									<button type="submit" class="psyq-linkbtn"><?php echo 'publish' === $f->status ? esc_html__( 'لغو انتشار', 'psyq' ) : esc_html__( 'انتشار پرسشنامه', 'psyq' ); ?></button>
								</form>

								<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" onsubmit="return confirm('<?php echo esc_js( __( 'این پرسشنامه و همه سوالات آن حذف می‌شود. مطمئن هستید؟', 'psyq' ) ); ?>');">
									<?php wp_nonce_field( 'psyq_action' ); ?>
									<input type="hidden" name="action" value="psyq_action">
									<input type="hidden" name="psyq_action" value="delete_form">
									<input type="hidden" name="form_id" value="<?php echo esc_attr( $f->id ); ?>">
									<button type="submit" class="psyq-linkbtn psyq-danger"><?php esc_html_e( 'حذف پرسشنامه', 'psyq' ); ?></button>
								</form>
							</div>
						</div>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
	</div>
</div>
