<?php
/**
 * ورود از اکسل.
 *
 * @package PsyQ
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$selected = isset( $_GET['form_id'] ) ? (int) $_GET['form_id'] : 0; // phpcs:ignore
?>
<div class="wrap psyq-wrap" dir="rtl">
	<h1 class="psyq-page-title"><span class="dashicons dashicons-upload"></span> <?php esc_html_e( 'ورود پرسشنامه از فایل اکسل', 'psyq' ); ?></h1>

	<div class="psyq-panel-grid">
		<div class="psyq-panel-main">
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data" class="psyq-box" id="psyq-import-upload-form">
				<?php wp_nonce_field( 'psyq_import' ); ?>
				<input type="hidden" name="action" value="psyq_import">

				<h2 class="psyq-box__title"><?php esc_html_e( '۱) فایل اکسل را انتخاب کنید', 'psyq' ); ?></h2>
				<label class="psyq-dropzone" id="psyq-dropzone">
					<input type="file" name="psyq_file" accept=".xlsx" required id="psyq-file-input">
					<span class="dashicons dashicons-media-spreadsheet"></span>
					<strong><?php esc_html_e( 'فایل xlsx را اینجا رها کنید یا کلیک کنید', 'psyq' ); ?></strong>
					<small><?php esc_html_e( 'فقط فرمت xlsx (Excel 2007 به بعد). حداکثر حجم بر اساس تنظیمات هاست.', 'psyq' ); ?></small>
					<em id="psyq-file-name"></em>
				</label>

				<h2 class="psyq-box__title"><?php esc_html_e( '۲) مقصد ورود', 'psyq' ); ?></h2>
				<div class="psyq-fields">
					<label class="psyq-field psyq-field--full">
						<span><?php esc_html_e( 'پرسشنامه مقصد', 'psyq' ); ?></span>
						<select name="form_id" id="psyq-import-form">
							<option value="0"><?php esc_html_e( '— ساخت پرسشنامه جدید —', 'psyq' ); ?></option>
							<?php foreach ( $forms as $f ) : ?>
								<option value="<?php echo esc_attr( $f->id ); ?>" <?php selected( $selected, $f->id ); ?>>
									<?php echo esc_html( $f->title . ' (' . $f->code . ')' ); ?>
								</option>
							<?php endforeach; ?>
						</select>
					</label>
					<label class="psyq-field psyq-field--full">
						<span><?php esc_html_e( 'حالت ورود', 'psyq' ); ?></span>
						<select name="mode" id="psyq-import-mode">
							<option value="new"><?php esc_html_e( 'ساخت پرسشنامه جدید', 'psyq' ); ?></option>
							<option value="replace"><?php esc_html_e( 'جایگزینی کامل سوالات و زیرمقیاس‌های پرسشنامه انتخاب‌شده', 'psyq' ); ?></option>
							<option value="append"><?php esc_html_e( 'افزودن به سوالات موجود (بدون حذف)', 'psyq' ); ?></option>
						</select>
					</label>
					<label class="psyq-field">
						<span><?php esc_html_e( 'وضعیت پرسشنامه جدید', 'psyq' ); ?></span>
						<select name="status">
							<option value="draft"><?php esc_html_e( 'پیش‌نویس', 'psyq' ); ?></option>
							<option value="publish"><?php esc_html_e( 'منتشرشده', 'psyq' ); ?></option>
						</select>
					</label>
				</div>

				<p class="psyq-row">
					<button type="submit" class="button button-primary button-large" id="psyq-import-submit"><?php esc_html_e( 'شروع ورود داده‌ها', 'psyq' ); ?></button>
					<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=psyq-templates' ) ); ?>"><?php esc_html_e( 'دریافت قالب خام', 'psyq' ); ?></a>
					<a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=psyq_excel&type=sample-pas' ), 'psyq_excel' ) ); ?>"><?php esc_html_e( 'دانلود نمونه PAS (۳۴ گویه)', 'psyq' ); ?></a>
					<a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=psyq_excel&type=sample-scas' ), 'psyq_excel' ) ); ?>"><?php esc_html_e( 'دانلود نمونه SCAS-Parent (۳۸ گویه)', 'psyq' ); ?></a>
				</p>
				<p class="psyq-import-status" id="psyq-import-status" role="status" aria-live="polite" hidden></p>
				<p class="psyq-muted psyq-small"><?php esc_html_e( 'پس از ورود، تعداد سوالات، گزینه‌ها، زیرمقیاس‌ها و نقاط برش گزارش داده می‌شود. اگر ستون «زیرمقیاس» به زیرمقیاس تعریف‌نشده‌ای اشاره کند، به‌صورت خودکار ساخته می‌شود.', 'psyq' ); ?></p>
			</form>

			<div class="psyq-box">
				<h2 class="psyq-box__title"><?php esc_html_e( 'ساختار فایل اکسل', 'psyq' ); ?></h2>
				<p class="psyq-muted"><?php esc_html_e( 'فایل دارای ۵ برگه است. می‌توانید برگه‌ها را حذف کنید؛ سیستم بر اساس نام و سرستون‌ها تشخیص می‌دهد.', 'psyq' ); ?></p>
				<ol class="psyq-ol">
					<li><strong><?php esc_html_e( 'پرسشنامه', 'psyq' ); ?></strong> — <?php esc_html_e( 'عنوان، کد، توضیحات، تعداد گزینه پیش‌فرض، نمایش نمره کل و…', 'psyq' ); ?></li>
					<li><strong><?php esc_html_e( 'زیرمقیاس‌ها', 'psyq' ); ?></strong> — <?php esc_html_e( 'نام (کد)، عنوان نمایشی، توضیح، رنگ، لحاظ شدن در نمره کل', 'psyq' ); ?></li>
					<li><strong><?php esc_html_e( 'نقاط برش', 'psyq' ); ?></strong> — <?php esc_html_e( 'برای هر زیرمقیاس ۱ تا ۳ نقطه برش: از / تا / برچسب / رنگ / تفسیر اختصاصی', 'psyq' ); ?></li>
					<li><strong><?php esc_html_e( 'سوالات', 'psyq' ); ?></strong> — <?php esc_html_e( 'شماره، متن، نوع پاسخ (گزینه‌ای یا متنی)، زیرمقیاس، تصویر، معکوس، شرط نمایش، گزینه۱ متن/امتیاز/تصویر، …', 'psyq' ); ?></li>
					<li><strong><?php esc_html_e( 'گزینه‌های مشترک', 'psyq' ); ?></strong> — <?php esc_html_e( 'اختیاری؛ برای وقتی همه سوالات گزینه‌های یکسان دارند', 'psyq' ); ?></li>
				</ol>
			</div>
		</div>

		<aside class="psyq-panel-side">
			<div class="psyq-box psyq-box--muted">
				<h3 class="psyq-box__title"><?php esc_html_e( 'نکات کلیدی', 'psyq' ); ?></h3>
				<ul class="psyq-ul">
					<li><?php esc_html_e( 'امتیاز گزینه‌ها از ۵- تا ۷ پذیرفته می‌شود (اعداد فارسی هم مجاز است).', 'psyq' ); ?></li>
					<li><?php esc_html_e( 'تعداد گزینه‌ها می‌تواند در هر سوال متفاوت باشد؛ برای پاسخ نوشتاری در ستون «نوع پاسخ» مقدار «متنی» بنویسید.', 'psyq' ); ?></li>
					<li><?php esc_html_e( 'برای سوال معکوس، ستون «معکوس» را «بله» بگذارید.', 'psyq' ); ?></li>
					<li><?php esc_html_e( 'شرط نمایش: مثل 29=بله یا 29!=خیر.', 'psyq' ); ?></li>
					<li><?php esc_html_e( 'تصویر: آدرس http یا نام فایل در کتابخانه رسانه.', 'psyq' ); ?></li>
					<li><?php esc_html_e( 'اگر می‌خواهید زیرمقیاس‌ها جمع شوند، در برگه زیرمقیاس‌ها ستون «در نمره کل لحاظ شود» را بله کنید.', 'psyq' ); ?></li>
				</ul>
			</div>
			<div class="psyq-box psyq-box--warn">
				<h3 class="psyq-box__title"><?php esc_html_e( 'خطاهای رایج', 'psyq' ); ?></h3>
				<ul class="psyq-ul">
					<li><?php esc_html_e( 'فایل ذخیره‌شده با فرمت xls قدیمی — با «Save as → Excel Workbook (.xlsx)» ذخیره کنید.', 'psyq' ); ?></li>
					<li><?php esc_html_e( 'جابه‌جایی ستون‌ها — سرستون‌ها را تغییر ندهید.', 'psyq' ); ?></li>
					<li><?php esc_html_e( 'نام زیرمقیاس با فاصله اضافه — از همان کد برگه زیرمقیاس‌ها استفاده کنید.', 'psyq' ); ?></li>
				</ul>
			</div>
		</aside>
	</div>
</div>
