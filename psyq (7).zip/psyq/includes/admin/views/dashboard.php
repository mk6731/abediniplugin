<?php
/**
 * پیشخوان افزونه.
 *
 * @package PsyQ
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="wrap psyq-wrap" dir="rtl">
	<h1 class="psyq-page-title">
		<span class="dashicons dashicons-clipboard"></span>
		<?php esc_html_e( 'پرسشنامه‌های روان‌شناسی', 'psyq' ); ?>
		<a class="page-title-action" href="<?php echo esc_url( admin_url( 'admin.php?page=psyq-form' ) ); ?>"><?php esc_html_e( 'افزودن پرسشنامه', 'psyq' ); ?></a>
	</h1>

	<div class="psyq-stats">
		<div class="psyq-stat">
			<span class="psyq-stat__icon dashicons dashicons-forms"></span>
			<div><strong><?php echo esc_html( number_format_i18n( $stats['forms'] ) ); ?></strong><span><?php esc_html_e( 'کل پرسشنامه‌ها', 'psyq' ); ?></span></div>
		</div>
		<div class="psyq-stat">
			<span class="psyq-stat__icon dashicons dashicons-yes-alt"></span>
			<div><strong><?php echo esc_html( number_format_i18n( $stats['published'] ) ); ?></strong><span><?php esc_html_e( 'منتشرشده', 'psyq' ); ?></span></div>
		</div>
		<div class="psyq-stat">
			<span class="psyq-stat__icon dashicons dashicons-editor-help"></span>
			<div><strong><?php echo esc_html( number_format_i18n( $stats['items'] ) ); ?></strong><span><?php esc_html_e( 'کل سوالات', 'psyq' ); ?></span></div>
		</div>
		<div class="psyq-stat">
			<span class="psyq-stat__icon dashicons dashicons-chart-area"></span>
			<div><strong><?php echo esc_html( number_format_i18n( $stats['responses'] ) ); ?></strong><span><?php esc_html_e( 'پاسخ ثبت‌شده', 'psyq' ); ?></span></div>
		</div>
		<div class="psyq-stat">
			<span class="psyq-stat__icon dashicons dashicons-calendar-alt"></span>
			<div><strong><?php echo esc_html( number_format_i18n( $stats['today'] ) ); ?></strong><span><?php esc_html_e( 'پاسخ امروز', 'psyq' ); ?></span></div>
		</div>
	</div>

	<div class="psyq-cards">
		<div class="psyq-card-box">
			<h2><span class="dashicons dashicons-upload"></span> <?php esc_html_e( 'ورود سریع از اکسل', 'psyq' ); ?></h2>
			<p><?php esc_html_e( 'سوالات و گزینه‌های پرسشنامه را در فایل اکسل کپی کنید و یک‌جا بارگذاری نمایید. برای پرسشنامه‌های تا ۴۰۰ سوال مناسب است.', 'psyq' ); ?></p>
			<a class="button button-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=psyq-import' ) ); ?>"><?php esc_html_e( 'بارگذاری فایل اکسل', 'psyq' ); ?></a>
			<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=psyq-templates' ) ); ?>"><?php esc_html_e( 'دریافت قالب خام', 'psyq' ); ?></a>
		</div>
		<div class="psyq-card-box">
			<h2><span class="dashicons dashicons-welcome-add-page"></span> <?php esc_html_e( 'ساخت دستی پرسشنامه', 'psyq' ); ?></h2>
			<p><?php esc_html_e( 'با رابط کاربری کامل: تعداد گزینه دلخواه، امتیاز مجزا برای هر گزینه (‑۵ تا ۷)، تصویر سوال و گزینه، زیرمقیاس و نقاط برش.', 'psyq' ); ?></p>
			<a class="button button-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=psyq-form' ) ); ?>"><?php esc_html_e( 'افزودن پرسشنامه جدید', 'psyq' ); ?></a>
		</div>
	</div>

	<h2 class="psyq-h2-section"><?php esc_html_e( 'آخرین پرسشنامه‌ها', 'psyq' ); ?></h2>
	<div class="psyq-table-wrap">
		<table class="wp-list-table widefat fixed striped psyq-table">
			<thead>
				<tr>
					<th><?php esc_html_e( 'عنوان', 'psyq' ); ?></th>
					<th><?php esc_html_e( 'کد', 'psyq' ); ?></th>
					<th><?php esc_html_e( 'سوالات', 'psyq' ); ?></th>
					<th><?php esc_html_e( 'زیرمقیاس', 'psyq' ); ?></th>
					<th><?php esc_html_e( 'وضعیت', 'psyq' ); ?></th>
					<th><?php esc_html_e( 'شورت‌کد', 'psyq' ); ?></th>
				</tr>
			</thead>
			<tbody>
			<?php if ( empty( $forms ) ) : ?>
				<tr><td colspan="6"><?php esc_html_e( 'هنوز پرسشنامه‌ای ساخته نشده است.', 'psyq' ); ?></td></tr>
			<?php else : ?>
				<?php foreach ( array_slice( $forms, 0, 8 ) as $f ) : ?>
					<tr>
						<td><a href="<?php echo esc_url( admin_url( 'admin.php?page=psyq-form&form_id=' . $f->id ) ); ?>"><strong><?php echo esc_html( $f->title ); ?></strong></a></td>
						<td><code><?php echo esc_html( $f->code ); ?></code></td>
						<td><?php echo esc_html( count( PsyQ_DB::get_items( $f->id ) ) ); ?></td>
						<td><?php echo esc_html( count( PsyQ_DB::get_subscales( $f->id ) ) ); ?></td>
						<td>
							<span class="psyq-badge psyq-badge--<?php echo 'publish' === $f->status ? 'ok' : 'draft'; ?>">
								<?php echo 'publish' === $f->status ? esc_html__( 'منتشرشده', 'psyq' ) : esc_html__( 'پیش‌نویس', 'psyq' ); ?>
							</span>
						</td>
						<td><code class="psyq-copy" title="<?php esc_attr_e( 'کلیک برای کپی', 'psyq' ); ?>">[psyq_form id="<?php echo esc_html( $f->id ); ?>"]</code></td>
					</tr>
				<?php endforeach; ?>
			<?php endif; ?>
			</tbody>
		</table>
	</div>
</div>
