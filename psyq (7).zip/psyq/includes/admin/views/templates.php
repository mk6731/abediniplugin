<?php
/**
 * قالب‌های خام اکسل.
 *
 * @package PsyQ
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="wrap psyq-wrap" dir="rtl">
	<h1 class="psyq-page-title"><span class="dashicons dashicons-media-spreadsheet"></span> <?php esc_html_e( 'قالب خام اکسل پرسشنامه', 'psyq' ); ?></h1>

	<p class="psyq-lead psyq-lead--box">
		<?php esc_html_e( 'متناسب با تعداد گزینه‌های هر پرسشنامه، قالب خام مناسب را دانلود کنید. سوالات و گزینه‌ها را در آن کپی کنید و سپس فایل را در بخش «ورود از اکسل» بارگذاری نمایید. برگه راهنما در هر فایل، توضیح کامل ستون‌ها را دارد.', 'psyq' ); ?>
	</p>

	<div class="psyq-tpl-grid">
		<?php for ( $i = 2; $i <= PsyQ_Excel::MAX_OPTIONS; $i++ ) : ?>
			<div class="psyq-tpl">
				<div class="psyq-tpl__num"><?php echo esc_html( $i ); ?></div>
				<h3><?php echo esc_html( sprintf( __( 'قالب %d گزینه‌ای', 'psyq' ), $i ) ); ?></h3>
				<p class="psyq-muted psyq-small">
					<?php
					$names = array(
						2 => __( 'بله / خیر — مناسب پرسشنامه‌های دو گزینه‌ای', 'psyq' ),
						3 => __( 'سه گزینه‌ای — بله / تا حدودی / خیر', 'psyq' ),
						4 => __( 'چهار گزینه‌ای — لیکرت ۴ درجه', 'psyq' ),
						5 => __( 'پنج گزینه‌ای — لیکرت ۵ درجه (پیشنهادی برای اسپنس)', 'psyq' ),
						6 => __( 'شش گزینه‌ای', 'psyq' ),
						7 => __( 'هفت گزینه‌ای — لیکرت ۷ درجه', 'psyq' ),
					);
					echo esc_html( isset( $names[ $i ] ) ? $names[ $i ] : sprintf( __( 'قالب %d گزینه‌ای سفارشی', 'psyq' ), $i ) );
					?>
				</p>
				<a class="button button-primary" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=psyq_excel&type=template&count=' . $i ), 'psyq_excel' ) ); ?>">
					<span class="dashicons dashicons-download"></span> <?php esc_html_e( 'دانلود قالب', 'psyq' ); ?>
				</a>
			</div>
		<?php endfor; ?>
	</div>

	<div class="psyq-box">
		<h2 class="psyq-box__title"><?php esc_html_e( 'ساخت قالب با تعداد گزینه دلخواه', 'psyq' ); ?></h2>
		<form method="get" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="psyq_excel">
			<input type="hidden" name="type" value="template">
			<?php wp_nonce_field( 'psyq_excel' ); ?>
			<div class="psyq-row">
				<label class="psyq-field">
					<span><?php esc_html_e( 'تعداد گزینه', 'psyq' ); ?></span>
					<input type="number" name="count" min="2" max="<?php echo esc_attr( PsyQ_Excel::MAX_OPTIONS ); ?>" value="4">
				</label>
				<button class="button button-primary"><?php esc_html_e( 'دانلود قالب', 'psyq' ); ?></button>
			</div>
		</form>
	</div>

	<div class="psyq-box psyq-box--warn">
		<h2 class="psyq-box__title"><?php esc_html_e( 'نمونه آماده ۱: PAS والد / پیش‌دبستانی (۳۴ گویه)', 'psyq' ); ?></h2>
		<p class="psyq-muted"><?php esc_html_e( '۲۸ گویه هسته با گزینه‌های ۵ درجه‌ای و امتیاز ۰ تا ۴، سؤال ۲۹ بله/خیر، نمایش مشروط سؤال‌های PTSD (۳۰ تا ۳۴)، کادر اختیاری شرح رویداد، ۶ زیرمقیاس و ۲۷ بازه برش نمونه. نمره کل هسته ۰ تا ۱۱۲ است و PTSD جداگانه گزارش می‌شود.', 'psyq' ); ?></p>
		<a class="button button-primary" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=psyq_excel&type=sample-pas' ), 'psyq_excel' ) ); ?>">
			<span class="dashicons dashicons-download"></span> <?php esc_html_e( 'دانلود نمونه PAS (xlsx)', 'psyq' ); ?>
		</a>
	</div>

	<div class="psyq-box psyq-box--warn">
		<h2 class="psyq-box__title"><?php esc_html_e( 'نمونه آماده ۲: SCAS-Parent استاندارد (۳۸ گویه)', 'psyq' ); ?></h2>
		<p class="psyq-muted"><?php esc_html_e( '۳۸ گویه نمره‌دار با پاسخ‌های هرگز/گاهی/اغلب/همیشه و امتیاز ۰ تا ۳، ۶ زیرمقیاس، نمره کل خام ۰ تا ۱۱۴ و یک سؤال باز اختیاری. نقاط برش خام عمداً خالی است تا فقط پس از انتخاب هنجار معتبر سن/جنس وارد شود.', 'psyq' ); ?></p>
		<a class="button button-primary" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=psyq_excel&type=sample-scas' ), 'psyq_excel' ) ); ?>">
			<span class="dashicons dashicons-download"></span> <?php esc_html_e( 'دانلود نمونه SCAS-Parent (xlsx)', 'psyq' ); ?>
		</a>
	</div>

	<div class="psyq-box">
		<h2 class="psyq-box__title"><?php esc_html_e( 'خروجی گرفتن از پرسشنامه موجود', 'psyq' ); ?></h2>
		<p class="psyq-muted"><?php esc_html_e( 'اگر پرسشنامه‌ای را قبلاً ساخته‌اید و می‌خواهید سوالات را در اکسل ویرایش کنید، از صفحه فهرست پرسشنامه‌ها گزینه «خروجی اکسل پرسشنامه» را بزنید؛ خروجی دقیقاً با همان ساختار قالب خام است و می‌توانید پس از ویرایش دوباره بارگذاری کنید.', 'psyq' ); ?></p>
		<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=psyq-forms' ) ); ?>"><?php esc_html_e( 'رفتن به فهرست پرسشنامه‌ها', 'psyq' ); ?></a>
	</div>
</div>
