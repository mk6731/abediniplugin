<?php
/**
 * فهرست پاسخ‌ها.
 *
 * @package PsyQ
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$pages_total = (int) ceil( $total / max( 1, $per_page ) );
?>
<div class="wrap psyq-wrap" dir="rtl">
	<h1 class="psyq-page-title">
		<span class="dashicons dashicons-chart-area"></span> <?php esc_html_e( 'پاسخ‌ها و نتایج', 'psyq' ); ?>
		<?php if ( $form_id ) : ?>
			<a class="page-title-action" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=psyq_excel&type=results&form_id=' . $form_id ), 'psyq_excel' ) ); ?>"><?php esc_html_e( 'خروجی اکسل نتایج', 'psyq' ); ?></a>
		<?php endif; ?>
	</h1>

	<form method="get" class="psyq-toolbar">
		<input type="hidden" name="page" value="psyq-responses">
		<select name="form_id">
			<option value="0"><?php esc_html_e( 'همه پرسشنامه‌ها', 'psyq' ); ?></option>
			<?php foreach ( $forms as $f ) : ?>
				<option value="<?php echo esc_attr( $f->id ); ?>" <?php selected( $form_id, $f->id ); ?>><?php echo esc_html( $f->title ); ?></option>
			<?php endforeach; ?>
		</select>
		<input type="search" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="<?php esc_attr_e( 'نام، موبایل یا ایمیل…', 'psyq' ); ?>">
		<button class="button"><?php esc_html_e( 'فیلتر', 'psyq' ); ?></button>
		<span class="psyq-muted psyq-small"><?php echo esc_html( sprintf( __( 'مجموع: %s پاسخ', 'psyq' ), number_format_i18n( $total ) ) ); ?></span>
	</form>

	<div class="psyq-table-wrap">
		<table class="psyq-table">
			<thead>
				<tr>
					<th style="width:60px">#</th>
					<th style="width:130px"><?php esc_html_e( 'تاریخ', 'psyq' ); ?></th>
					<th><?php esc_html_e( 'آزمودنی', 'psyq' ); ?></th>
					<th style="width:70px"><?php esc_html_e( 'سن', 'psyq' ); ?></th>
					<th style="width:110px"><?php esc_html_e( 'موبایل', 'psyq' ); ?></th>
					<?php foreach ( $subs as $s ) : ?>
						<th style="width:110px"><?php echo esc_html( $s->title ); ?></th>
					<?php endforeach; ?>
					<th style="width:110px"><?php esc_html_e( 'عملیات', 'psyq' ); ?></th>
				</tr>
			</thead>
			<tbody>
			<?php if ( empty( $rows ) ) : ?>
				<tr><td colspan="<?php echo esc_attr( 6 + count( $subs ) ); ?>"><?php esc_html_e( 'پاسخی ثبت نشده است.', 'psyq' ); ?></td></tr>
			<?php endif; ?>
			<?php foreach ( $rows as $r ) : ?>
				<?php $scores = json_decode( (string) $r->scores, true ); ?>
				<tr>
					<td><?php echo esc_html( $r->id ); ?></td>
					<td class="psyq-small"><?php echo esc_html( mysql2date( 'Y/m/d H:i', $r->created_at ) ); ?></td>
					<td>
						<strong><?php echo esc_html( trim( $r->first_name . ' ' . $r->last_name ) ); ?></strong>
						<?php if ( ! $r->first_name && ! $r->last_name ) : ?>
							<span class="psyq-muted"><?php esc_html_e( 'ناشناس', 'psyq' ); ?></span>
						<?php endif; ?>
					</td>
					<td><?php echo $r->age ? esc_html( $r->age ) : '—'; ?></td>
					<td class="psyq-small"><?php echo esc_html( $r->phone ? $r->phone : '—' ); ?></td>
					<?php foreach ( $subs as $s ) : ?>
						<?php
						$sc = isset( $scores['subscales'][ $s->id ] ) ? $scores['subscales'][ $s->id ] : null;
						?>
						<td>
							<?php if ( $sc ) : ?>
								<strong><?php echo esc_html( PsyQ_Scoring::fmt( $sc['score'] ) ); ?></strong>
								<?php if ( ! empty( $sc['band']['label'] ) ) : ?>
									<span class="psyq-pill" style="background:<?php echo esc_attr( $sc['band']['color'] ); ?>1a;color:<?php echo esc_attr( $sc['band']['color'] ); ?>;border-color:<?php echo esc_attr( $sc['band']['color'] ); ?>55"><?php echo esc_html( $sc['band']['label'] ); ?></span>
								<?php endif; ?>
							<?php else : ?>
								—
							<?php endif; ?>
						</td>
					<?php endforeach; ?>
					<td class="psyq-actions">
						<a class="button button-small" href="<?php echo esc_url( admin_url( 'admin.php?page=psyq-report&response_id=' . $r->id ) ); ?>"><?php esc_html_e( 'کارنامه', 'psyq' ); ?></a>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" onsubmit="return confirm('<?php echo esc_js( __( 'این پاسخ حذف شود؟', 'psyq' ) ); ?>');">
							<?php wp_nonce_field( 'psyq_action' ); ?>
							<input type="hidden" name="action" value="psyq_action">
							<input type="hidden" name="psyq_action" value="delete_response">
							<input type="hidden" name="form_id" value="<?php echo esc_attr( $r->id ); ?>">
							<button class="button button-small psyq-danger">×</button>
						</form>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
	</div>

	<?php if ( $pages_total > 1 ) : ?>
		<div class="tablenav"><div class="tablenav-pages">
			<?php
			echo paginate_links( // phpcs:ignore
				array(
					'base'      => add_query_arg( 'paged', '%#%' ),
					'format'    => '',
					'current'   => $paged,
					'total'     => $pages_total,
					'prev_text' => '‹',
					'next_text' => '›',
				)
			);
			?>
		</div></div>
	<?php endif; ?>
</div>
