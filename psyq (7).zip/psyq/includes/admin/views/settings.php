<?php
/**
 * تنظیمات افزونه.
 *
 * @package PsyQ
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$pages = get_pages();
?>
<div class="wrap psyq-wrap" dir="rtl">
	<h1 class="psyq-page-title"><span class="dashicons dashicons-admin-settings"></span> <?php esc_html_e( 'تنظیمات', 'psyq' ); ?></h1>

	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<?php wp_nonce_field( 'psyq_action' ); ?>
		<input type="hidden" name="action" value="psyq_action">
		<input type="hidden" name="psyq_action" value="save_settings">

		<div class="psyq-panel-grid">
			<div class="psyq-panel-main">
				<div class="psyq-box">
					<h2 class="psyq-box__title"><?php esc_html_e( 'برند و ظاهر', 'psyq' ); ?></h2>
					<div class="psyq-fields">
						<label class="psyq-field">
							<span><?php esc_html_e( 'رنگ اصلی', 'psyq' ); ?></span>
							<input type="color" name="brand_color" value="<?php echo esc_attr( $brand_color ); ?>">
						</label>
						<label class="psyq-field">
							<span><?php esc_html_e( 'آدرس لوگو', 'psyq' ); ?></span>
							<input type="text" name="brand_logo" value="<?php echo esc_attr( $brand_logo ); ?>" placeholder="https://…">
						</label>
					</div>
				</div>

				<div class="psyq-box">
					<h2 class="psyq-box__title"><?php esc_html_e( 'کارنامه و دسترسی', 'psyq' ); ?></h2>
					<div class="psyq-fields">
						<label class="psyq-field">
							<span><?php esc_html_e( 'برگه کارنامه دائمی', 'psyq' ); ?></span>
							<select name="report_page">
								<option value="0"><?php esc_html_e( '— انتخاب نشده —', 'psyq' ); ?></option>
								<?php foreach ( $pages as $p ) : ?>
									<option value="<?php echo esc_attr( $p->ID ); ?>" <?php selected( $report_page, $p->ID ); ?>><?php echo esc_html( $p->post_title ); ?></option>
								<?php endforeach; ?>
							</select>
							<small><?php esc_html_e( 'برگه‌ای که شورت‌کد [psyq_report] در آن قرار دارد؛ لینک دائمی کارنامه به آن اشاره می‌کند.', 'psyq' ); ?></small>
						</label>
						<label class="psyq-check">
							<input type="checkbox" name="allow_guest" value="1" <?php checked( $allow_guest ); ?>>
							<span><?php esc_html_e( 'امکان شرکت مهمانان (کاربران وارد‌نشده)', 'psyq' ); ?></span>
						</label>
						<label class="psyq-field psyq-field--full">
							<span><?php esc_html_e( 'متن سلب مسئولیت (زیر پرسشنامه)', 'psyq' ); ?></span>
							<textarea name="disclaimer" rows="3"><?php echo esc_textarea( $disclaimer ); ?></textarea>
							<small><?php esc_html_e( 'مثلاً: این آزمون جنبه غربالگری دارد و جایگزین تشخیص تخصصی نیست.', 'psyq' ); ?></small>
						</label>
					</div>
				</div>
				<p><button class="button button-primary button-large"><?php esc_html_e( 'ذخیره تنظیمات', 'psyq' ); ?></button></p>
			</div>

			<aside class="psyq-panel-side">
				<div class="psyq-box psyq-box--muted">
					<h3 class="psyq-box__title"><?php esc_html_e( 'وضعیت سیستم', 'psyq' ); ?></h3>
					<ul class="psyq-ul psyq-small">
						<li><?php esc_html_e( 'نسخه افزونه:', 'psyq' ); ?> <strong><?php echo esc_html( PSYQ_VERSION ); ?></strong></li>
						<li><?php esc_html_e( 'نسخه PHP:', 'psyq' ); ?> <strong><?php echo esc_html( PHP_VERSION ); ?></strong></li>
						<li>
							<?php esc_html_e( 'افزونه ZipArchive:', 'psyq' ); ?>
							<strong><?php echo class_exists( 'ZipArchive' ) ? esc_html__( 'فعال ✓', 'psyq' ) : esc_html__( 'غیرفعال ✗', 'psyq' ); ?></strong>
						</li>
						<li><?php esc_html_e( 'حداکثر حجم آپلود:', 'psyq' ); ?> <strong><?php echo esc_html( size_format( wp_max_upload_size() ) ); ?></strong></li>
						<li><?php esc_html_e( 'محدودیت اجرا:', 'psyq' ); ?> <strong><?php echo esc_html( ini_get( 'max_execution_time' ) ); ?>s</strong></li>
					</ul>
					<?php if ( ! class_exists( 'ZipArchive' ) ) : ?>
						<p class="psyq-danger-text"><?php esc_html_e( 'بدون ZipArchive، خواندن و ساخت فایل اکسل ممکن نیست. از هاست بخواهید افزونه php-zip را فعال کند.', 'psyq' ); ?></p>
					<?php endif; ?>
				</div>
				<div class="psyq-box">
					<h3 class="psyq-box__title"><?php esc_html_e( 'شورت‌کدها', 'psyq' ); ?></h3>
					<ul class="psyq-ul psyq-small">
						<li><code class="psyq-copy">[psyq_form id="12"]</code> — <?php esc_html_e( 'نمایش پرسشنامه', 'psyq' ); ?></li>
						<li><code class="psyq-copy">[psyq_form code="SPENCE"]</code> — <?php esc_html_e( 'با کد پرسشنامه', 'psyq' ); ?></li>
						<li><code class="psyq-copy">[psyq_report]</code> — <?php esc_html_e( 'صفحه کارنامه دائمی', 'psyq' ); ?></li>
						<li><code class="psyq-copy">[psyq_list]</code> — <?php esc_html_e( 'فهرست پرسشنامه‌های منتشرشده', 'psyq' ); ?></li>
					</ul>
				</div>
			</aside>
		</div>
	</form>
</div>
