<?php
/**
 * گزارش یک آزمودنی در پنل.
 *
 * @package PsyQ
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="wrap psyq-wrap" dir="rtl">
	<h1 class="psyq-page-title">
		<span class="dashicons dashicons-analytics"></span> <?php esc_html_e( 'کارنامه آزمودنی', 'psyq' ); ?>
		<?php if ( $response ) : ?>
			<a class="page-title-action" href="<?php echo esc_url( admin_url( 'admin.php?page=psyq-responses&form_id=' . (int) $response->form_id ) ); ?>"><?php esc_html_e( 'بازگشت به پاسخ‌ها', 'psyq' ); ?></a>
		<?php endif; ?>
	</h1>

	<?php if ( ! $response ) : ?>
		<div class="psyq-empty-box">
			<p><?php esc_html_e( 'برای مشاهده کارنامه، یکی از پاسخ‌ها را در صفحه «پاسخ‌ها و نتایج» انتخاب کنید.', 'psyq' ); ?></p>
			<a class="button button-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=psyq-responses' ) ); ?>"><?php esc_html_e( 'رفتن به پاسخ‌ها', 'psyq' ); ?></a>
		</div>
	<?php else : ?>
		<div class="psyq-report-tools">
			<button type="button" class="button" onclick="window.print()"><?php esc_html_e( 'چاپ / PDF', 'psyq' ); ?></button>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php wp_nonce_field( 'psyq_action' ); ?>
				<input type="hidden" name="action" value="psyq_action">
				<input type="hidden" name="psyq_action" value="rescore_response">
				<input type="hidden" name="form_id" value="<?php echo esc_attr( $response->id ); ?>">
				<button class="button"><?php esc_html_e( 'بازمحاسبه نمرات', 'psyq' ); ?></button>
			</form>
			<span class="psyq-muted psyq-small">
				<?php echo esc_html( sprintf( __( 'مدت پاسخ‌دهی: %s ثانیه', 'psyq' ), number_format_i18n( $response->duration_sec ) ) ); ?>
			</span>
		</div>
		<div class="psyq-report-container">
			<?php echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		</div>
	<?php endif; ?>
</div>
<?php if ( $response ) : ?>
	<script>
	document.addEventListener('DOMContentLoaded', function(){
		if (window.PsyQFront && window.PsyQFront.initCharts) { window.PsyQFront.initCharts(document); }
	});
	</script>
<?php endif; ?>
