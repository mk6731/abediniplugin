<?php
/**
 * ایجاد پرسشنامه جدید.
 *
 * @package PsyQ
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="wrap psyq-wrap" dir="rtl">
	<h1 class="psyq-page-title"><span class="dashicons dashicons-plus-alt2"></span> <?php esc_html_e( 'افزودن پرسشنامه جدید', 'psyq' ); ?></h1>

	<div class="psyq-cards psyq-cards--3">
		<div class="psyq-card-box">
			<h2><span class="dashicons dashicons-welcome-add-page"></span> <?php esc_html_e( 'ساخت دستی', 'psyq' ); ?></h2>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php wp_nonce_field( 'psyq_action' ); ?>
				<input type="hidden" name="action" value="psyq_action">
				<input type="hidden" name="psyq_action" value="save_form">
				<p>
					<label class="psyq-field psyq-field--full">
						<span><?php esc_html_e( 'عنوان پرسشنامه', 'psyq' ); ?> <i>*</i></span>
						<input type="text" name="title" required placeholder="<?php esc_attr_e( 'مثلاً مقیاس اضطراب کودکان اسپنس', 'psyq' ); ?>">
					</label>
				</p>
				<p>
					<label class="psyq-field psyq-field--full">
						<span><?php esc_html_e( 'تعداد گزینه‌ها', 'psyq' ); ?></span>
						<select name="default_option_count">
							<?php for ( $i = 2; $i <= PsyQ_Excel::MAX_OPTIONS; $i++ ) : ?>
								<option value="<?php echo esc_attr( $i ); ?>" <?php selected( 4, $i ); ?>><?php echo esc_html( sprintf( __( '%d گزینه‌ای', 'psyq' ), $i ) ); ?></option>
							<?php endfor; ?>
						</select>
					</label>
				</p>
				<button type="submit" class="button button-primary button-large psyq-w100"><?php esc_html_e( 'ساخت و ادامه', 'psyq' ); ?></button>
			</form>
		</div>

		<div class="psyq-card-box">
			<h2><span class="dashicons dashicons-upload"></span> <?php esc_html_e( 'ورود از فایل اکسل', 'psyq' ); ?></h2>
			<p><?php esc_html_e( 'اگر سوالات را در اکسل آماده کرده‌اید، از این بخش یک‌جا وارد کنید. برای پرسشنامه‌های بزرگ (تا ۴۰۰ سوال) سریع‌ترین روش است.', 'psyq' ); ?></p>
			<p>
				<a class="button button-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=psyq-import' ) ); ?>"><?php esc_html_e( 'بارگذاری فایل', 'psyq' ); ?></a>
				<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=psyq-templates' ) ); ?>"><?php esc_html_e( 'دریافت قالب خام', 'psyq' ); ?></a>
			</p>
		</div>

		<div class="psyq-card-box">
			<h2><span class="dashicons dashicons-database-import"></span> <?php esc_html_e( 'شروع از نمونه آماده', 'psyq' ); ?></h2>
			<p><strong><?php esc_html_e( '۱) نسخه ۳۴ گویه‌ای پیش‌دبستانی/والد (PAS)', 'psyq' ); ?></strong></p>
			<p class="psyq-small"><?php esc_html_e( '۲۸ گویه هسته با طیف ۰ تا ۴، سؤال ۲۹ دروازه‌ای، PTSD مشروط، شرح اختیاری رویداد و نمره کل هسته ۰ تا ۱۱۲.', 'psyq' ); ?></p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php wp_nonce_field( 'psyq_action' ); ?>
				<input type="hidden" name="action" value="psyq_action">
				<input type="hidden" name="psyq_action" value="create_sample">
				<input type="hidden" name="sample_type" value="pas34">
				<button type="submit" class="button button-primary"><?php esc_html_e( 'ساخت نمونه PAS (۳۴ گویه)', 'psyq' ); ?></button>
			</form>
			<hr>
			<p><strong><?php esc_html_e( '۲) SCAS-Parent استاندارد (۳۸ گویه)', 'psyq' ); ?></strong></p>
			<p class="psyq-small"><?php esc_html_e( '۳۸ گویه نمره‌دار با طیف هرگز تا همیشه (۰ تا ۳)، ۶ زیرمقیاس، نمره کل ۰ تا ۱۱۴ و سؤال باز اختیاری.', 'psyq' ); ?></p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php wp_nonce_field( 'psyq_action' ); ?>
				<input type="hidden" name="action" value="psyq_action">
				<input type="hidden" name="psyq_action" value="create_sample">
				<input type="hidden" name="sample_type" value="scasp38">
				<button type="submit" class="button button-primary"><?php esc_html_e( 'ساخت نمونه SCAS-Parent', 'psyq' ); ?></button>
			</form>
			<p class="psyq-small psyq-muted"><?php esc_html_e( 'برای کاربرد بالینی، متن فارسی و هنجارهای سن/جنس را با منبع معتبر و نظر متخصص تطبیق دهید.', 'psyq' ); ?></p>
		</div>
	</div>

</div>

