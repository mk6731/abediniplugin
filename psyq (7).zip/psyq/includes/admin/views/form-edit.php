<?php
/**
 * ویرایش پرسشنامه.
 *
 * @package PsyQ
 *
 * @var array  $bundle
 * @var string $tab
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$form = $bundle['form'];
$subs = $bundle['subscales'];
$items = $bundle['items'];
$total = $bundle['total'];
$form_id = (int) $form->id;

$base_url = admin_url( 'admin.php?page=psyq-form&form_id=' . $form_id );
$tabs     = array(
	'settings'  => array( 'label' => __( 'تنظیمات پرسشنامه', 'psyq' ), 'icon' => 'admin-generic' ),
	'items'     => array( 'label' => __( 'سوالات و گزینه‌ها', 'psyq' ), 'icon' => 'editor-ul' ),
	'subscales' => array( 'label' => __( 'زیرمقیاس‌ها و نقاط برش', 'psyq' ), 'icon' => 'networking' ),
	'preview'   => array( 'label' => __( 'پیش‌نمایش گزارش', 'psyq' ), 'icon' => 'chart-bar' ),
);
if ( ! isset( $tabs[ $tab ] ) ) {
	$tab = 'settings';
}

$option_presets = PsyQ_DB::option_presets();
?>
<div class="wrap psyq-wrap psyq-formedit" dir="rtl">

	<h1 class="psyq-page-title">
		<span class="dashicons dashicons-forms"></span>
		<?php echo esc_html( $form->title ); ?>
		<span class="psyq-badge psyq-badge--<?php echo 'publish' === $form->status ? 'ok' : 'draft'; ?>">
			<?php echo 'publish' === $form->status ? esc_html__( 'منتشرشده', 'psyq' ) : esc_html__( 'پیش‌نویس', 'psyq' ); ?>
		</span>
		<a class="page-title-action" href="<?php echo esc_url( admin_url( 'admin.php?page=psyq-forms' ) ); ?>"><?php esc_html_e( 'بازگشت به فهرست', 'psyq' ); ?></a>
	</h1>

	<div class="psyq-summary">
		<div><strong><?php echo esc_html( count( $items ) ); ?></strong><span><?php esc_html_e( 'سوال', 'psyq' ); ?></span></div>
		<div><strong><?php echo esc_html( count( $subs ) ); ?></strong><span><?php esc_html_e( 'زیرمقیاس', 'psyq' ); ?></span></div>
		<div><strong><?php echo esc_html( $form->default_option_count ); ?></strong><span><?php esc_html_e( 'گزینه پیش‌فرض', 'psyq' ); ?></span></div>
		<div><strong><?php echo esc_html( PsyQ_DB::count_responses( array( 'form_id' => $form_id ) ) ); ?></strong><span><?php esc_html_e( 'پاسخ ثبت‌شده', 'psyq' ); ?></span></div>
		<div class="psyq-summary__code">
			<span><?php esc_html_e( 'شورت‌کد', 'psyq' ); ?></span>
			<code class="psyq-copy">[psyq_form id="<?php echo esc_html( $form_id ); ?>"]</code>
		</div>
	</div>

	<nav class="nav-tab-wrapper psyq-tabs">
		<?php foreach ( $tabs as $key => $t ) : ?>
			<a class="nav-tab <?php echo $tab === $key ? 'nav-tab-active' : ''; ?>" href="<?php echo esc_url( $base_url . '&tab=' . $key ); ?>">
				<span class="dashicons dashicons-<?php echo esc_attr( $t['icon'] ); ?>"></span> <?php echo esc_html( $t['label'] ); ?>
			</a>
		<?php endforeach; ?>
	</nav>

	<?php if ( 'settings' === $tab ) : ?>
	<!-- ============================ تنظیمات ============================ -->
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="psyq-panel">
		<?php wp_nonce_field( 'psyq_action' ); ?>
		<input type="hidden" name="action" value="psyq_action">
		<input type="hidden" name="psyq_action" value="save_form">
		<input type="hidden" name="form_id" value="<?php echo esc_attr( $form_id ); ?>">

		<div class="psyq-panel-grid">
			<div class="psyq-panel-main">

				<div class="psyq-box">
					<h2 class="psyq-box__title"><?php esc_html_e( 'اطلاعات پایه', 'psyq' ); ?></h2>
					<div class="psyq-fields">
						<label class="psyq-field psyq-field--full">
							<span><?php esc_html_e( 'عنوان پرسشنامه', 'psyq' ); ?> <i>*</i></span>
							<input type="text" name="title" required value="<?php echo esc_attr( $form->title ); ?>">
						</label>
						<label class="psyq-field">
							<span><?php esc_html_e( 'کد پرسشنامه', 'psyq' ); ?></span>
							<input type="text" name="code" value="<?php echo esc_attr( $form->code ); ?>" placeholder="SPENCE-PARENT">
							<small><?php esc_html_e( 'کد یکتا برای شناسایی در اکسل و API', 'psyq' ); ?></small>
						</label>
						<label class="psyq-field">
							<span><?php esc_html_e( 'وضعیت', 'psyq' ); ?></span>
							<select name="status">
								<option value="draft" <?php selected( $form->status, 'draft' ); ?>><?php esc_html_e( 'پیش‌نویس', 'psyq' ); ?></option>
								<option value="publish" <?php selected( $form->status, 'publish' ); ?>><?php esc_html_e( 'منتشرشده', 'psyq' ); ?></option>
								<option value="private" <?php selected( $form->status, 'private' ); ?>><?php esc_html_e( 'خصوصی', 'psyq' ); ?></option>
							</select>
						</label>
						<label class="psyq-field psyq-field--full">
							<span><?php esc_html_e( 'توضیحات کوتاه', 'psyq' ); ?></span>
							<textarea name="description" rows="3"><?php echo esc_textarea( $form->description ); ?></textarea>
						</label>
					</div>
				</div>

				<div class="psyq-box">
					<h2 class="psyq-box__title"><?php esc_html_e( 'ساختار پاسخ‌دهی و امتیازدهی', 'psyq' ); ?></h2>
					<div class="psyq-fields">
						<label class="psyq-field">
							<span><?php esc_html_e( 'تعداد گزینه‌های پرسشنامه', 'psyq' ); ?></span>
							<select name="default_option_count" id="psyq-default-count">
								<?php for ( $i = 2; $i <= PsyQ_Excel::MAX_OPTIONS; $i++ ) : ?>
									<option value="<?php echo esc_attr( $i ); ?>" <?php selected( (int) $form->default_option_count, $i ); ?>>
										<?php echo esc_html( sprintf( __( '%d گزینه‌ای', 'psyq' ), $i ) ); ?>
									</option>
								<?php endfor; ?>
							</select>
							<small><?php esc_html_e( 'قالب پیش‌فرض برای سوالات جدید و قالب اکسل خروجی', 'psyq' ); ?></small>
						</label>
						<label class="psyq-field">
							<span><?php esc_html_e( 'حالت امتیازدهی', 'psyq' ); ?></span>
							<select name="scoring_mode">
								<?php foreach ( PsyQ_DB::scoring_modes() as $k => $label ) : ?>
									<option value="<?php echo esc_attr( $k ); ?>" <?php selected( $form->scoring_mode, $k ); ?>><?php echo esc_html( $label ); ?></option>
								<?php endforeach; ?>
							</select>
						</label>
						<label class="psyq-field">
							<span><?php esc_html_e( 'تعداد سوال در هر صفحه', 'psyq' ); ?></span>
							<input type="number" name="items_per_page" min="1" max="400" value="<?php echo esc_attr( $form->items_per_page ); ?>">
						</label>
						<label class="psyq-field">
							<span><?php esc_html_e( 'مدت تقریبی (دقیقه)', 'psyq' ); ?></span>
							<input type="number" name="duration_minutes" min="0" max="600" value="<?php echo esc_attr( $form->duration_minutes ); ?>">
						</label>
					</div>
				</div>

				<div class="psyq-box">
					<h2 class="psyq-box__title"><?php esc_html_e( 'گزارش و تفسیر', 'psyq' ); ?></h2>
					<div class="psyq-fields">
						<label class="psyq-check">
							<input type="checkbox" name="show_total" value="1" <?php checked( $form->show_total ); ?>>
							<span><?php esc_html_e( 'نمایش «نمره کل» با جمع زیرمقیاس‌ها', 'psyq' ); ?></span>
						</label>
						<label class="psyq-check">
							<input type="checkbox" name="show_charts" value="1" <?php checked( $form->show_charts ); ?>>
							<span><?php esc_html_e( 'نمایش نمودار میله‌ای و هیستوگرام در کارنامه', 'psyq' ); ?></span>
						</label>
						<label class="psyq-field">
							<span><?php esc_html_e( 'موتور نمودار', 'psyq' ); ?></span>
							<select name="chart_engine">
								<option value="both" <?php selected( $form->chart_engine, 'both' ); ?>><?php esc_html_e( 'SVG + تعاملی (پیشنهادی)', 'psyq' ); ?></option>
								<option value="svg" <?php selected( $form->chart_engine, 'svg' ); ?>><?php esc_html_e( 'فقط SVG (چاپ‌پذیر)', 'psyq' ); ?></option>
								<option value="chartjs" <?php selected( $form->chart_engine, 'chartjs' ); ?>><?php esc_html_e( 'فقط تعاملی (Chart.js)', 'psyq' ); ?></option>
							</select>
						</label>
						<label class="psyq-field psyq-field--full">
							<span><?php esc_html_e( 'متن معرفی (بالای پرسشنامه)', 'psyq' ); ?></span>
							<textarea name="intro_html" rows="4"><?php echo esc_textarea( $form->intro_html ); ?></textarea>
						</label>
						<label class="psyq-field psyq-field--full">
							<span><?php esc_html_e( 'متن رضایت‌نامه (با تیک تأیید اجباری)', 'psyq' ); ?></span>
							<textarea name="consent_html" rows="3"><?php echo esc_textarea( $form->consent_html ); ?></textarea>
						</label>
						<label class="psyq-field psyq-field--full">
							<span><?php esc_html_e( 'متن پایان کارنامه (راهکارها، معرفی کتاب و…)', 'psyq' ); ?></span>
							<textarea name="report_footer_html" rows="6"><?php echo esc_textarea( $form->report_footer_html ); ?></textarea>
							<small><?php esc_html_e( 'این متن در پایان کارنامه نمایش داده می‌شود؛ مناسب معرفی کتاب و پیشنهادهای درمانی.', 'psyq' ); ?></small>
						</label>
					</div>
				</div>

				<div class="psyq-box">
					<h2 class="psyq-box__title"><?php esc_html_e( 'تنظیمات اجرا', 'psyq' ); ?></h2>
					<div class="psyq-fields psyq-fields--2">
						<label class="psyq-check"><input type="checkbox" name="require_all" value="1" <?php checked( $form->require_all ); ?>><span><?php esc_html_e( 'پاسخ به همه سوالات اجباری باشد', 'psyq' ); ?></span></label>
						<label class="psyq-check"><input type="checkbox" name="allow_back" value="1" <?php checked( $form->allow_back ); ?>><span><?php esc_html_e( 'امکان بازگشت به سوال قبلی', 'psyq' ); ?></span></label>
						<label class="psyq-check"><input type="checkbox" name="collect_name" value="1" <?php checked( $form->collect_name ); ?>><span><?php esc_html_e( 'دریافت نام و نام خانوادگی', 'psyq' ); ?></span></label>
						<label class="psyq-check"><input type="checkbox" name="collect_demographics" value="1" <?php checked( $form->collect_demographics ); ?>><span><?php esc_html_e( 'دریافت مشخصات جمعیت‌شناختی', 'psyq' ); ?></span></label>
						<label class="psyq-check"><input type="checkbox" name="randomize_items" value="1" <?php checked( $form->randomize_items ); ?>><span><?php esc_html_e( 'ترتیب تصادفی سوالات', 'psyq' ); ?></span></label>
						<label class="psyq-check"><input type="checkbox" name="randomize_options" value="1" <?php checked( $form->randomize_options ); ?>><span><?php esc_html_e( 'ترتیب تصادفی گزینه‌ها', 'psyq' ); ?></span></label>
					</div>
				</div>

			</div>

			<aside class="psyq-panel-side">
				<div class="psyq-box">
					<h2 class="psyq-box__title"><?php esc_html_e( 'اقدامات', 'psyq' ); ?></h2>
					<button type="submit" class="button button-primary button-large psyq-w100"><?php esc_html_e( 'ذخیره تغییرات', 'psyq' ); ?></button>
					<hr>
					<a class="button psyq-w100" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=psyq_excel&type=export&form_id=' . $form_id ), 'psyq_excel' ) ); ?>"><?php esc_html_e( 'دریافت اکسل پرسشنامه', 'psyq' ); ?></a>
					<a class="button psyq-w100" href="<?php echo esc_url( admin_url( 'admin.php?page=psyq-import&form_id=' . $form_id ) ); ?>"><?php esc_html_e( 'بارگذاری اکسل در این پرسشنامه', 'psyq' ); ?></a>
					<a class="button psyq-w100" href="<?php echo esc_url( admin_url( 'admin.php?page=psyq-responses&form_id=' . $form_id ) ); ?>"><?php esc_html_e( 'مشاهده پاسخ‌ها', 'psyq' ); ?></a>
				</div>
				<div class="psyq-box psyq-box--muted">
					<h3 class="psyq-box__title"><?php esc_html_e( 'راهنمای نمایش در سایت', 'psyq' ); ?></h3>
					<p><?php esc_html_e( 'برای نمایش این پرسشنامه، شورت‌کد زیر را در برگه یا نوشته قرار دهید:', 'psyq' ); ?></p>
					<code class="psyq-copy psyq-codeblock">[psyq_form id="<?php echo esc_html( $form_id ); ?>"]</code>
					<p class="psyq-small"><?php esc_html_e( 'برای صفحه دائمی کارنامه، یک برگه بسازید و شورت‌کد [psyq_report] را در آن قرار دهید و سپس در تنظیمات افزونه آن را انتخاب کنید.', 'psyq' ); ?></p>
				</div>
			</aside>
		</div>
	</form>

	<?php elseif ( 'items' === $tab ) : ?>
	<!-- ============================ سوالات ============================ -->
	<div class="psyq-toolbar psyq-toolbar--sticky">
		<button type="button" class="button button-primary psyq-add-item"><?php esc_html_e( '+ افزودن سوال', 'psyq' ); ?></button>
		<button type="button" class="button psyq-bulk-import"><?php esc_html_e( 'افزودن گروهی (چند سوال یک‌جا)', 'psyq' ); ?></button>
		<span class="psyq-toolbar__sep"></span>
		<select class="psyq-filter-sub">
			<option value=""><?php esc_html_e( 'همه زیرمقیاس‌ها', 'psyq' ); ?></option>
			<?php foreach ( $subs as $s ) : ?>
				<option value="<?php echo esc_attr( $s['id'] ); ?>"><?php echo esc_html( $s['title'] ); ?></option>
			<?php endforeach; ?>
		</select>
		<input type="search" class="psyq-search-items" placeholder="<?php esc_attr_e( 'جست‌وجو در متن سوال…', 'psyq' ); ?>">
		<span class="psyq-toolbar__sep"></span>
		<a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=psyq_excel&type=export&form_id=' . $form_id ), 'psyq_excel' ) ); ?>"><?php esc_html_e( 'خروجی اکسل', 'psyq' ); ?></a>
		<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=psyq-import&form_id=' . $form_id ) ); ?>"><?php esc_html_e( 'ورود از اکسل', 'psyq' ); ?></a>
	</div>

	<div class="psyq-table-wrap">
		<table class="psyq-table psyq-table--items">
			<thead>
				<tr>
					<th style="width:34px"></th>
					<th style="width:56px"><?php esc_html_e( 'شماره', 'psyq' ); ?></th>
					<th><?php esc_html_e( 'متن سوال', 'psyq' ); ?></th>
					<th style="width:170px"><?php esc_html_e( 'زیرمقیاس', 'psyq' ); ?></th>
					<th style="width:330px"><?php esc_html_e( 'گزینه‌ها و امتیازها', 'psyq' ); ?></th>
					<th style="width:150px"><?php esc_html_e( 'عملیات', 'psyq' ); ?></th>
				</tr>
			</thead>
			<tbody class="psyq-items-body" data-form="<?php echo esc_attr( $form_id ); ?>">
				<?php if ( empty( $items ) ) : ?>
					<tr class="psyq-empty"><td colspan="6"><?php esc_html_e( 'هنوز سوالی اضافه نشده است. از دکمه «افزودن سوال» یا «ورود از اکسل» استفاده کنید.', 'psyq' ); ?></td></tr>
				<?php endif; ?>
				<?php foreach ( $items as $item ) : ?>
					<?php echo PsyQ_Ajax::item_row_html( $item, $bundle ); // phpcs:ignore ?>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>
	<p class="psyq-muted psyq-small"><?php esc_html_e( 'برای تغییر ترتیب، ردیف‌ها را با دستگیره سمت راست بکشید. تغییرات ترتیب به‌صورت خودکار ذخیره می‌شود.', 'psyq' ); ?></p>

	<?php elseif ( 'subscales' === $tab ) : ?>
	<!-- ============================ زیرمقیاس‌ها ============================ -->
	<div class="psyq-toolbar">
		<button type="button" class="button button-primary psyq-add-subscale"><?php esc_html_e( '+ افزودن زیرمقیاس', 'psyq' ); ?></button>
		<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=psyq-import&form_id=' . $form_id ) ); ?>"><?php esc_html_e( 'تعریف گروهی با اکسل', 'psyq' ); ?></a>
		<span class="psyq-muted psyq-small"><?php esc_html_e( 'برای هر زیرمقیاس می‌توانید تا ۳ نقطه برش (۴ بازه) و تفسیر مستقل تعریف کنید.', 'psyq' ); ?></span>
	</div>

	<div class="psyq-subs" data-form="<?php echo esc_attr( $form_id ); ?>">
		<?php
		$sub_list = $subs;
		if ( $total ) {
			$sub_list[ $total['id'] ] = array(
				'id'               => $total['id'],
				'name'             => '__TOTAL__',
				'title'            => $total['title'],
				'description'      => '',
				'color'            => $total['color'],
				'sort_order'       => 999,
				'include_in_total' => 1,
				'bands'            => $total['bands'],
				'is_total'         => true,
			);
		}
		?>
		<?php if ( empty( $sub_list ) ) : ?>
			<div class="psyq-empty-box"><?php esc_html_e( 'هنوز زیرمقیاسی تعریف نشده است. با دکمه بالا اولین زیرمقیاس را اضافه کنید.', 'psyq' ); ?></div>
		<?php endif; ?>

		<?php foreach ( $sub_list as $s ) : ?>
			<?php $is_total = ! empty( $s['is_total'] ); ?>
			<div class="psyq-sub" data-sub-id="<?php echo esc_attr( $s['id'] ); ?>" data-is-total="<?php echo $is_total ? '1' : '0'; ?>">
				<header class="psyq-sub__head">
					<span class="psyq-sub__swatch" style="background:<?php echo esc_attr( $s['color'] ); ?>"></span>
					<input type="text" class="psyq-sub__title" value="<?php echo esc_attr( $s['title'] ); ?>" placeholder="<?php esc_attr_e( 'عنوان زیرمقیاس', 'psyq' ); ?>" <?php echo $is_total ? 'readonly' : ''; ?>>
					<?php if ( ! $is_total ) : ?>
						<input type="text" class="psyq-sub__name" value="<?php echo esc_attr( $s['name'] ); ?>" placeholder="<?php esc_attr_e( 'کد', 'psyq' ); ?>" title="<?php esc_attr_e( 'کد یکتا (در اکسل به این کد ارجاع داده می‌شود)', 'psyq' ); ?>">
						<label class="psyq-check psyq-check--sm">
							<input type="checkbox" class="psyq-sub__intotal" value="1" <?php checked( ! empty( $s['include_in_total'] ) ); ?>>
							<span><?php esc_html_e( 'در نمره کل لحاظ شود', 'psyq' ); ?></span>
						</label>
					<?php else : ?>
						<span class="psyq-chip psyq-chip--dark"><?php esc_html_e( 'نمره کل (مجموع زیرمقیاس‌های تیک‌خورده)', 'psyq' ); ?></span>
					<?php endif; ?>
					<input type="color" class="psyq-sub__color" value="<?php echo esc_attr( $s['color'] ); ?>" title="<?php esc_attr_e( 'رنگ نمودار', 'psyq' ); ?>">
					<?php
					$counts = array_count_values( wp_list_pluck( $items, 'subscale_id' ) );
					$cnt    = isset( $counts[ (int) $s['id'] ] ) ? (int) $counts[ (int) $s['id'] ] : 0;
					?>
					<span class="psyq-sub__count"><?php echo esc_html( $cnt ); ?> <?php esc_html_e( 'سوال', 'psyq' ); ?></span>
					<button type="button" class="button button-small psyq-sub__save"><?php esc_html_e( 'ذخیره', 'psyq' ); ?></button>
					<?php if ( ! $is_total ) : ?>
						<button type="button" class="button button-small psyq-sub__delete"><?php esc_html_e( 'حذف', 'psyq' ); ?></button>
					<?php endif; ?>
				</header>

				<div class="psyq-sub__body">
					<textarea class="psyq-sub__desc" rows="2" placeholder="<?php esc_attr_e( 'توضیح کوتاه زیرمقیاس (اختیاری) — در کارنامه نمایش داده می‌شود', 'psyq' ); ?>"><?php echo esc_textarea( $s['description'] ); ?></textarea>

					<div class="psyq-bands">
						<div class="psyq-bands__head">
							<span><?php esc_html_e( 'بازه', 'psyq' ); ?></span>
							<span><?php esc_html_e( 'از (شامل)', 'psyq' ); ?></span>
							<span><?php esc_html_e( 'تا (غیرشامل)', 'psyq' ); ?></span>
							<span><?php esc_html_e( 'برچسب سطح', 'psyq' ); ?></span>
							<span><?php esc_html_e( 'رنگ', 'psyq' ); ?></span>
							<span><?php esc_html_e( 'تفسیر اختصاصی این بازه', 'psyq' ); ?></span>
							<span></span>
						</div>
						<div class="psyq-bands__rows">
							<?php
							$bands = ! empty( $s['bands'] ) ? $s['bands'] : array();
							if ( empty( $bands ) ) {
								$bands = PsyQ_Scoring::suggest_bands( 10, 4 );
							}
							foreach ( $bands as $bi => $b ) :
								?>
								<div class="psyq-band">
									<span class="psyq-band__idx"><?php echo esc_html( $bi + 1 ); ?></span>
									<input type="number" step="0.01" class="psyq-band__min" value="<?php echo esc_attr( $b['min'] ); ?>">
									<input type="number" step="0.01" class="psyq-band__max" value="<?php echo esc_attr( (float) $b['max'] >= 99999 ? '' : $b['max'] ); ?>" placeholder="∞">
									<input type="text" class="psyq-band__label" value="<?php echo esc_attr( $b['label'] ); ?>" placeholder="<?php esc_attr_e( 'مثلاً متوسط', 'psyq' ); ?>">
									<input type="color" class="psyq-band__color" value="<?php echo esc_attr( $b['color'] ); ?>">
									<textarea class="psyq-band__interp" rows="2" placeholder="<?php esc_attr_e( 'متنی که برای فردی با نمره در این بازه نمایش داده می‌شود…', 'psyq' ); ?>"><?php echo esc_textarea( $b['interpretation'] ); ?></textarea>
									<button type="button" class="psyq-band__del" title="<?php esc_attr_e( 'حذف بازه', 'psyq' ); ?>">×</button>
								</div>
							<?php endforeach; ?>
						</div>
						<div class="psyq-bands__foot">
							<button type="button" class="button button-small psyq-band__add"><?php esc_html_e( '+ افزودن بازه', 'psyq' ); ?></button>
							<button type="button" class="button button-small psyq-band__suggest"><?php esc_html_e( 'پیشنهاد خودکار ۴ بازه', 'psyq' ); ?></button>
							<span class="psyq-muted psyq-small"><?php esc_html_e( 'در متن تفسیر می‌توانید از متغیرهای {score}، {max}، {percent}، {name} استفاده کنید.', 'psyq' ); ?></span>
						</div>
					</div>
				</div>
			</div>
		<?php endforeach; ?>
	</div>

	<?php else : ?>
	<!-- ============================ پیش‌نمایش ============================ -->
	<div class="psyq-toolbar">
		<button type="button" class="button button-primary" id="psyq-preview-mid"><?php esc_html_e( 'تولید کارنامه با پاسخ‌های میانه', 'psyq' ); ?></button>
		<button type="button" class="button" id="psyq-preview-random"><?php esc_html_e( 'تولید کارنامه با پاسخ‌های تصادفی', 'psyq' ); ?></button>
		<span class="psyq-muted psyq-small"><?php esc_html_e( 'برای بازبینی نقاط برش، متن تفسیر و نمودارها پیش از انتشار.', 'psyq' ); ?></span>
	</div>
	<div id="psyq-preview-box" class="psyq-preview-box">
		<div class="psyq-empty-box"><?php esc_html_e( 'یکی از دکمه‌های بالا را بزنید تا کارنامه نمونه تولید شود.', 'psyq' ); ?></div>
	</div>

	<?php endif; ?>
</div>

<!-- ================== مودال ویرایش سوال ================== -->
<div class="psyq-modal" id="psyq-item-modal" hidden style="display:none" aria-hidden="true">
	<div class="psyq-modal__overlay"></div>
	<div class="psyq-modal__dialog" role="dialog" aria-modal="true">
		<header class="psyq-modal__head">
			<h2><?php esc_html_e( 'ویرایش سوال', 'psyq' ); ?></h2>
			<button type="button" class="psyq-modal__close" aria-label="<?php esc_attr_e( 'بستن', 'psyq' ); ?>" title="<?php esc_attr_e( 'بستن', 'psyq' ); ?>">×</button>
		</header>
		<div class="psyq-modal__body">
			<input type="hidden" id="psyq-item-id" value="0">
			<div class="psyq-fields psyq-fields--2">
				<label class="psyq-field">
					<span><?php esc_html_e( 'شماره سوال', 'psyq' ); ?></span>
					<input type="number" id="psyq-item-number" min="1">
				</label>
				<label class="psyq-field">
					<span><?php esc_html_e( 'زیرمقیاس', 'psyq' ); ?></span>
					<select id="psyq-item-subscale">
						<option value="0"><?php esc_html_e( '— بدون زیرمقیاس —', 'psyq' ); ?></option>
						<?php foreach ( $subs as $s ) : ?>
							<option value="<?php echo esc_attr( $s['id'] ); ?>"><?php echo esc_html( $s['title'] ); ?></option>
						<?php endforeach; ?>
					</select>
				</label>
				<label class="psyq-field">
					<span><?php esc_html_e( 'نوع پاسخ', 'psyq' ); ?></span>
					<select id="psyq-item-answer-type">
						<option value="choice"><?php esc_html_e( 'گزینه‌ای و نمره‌دار', 'psyq' ); ?></option>
						<option value="text"><?php esc_html_e( 'متن آزاد (بدون نمره)', 'psyq' ); ?></option>
					</select>
					<small><?php esc_html_e( 'برای شرح حادثه، توضیح تکمیلی و سؤال‌های باز مناسب است.', 'psyq' ); ?></small>
				</label>
			</div>
			<label class="psyq-field psyq-field--full">
				<span><?php esc_html_e( 'متن سوال', 'psyq' ); ?> <i>*</i></span>
				<textarea id="psyq-item-text" rows="3"></textarea>
			</label>

			<div class="psyq-field-row">
				<div class="psyq-imgfield">
					<span class="psyq-field__label"><?php esc_html_e( 'تصویر سوال', 'psyq' ); ?></span>
					<div class="psyq-imgfield__box">
						<img class="psyq-imgfield__preview" id="psyq-item-img-preview" src="" alt="" hidden>
						<div class="psyq-imgfield__actions">
							<button type="button" class="button button-small psyq-pick-image" data-target="item"><?php esc_html_e( 'انتخاب تصویر', 'psyq' ); ?></button>
							<button type="button" class="button button-small psyq-clear-image" data-target="item"><?php esc_html_e( 'حذف', 'psyq' ); ?></button>
						</div>
						<input type="hidden" id="psyq-item-img-id" value="0">
						<input type="text" id="psyq-item-img-url" placeholder="<?php esc_attr_e( 'یا آدرس تصویر را بچسبانید', 'psyq' ); ?>">
					</div>
				</div>
			</div>

			<div class="psyq-fields psyq-fields--2">
				<label class="psyq-check"><input type="checkbox" id="psyq-item-reversed"><span><?php esc_html_e( 'نمره‌گذاری معکوس', 'psyq' ); ?></span></label>
				<label class="psyq-check"><input type="checkbox" id="psyq-item-required" checked><span><?php esc_html_e( 'پاسخ اجباری', 'psyq' ); ?></span></label>
				<label class="psyq-field">
					<span><?php esc_html_e( 'شرط نمایش (اختیاری)', 'psyq' ); ?></span>
					<input type="text" id="psyq-item-condition" placeholder="29=بله">
					<small><?php esc_html_e( 'مثال: 29=بله یعنی فقط وقتی پاسخ سوال ۲۹ «بله» باشد نمایش داده شود.', 'psyq' ); ?></small>
				</label>
				<label class="psyq-field">
					<span><?php esc_html_e( 'یادداشت زیر سوال (اختیاری)', 'psyq' ); ?></span>
					<input type="text" id="psyq-item-note">
				</label>
			</div>

			<div class="psyq-opts-editor" id="psyq-opts-editor">
				<div class="psyq-opts-editor__head">
					<h3><?php esc_html_e( 'گزینه‌ها و امتیاز هر گزینه', 'psyq' ); ?></h3>
					<div class="psyq-opts-editor__tools">
						<select id="psyq-preset-count">
							<option value=""><?php esc_html_e( 'قالب آماده…', 'psyq' ); ?></option>
							<?php for ( $i = 2; $i <= PsyQ_Excel::MAX_OPTIONS; $i++ ) : ?>
								<option value="<?php echo esc_attr( $i ); ?>"><?php echo esc_html( sprintf( __( '%d گزینه‌ای', 'psyq' ), $i ) ); ?></option>
							<?php endfor; ?>
						</select>
						<button type="button" class="button button-small" id="psyq-apply-preset"><?php esc_html_e( 'اعمال', 'psyq' ); ?></button>
						<button type="button" class="button button-small" id="psyq-add-option"><?php esc_html_e( '+ گزینه', 'psyq' ); ?></button>
					</div>
				</div>
				<div class="psyq-opts-editor__hint psyq-small psyq-muted">
					<?php esc_html_e( 'امتیاز هر گزینه را جداگانه بین ۵- تا ۷ تعیین کنید. برای پرسشنامه بله/خیر معمولاً ۱ و ۰ و برای لیکرت ۰ تا ۴ یا ۱ تا ۵ استفاده می‌شود.', 'psyq' ); ?>
				</div>
				<div class="psyq-opt-rows" id="psyq-opt-rows"></div>
			</div>
		</div>
		<footer class="psyq-modal__foot">
			<button type="button" class="button psyq-modal__cancel"><?php esc_html_e( 'انصراف', 'psyq' ); ?></button>
			<button type="button" class="button button-primary button-large" id="psyq-save-item"><?php esc_html_e( 'ذخیره سوال', 'psyq' ); ?></button>
		</footer>
	</div>
</div>

<!-- ================== مودال افزودن گروهی ================== -->
<div class="psyq-modal" id="psyq-bulk-modal" hidden style="display:none" aria-hidden="true">
	<div class="psyq-modal__overlay"></div>
	<div class="psyq-modal__dialog psyq-modal__dialog--wide" role="dialog" aria-modal="true">
		<header class="psyq-modal__head">
			<h2><?php esc_html_e( 'افزودن گروهی سوالات', 'psyq' ); ?></h2>
			<button type="button" class="psyq-modal__close" aria-label="<?php esc_attr_e( 'بستن', 'psyq' ); ?>" title="<?php esc_attr_e( 'بستن', 'psyq' ); ?>">×</button>
		</header>
		<div class="psyq-modal__body">
			<p class="psyq-muted psyq-small"><?php esc_html_e( 'هر خط یک سوال. می‌توانید متن سوالات را از فایل ورد یا اکسل کپی و اینجا بچسبانید. برای همه این سوالات، گزینه‌های زیر اعمال می‌شود.', 'psyq' ); ?></p>
			<label class="psyq-field psyq-field--full">
				<span><?php esc_html_e( 'متن سوالات (هر خط یک سوال)', 'psyq' ); ?></span>
				<textarea id="psyq-bulk-text" rows="10" placeholder="۱. برایش مشکل است که احساس نگرانی‌اش را متوقف کند.&#10;۲. از این که در نظر دیگران احمق به نظر برسد نگران است."></textarea>
			</label>
			<div class="psyq-fields psyq-fields--2">
				<label class="psyq-field">
					<span><?php esc_html_e( 'زیرمقیاس', 'psyq' ); ?></span>
					<select id="psyq-bulk-sub">
						<option value="0"><?php esc_html_e( '— بدون زیرمقیاس —', 'psyq' ); ?></option>
						<?php foreach ( $subs as $s ) : ?>
							<option value="<?php echo esc_attr( $s['id'] ); ?>"><?php echo esc_html( $s['title'] ); ?></option>
						<?php endforeach; ?>
					</select>
				</label>
				<label class="psyq-field">
					<span><?php esc_html_e( 'شماره شروع', 'psyq' ); ?></span>
					<input type="number" id="psyq-bulk-start" value="<?php echo esc_attr( count( $items ) + 1 ); ?>" min="1">
				</label>
			</div>
			<div class="psyq-opts-editor">
				<div class="psyq-opts-editor__head">
					<h3><?php esc_html_e( 'گزینه‌های مشترک', 'psyq' ); ?></h3>
					<select id="psyq-bulk-preset">
						<?php for ( $i = 2; $i <= PsyQ_Excel::MAX_OPTIONS; $i++ ) : ?>
							<option value="<?php echo esc_attr( $i ); ?>" <?php selected( (int) $form->default_option_count, $i ); ?>><?php echo esc_html( sprintf( __( '%d گزینه‌ای', 'psyq' ), $i ) ); ?></option>
						<?php endfor; ?>
					</select>
				</div>
				<div class="psyq-opt-rows" id="psyq-bulk-opt-rows"></div>
			</div>
		</div>
		<footer class="psyq-modal__foot">
			<button type="button" class="button psyq-modal__cancel"><?php esc_html_e( 'انصراف', 'psyq' ); ?></button>
			<button type="button" class="button button-primary button-large" id="psyq-bulk-save"><?php esc_html_e( 'افزودن سوالات', 'psyq' ); ?></button>
		</footer>
	</div>
</div>
