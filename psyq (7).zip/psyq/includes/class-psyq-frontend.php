<?php
/**
 * نمایش پرسشنامه و کارنامه در سمت کاربر.
 *
 * شورت‌کدها:
 *   [psyq_form id="12"]     نمایش پرسشنامه
 *   [psyq_report]           صفحه گزارش (با پارامتر psyq_result)
 *   [psyq_list]             فهرست پرسشنامه‌های منتشرشده
 *
 * @package PsyQ
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class PsyQ_Frontend {

	public static function init() {
		add_shortcode( 'psyq_form', array( __CLASS__, 'shortcode_form' ) );
		add_shortcode( 'psyq_report', array( __CLASS__, 'shortcode_report' ) );
		add_shortcode( 'psyq_list', array( __CLASS__, 'shortcode_list' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'register_assets' ) );
	}

	public static function register_assets() {
		wp_register_style( 'psyq-front', PSYQ_URL . 'assets/css/front.css', array(), PSYQ_VERSION );
		wp_register_script( 'psyq-chartjs', PSYQ_URL . 'assets/vendor/chart.umd.min.js', array(), '4.4.1', true );
		wp_register_script( 'psyq-front', PSYQ_URL . 'assets/js/front.js', array( 'jquery' ), PSYQ_VERSION, true );
	}

	/**
	 * شورت‌کد نمایش پرسشنامه.
	 *
	 * @param array $atts پارامترها.
	 * @return string
	 */
	public static function shortcode_form( $atts ) {
		$atts = shortcode_atts(
			array(
				'id'   => 0,
				'code' => '',
			),
			$atts,
			'psyq_form'
		);

		$form = null;
		if ( $atts['id'] ) {
			$form = PsyQ_DB::get_form( (int) $atts['id'] );
		} elseif ( $atts['code'] ) {
			$form = PsyQ_DB::get_form_by_code( $atts['code'] );
		}
		if ( ! $form ) {
			return '<p class="psyq-error">' . esc_html__( 'پرسشنامه یافت نشد.', 'psyq' ) . '</p>';
		}
		if ( 'publish' !== $form->status && ! current_user_can( PsyQ_Admin::CAP ) ) {
			return '<p class="psyq-error">' . esc_html__( 'این پرسشنامه در دسترس نیست.', 'psyq' ) . '</p>';
		}

		$bundle = PsyQ_Scoring::bundle( (int) $form->id );
		if ( ! $bundle || empty( $bundle['items'] ) ) {
			return '<p class="psyq-error">' . esc_html__( 'این پرسشنامه هنوز سوالی ندارد.', 'psyq' ) . '</p>';
		}

		// بررسی وضعیت برگزاری در یک جدول امن.
		$resume = isset( $_GET['psyq_result'] ) ? sanitize_text_field( wp_unslash( $_GET['psyq_result'] ) ) : '';

		wp_enqueue_style( 'dashicons' );
		wp_enqueue_style( 'psyq-front' );
		wp_enqueue_script( 'psyq-front' );
		if ( 'svg' !== $form->chart_engine ) {
			wp_enqueue_script( 'psyq-chartjs' );
		}

		$items = $bundle['items'];
		if ( ! empty( $form->randomize_items ) ) {
			shuffle( $items );
		}

		$per_page  = max( 1, (int) $form->items_per_page );
		$pages     = array_chunk( $items, $per_page );
		$total_q    = count( $items );
		$text_q     = 0;
		foreach ( $items as $count_item ) {
			if ( isset( $count_item['answer_type'] ) && 'text' === $count_item['answer_type'] ) {
				$text_q++;
			}
		}
		$choice_q = $total_q - $text_q;
		$color      = get_option( 'psyq_brand_color', '#4338ca' );
		$logo       = get_option( 'psyq_brand_logo', '' );
		$disclaimer = get_option( 'psyq_show_disclaimer', '' );

		$state = array(
			'formId'       => (int) $form->id,
			'itemCount'    => $total_q,
			'requireAll'   => (int) $form->require_all,
			'allowBack'    => (int) $form->allow_back,
			'randomizeOpt' => (int) $form->randomize_options,
			'duration'     => (int) $form->duration_minutes,
			'collectName'  => (int) $form->collect_name,
			'demographics' => (int) $form->collect_demographics,
			'pages'        => count( $pages ),
			'nonce'        => wp_create_nonce( 'psyq_front' ),
			'ajaxUrl'      => admin_url( 'admin-ajax.php' ),
			'charts'       => $form->show_charts ? 1 : 0,
			'engine'       => $form->chart_engine,
		);

		ob_start();
		?>
		<div class="psyq-app" id="psyq-app-<?php echo esc_attr( $form->id ); ?>"
			data-state="<?php echo esc_attr( wp_json_encode( $state ) ); ?>"
			style="--psyq-primary:<?php echo esc_attr( $color ); ?>"
			dir="rtl">

			<!-- صفحه شروع -->
			<section class="psyq-screen psyq-screen--intro is-active" data-screen="intro">
				<div class="psyq-card psyq-card--intro">
					<?php if ( $logo ) : ?>
						<img class="psyq-logo" src="<?php echo esc_url( $logo ); ?>" alt="">
					<?php endif; ?>
					<h1 class="psyq-h1"><?php echo esc_html( $form->title ); ?></h1>
					<?php if ( $form->description ) : ?>
						<div class="psyq-lead"><?php echo wp_kses_post( wpautop( $form->description ) ); ?></div>
					<?php endif; ?>
					<?php if ( $form->intro_html ) : ?>
						<div class="psyq-intro-text"><?php echo wp_kses_post( wpautop( $form->intro_html ) ); ?></div>
					<?php endif; ?>

					<ul class="psyq-facts">
						<li><span class="dashicons dashicons-editor-help"></span> <?php echo esc_html( number_format_i18n( $choice_q ) ); ?> <?php esc_html_e( 'گویه نمره‌دار', 'psyq' ); ?><?php if ( $text_q ) : ?> + <?php echo esc_html( number_format_i18n( $text_q ) ); ?> <?php esc_html_e( 'پاسخ متنی', 'psyq' ); ?><?php endif; ?></li>
						<li><span class="dashicons dashicons-clock"></span> <?php echo esc_html( $form->duration_minutes ? sprintf( __( 'حدود %d دقیقه', 'psyq' ), $form->duration_minutes ) : __( 'بدون محدودیت زمان', 'psyq' ) ); ?></li>
						<li><span class="dashicons dashicons-chart-bar"></span> <?php echo esc_html( count( $bundle['subscales'] ) ); ?> <?php esc_html_e( 'زیرمقیاس', 'psyq' ); ?></li>
						<?php if ( $form->show_total ) : ?>
							<li><span class="dashicons dashicons-awards"></span> <?php esc_html_e( 'همراه با نمره کل و تفسیر', 'psyq' ); ?></li>
						<?php endif; ?>
					</ul>

					<?php if ( $form->consent_html ) : ?>
						<label class="psyq-consent">
							<input type="checkbox" class="psyq-consent-check">
							<span><?php echo wp_kses_post( $form->consent_html ); ?></span>
						</label>
					<?php endif; ?>

					<div class="psyq-row psyq-row--end">
						<button type="button" class="psyq-btn psyq-btn--primary psyq-start" <?php echo $form->consent_html ? 'disabled' : ''; ?>>
							<?php esc_html_e( 'شروع آزمون', 'psyq' ); ?>
						</button>
					</div>
					<?php if ( $disclaimer ) : ?>
						<p class="psyq-note"><?php echo wp_kses_post( $disclaimer ); ?></p>
					<?php endif; ?>
				</div>
			</section>

			<!-- صفحه مشخصات -->
			<section class="psyq-screen" data-screen="profile">
				<div class="psyq-card">
					<h2 class="psyq-h2"><?php esc_html_e( 'مشخصات شرکت‌کننده', 'psyq' ); ?></h2>
					<p class="psyq-muted psyq-small"><?php esc_html_e( 'این اطلاعات برای درج در کارنامه آزمون استفاده می‌شود.', 'psyq' ); ?></p>
					<div class="psyq-grid psyq-grid--2">
						<?php if ( $form->collect_name ) : ?>
							<label class="psyq-field"><span><?php esc_html_e( 'نام', 'psyq' ); ?></span><input type="text" class="psyq-in" data-field="first_name"></label>
							<label class="psyq-field"><span><?php esc_html_e( 'نام خانوادگی', 'psyq' ); ?></span><input type="text" class="psyq-in" data-field="last_name"></label>
						<?php endif; ?>
						<?php if ( $form->collect_demographics ) : ?>
							<label class="psyq-field"><span><?php esc_html_e( 'جنسیت', 'psyq' ); ?></span>
								<select class="psyq-in" data-field="gender">
									<option value=""><?php esc_html_e( 'انتخاب کنید', 'psyq' ); ?></option>
									<option value="male"><?php esc_html_e( 'مرد', 'psyq' ); ?></option>
									<option value="female"><?php esc_html_e( 'زن', 'psyq' ); ?></option>
								</select>
							</label>
							<label class="psyq-field"><span><?php esc_html_e( 'سن', 'psyq' ); ?></span><input type="number" min="1" max="120" class="psyq-in" data-field="age"></label>
							<label class="psyq-field"><span><?php esc_html_e( 'تحصیلات', 'psyq' ); ?></span>
								<select class="psyq-in" data-field="education">
									<option value=""><?php esc_html_e( 'انتخاب کنید', 'psyq' ); ?></option>
									<option value="زیر دیپلم"><?php esc_html_e( 'زیر دیپلم', 'psyq' ); ?></option>
									<option value="دیپلم"><?php esc_html_e( 'دیپلم', 'psyq' ); ?></option>
									<option value="کارشناسی"><?php esc_html_e( 'کارشناسی', 'psyq' ); ?></option>
									<option value="کارشناسی ارشد"><?php esc_html_e( 'کارشناسی ارشد', 'psyq' ); ?></option>
									<option value="دکتری"><?php esc_html_e( 'دکتری', 'psyq' ); ?></option>
								</select>
							</label>
							<label class="psyq-field"><span><?php esc_html_e( 'شماره تماس (اختیاری)', 'psyq' ); ?></span><input type="tel" class="psyq-in" data-field="phone"></label>
						<?php endif; ?>
					</div>
					<div class="psyq-row">
						<button type="button" class="psyq-btn psyq-btn--ghost psyq-back-intro"><?php esc_html_e( 'بازگشت', 'psyq' ); ?></button>
						<button type="button" class="psyq-btn psyq-btn--primary psyq-profile-next"><?php esc_html_e( 'ادامه', 'psyq' ); ?></button>
					</div>
					<label class="psyq-check psyq-skip-profile"><input type="checkbox" checked> <?php esc_html_e( 'مایل به افشای هویت نیستم (ناشناس)', 'psyq' ); ?></label>
				</div>
			</section>

			<!-- صفحه سوالات -->
			<section class="psyq-screen" data-screen="quiz">
				<div class="psyq-quizbar">
					<div class="psyq-progress"><span class="psyq-progress__bar"></span></div>
					<div class="psyq-quizbar__meta">
						<span class="psyq-counter">0 / <?php echo esc_html( $total_q ); ?></span>
						<span class="psyq-timer" hidden></span>
						<span class="psyq-pageinfo"></span>
					</div>
				</div>

				<div class="psyq-questions">
					<?php
					$global_index = 0;
					foreach ( $pages as $pi => $page_items ) :
						?>
						<div class="psyq-page" data-page="<?php echo esc_attr( $pi ); ?>">
							<?php foreach ( $page_items as $item ) : ?>
								<?php
								$is_text = isset( $item['answer_type'] ) && 'text' === $item['answer_type'];
								$opts    = $item['options'];
								if ( ! $is_text && ! empty( $form->randomize_options ) ) {
									shuffle( $opts );
								}
								$input_name = 'psyq_' . $form->id . '_' . $item['id'];
								$cond_attr  = '';
								if ( ! empty( $item['condition'] ) ) {
									$cond_attr = ' data-cond-item="' . esc_attr( $item['condition']['item'] ) . '" data-cond-op="' . esc_attr( $item['condition']['op'] ) . '" data-cond-val="' . esc_attr( $item['condition']['val'] ) . '"';
								}
								$has_images = false;
								foreach ( $opts as $o ) {
									if ( ! empty( $o['image_url'] ) ) {
										$has_images = true;
										break;
									}
								}
								?>
								<article class="psyq-q<?php echo $is_text ? ' psyq-q--text' : ''; ?>" data-item-id="<?php echo esc_attr( $item['id'] ); ?>"
									data-number="<?php echo esc_attr( $item['number'] ); ?>"
									data-answer-type="<?php echo $is_text ? 'text' : 'choice'; ?>"
									data-required="<?php echo esc_attr( $item['is_required'] ); ?>"<?php echo $cond_attr; // phpcs:ignore ?>>
									<div class="psyq-q__head">
										<span class="psyq-q__num"><?php echo esc_html( $item['number'] ); ?></span>
										<div class="psyq-q__body">
											<div class="psyq-q__text"><?php echo wp_kses_post( wpautop( $item['text'] ) ); ?></div>
											<?php if ( $item['image_url'] ) : ?>
												<figure class="psyq-q__image"><img src="<?php echo esc_url( $item['image_url'] ); ?>" alt="" loading="lazy"></figure>
											<?php endif; ?>
											<?php if ( ! empty( $item['note'] ) ) : ?>
												<p class="psyq-note"><?php echo esc_html( $item['note'] ); ?></p>
											<?php endif; ?>
										</div>
									</div>
									<?php if ( $is_text ) : ?>
										<div class="psyq-text-response">
											<textarea class="psyq-text-answer" data-psyq-text rows="4" maxlength="2000" placeholder="<?php esc_attr_e( 'پاسخ خود را بنویسید…', 'psyq' ); ?>"></textarea>
											<p class="psyq-muted psyq-small"><?php esc_html_e( 'این پاسخ برای مشاهده متخصص ثبت می‌شود و در نمره‌گذاری وارد نمی‌شود.', 'psyq' ); ?></p>
										</div>
									<?php else : ?>
										<div class="psyq-opts <?php echo $has_images ? 'psyq-opts--images' : 'psyq-opts--' . count( $opts ); ?>">
											<?php foreach ( $opts as $oi => $o ) : ?>
												<label class="psyq-opt">
													<input type="radio" name="<?php echo esc_attr( $input_name ); ?>" value="<?php echo esc_attr( $o['id'] ); ?>">
													<span class="psyq-opt__box">
														<?php if ( ! empty( $o['image_url'] ) ) : ?>
															<img src="<?php echo esc_url( $o['image_url'] ); ?>" alt="" loading="lazy">
														<?php endif; ?>
														<span class="psyq-opt__label"><?php echo esc_html( $o['label'] ); ?></span>
													</span>
												</label>
											<?php endforeach; ?>
										</div>
									<?php endif; ?>
								</article>
								<?php
								$global_index++;
							endforeach;
							?>
						</div>
					<?php endforeach; ?>
				</div>

				<div class="psyq-nav">
					<button type="button" class="psyq-btn psyq-btn--ghost psyq-prev" <?php echo $form->allow_back ? '' : 'hidden'; ?>><?php esc_html_e( 'قبلی', 'psyq' ); ?></button>
					<button type="button" class="psyq-btn psyq-btn--primary psyq-next"><?php esc_html_e( 'بعدی', 'psyq' ); ?></button>
					<button type="button" class="psyq-btn psyq-btn--primary psyq-submit" hidden><?php esc_html_e( 'پایان و مشاهده کارنامه', 'psyq' ); ?></button>
				</div>
				<p class="psyq-alert" hidden></p>
			</section>

			<!-- صفحه نتیجه -->
			<section class="psyq-screen" data-screen="result">
				<div class="psyq-loading" hidden>
					<div class="psyq-spinner"></div>
					<p><?php esc_html_e( 'در حال تحلیل پاسخ‌ها و تهیه کارنامه…', 'psyq' ); ?></p>
				</div>
				<div class="psyq-result"></div>
				<div class="psyq-row psyq-result-actions" hidden>
					<button type="button" class="psyq-btn psyq-btn--ghost psyq-print"><?php esc_html_e( 'چاپ / ذخیره PDF', 'psyq' ); ?></button>
					<a class="psyq-btn psyq-btn--ghost psyq-report-link" target="_blank" rel="noopener" hidden><?php esc_html_e( 'لینک دائمی کارنامه', 'psyq' ); ?></a>
					<a class="psyq-btn psyq-btn--primary psyq-restart" href="<?php echo esc_url( remove_query_arg( 'psyq_result' ) ); ?>"><?php esc_html_e( 'آزمون جدید', 'psyq' ); ?></a>
				</div>
			</section>
		</div>
		<?php
		if ( $resume ) {
			?>
			<script>
			document.addEventListener('DOMContentLoaded', function(){
				var app = document.querySelector('#psyq-app-<?php echo (int) $form->id; ?>');
				if (app && window.PsyQFront) { window.PsyQFront.resume(app, '<?php echo esc_js( $resume ); ?>'); }
			});
			</script>
			<?php
		}
		return ob_get_clean();
	}

	/**
	 * شورت‌کد صفحه گزارش دائمی.
	 *
	 * @return string
	 */
	public static function shortcode_report() {
		$token = isset( $_GET['psyq_result'] ) ? sanitize_text_field( wp_unslash( $_GET['psyq_result'] ) ) : '';
		wp_enqueue_style( 'psyq-front' );

		if ( ! $token ) {
			return '<p class="psyq-error">' . esc_html__( 'شناسه کارنامه یافت نشد.', 'psyq' ) . '</p>';
		}
		global $wpdb;
		$t   = PsyQ_DB::table( 'responses' );
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE guest_token = %s", $token ) );
		if ( ! $row ) {
			return '<p class="psyq-error">' . esc_html__( 'کارنامه‌ای با این شناسه وجود ندارد.', 'psyq' ) . '</p>';
		}
		$html = $row->report_html;
		if ( ! $html ) {
			$scores = json_decode( (string) $row->scores, true );
			$html   = is_array( $scores ) ? PsyQ_Scoring::render_report( (int) $row->form_id, $scores, array( 'response' => $row, 'context' => 'front' ) ) : '';
		}
		wp_enqueue_script( 'psyq-front' );
		wp_enqueue_script( 'psyq-chartjs' );
		return '<div class="psyq-app psyq-app--report" dir="rtl">' . $html . '<div class="psyq-row"><button type="button" class="psyq-btn psyq-btn--ghost psyq-print">' . esc_html__( 'چاپ / ذخیره PDF', 'psyq' ) . '</button></div></div>';
	}

	/**
	 * فهرست پرسشنامه‌ها.
	 *
	 * @param array $atts پارامترها.
	 * @return string
	 */
	public static function shortcode_list( $atts ) {
		wp_enqueue_style( 'psyq-front' );
		$forms = PsyQ_DB::get_forms( array( 'status' => 'publish' ) );
		if ( ! $forms ) {
			return '<p class="psyq-muted">' . esc_html__( 'هنوز پرسشنامه‌ای منتشر نشده است.', 'psyq' ) . '</p>';
		}
		ob_start();
		?>
		<div class="psyq-app psyq-list" dir="rtl">
			<?php foreach ( $forms as $f ) : ?>
				<a class="psyq-listcard" href="<?php echo esc_url( get_permalink() . '#psyq-' . $f->id ); ?>">
					<h3><?php echo esc_html( $f->title ); ?></h3>
					<p><?php echo esc_html( wp_trim_words( wp_strip_all_tags( (string) $f->description ), 22 ) ); ?></p>
					<span class="psyq-chip"><?php esc_html_e( 'شروع آزمون', 'psyq' ); ?></span>
				</a>
			<?php endforeach; ?>
		</div>
		<?php
		return ob_get_clean();
	}
}
