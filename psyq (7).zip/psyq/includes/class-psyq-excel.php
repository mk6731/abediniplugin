<?php
/**
 * قالب خام اکسل، ورود و خروج پرسشنامه و نتایج.
 *
 * @package PsyQ
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class PsyQ_Excel {

	/** حداکثر تعداد گزینه قابل پشتیبانی در قالب. */
	const MAX_OPTIONS = 10;

	/* ==================================================================
	 * قالب خام
	 * ================================================================== */

	/**
	 * ساخت فایل قالب خام.
	 *
	 * @param int    $option_count تعداد گزینه.
	 * @param object $form         اگر ساخت‌شده باشد، برای خروجی گرفتن از پرسشنامه موجود.
	 * @param string $mode         'template' یا 'export'.
	 * @return string مسیر فایل موقت.
	 */
	public static function build( $option_count = 4, $form = null, $mode = 'template' ) {
		$option_count = max( 2, min( self::MAX_OPTIONS, (int) $option_count ) );
		$writer       = new PsyQ_XLSX_Writer();

		$is_export = ( 'export' === $mode && $form );

		/* ---------------- شیت راهنما ---------------- */
		$guide = array(
			array( array( 'v' => 'راهنمای تکمیل فایل اکسل پرسشنامه', 's' => 4 ) ),
			array( array( 'v' => 'این فایل شامل چند برگه (Sheet) است. لطفاً ساختار هر برگه را تغییر ندهید و فقط ردیف‌های داده را تکمیل کنید.', 's' => 7 ) ),
			array( '' ),
			array( array( 'v' => '۱) برگه «پرسشنامه»', 's' => 6 ), array( 'v' => 'اطلاعات کلی: عنوان، کد، توضیحات، تعداد گزینه پیش‌فرض، نحوه نمایش و…', 's' => 7 ) ),
			array( array( 'v' => '۲) برگه «زیرمقیاس‌ها»', 's' => 6 ), array( 'v' => 'هر ردیف یک زیرمقیاس. ستون «نام» کد یکتای زیرمقیاس است (مثلاً ANX) و در برگه سوالات به آن ارجاع می‌دهید.', 's' => 7 ) ),
			array( array( 'v' => '۳) برگه «نقاط برش»', 's' => 6 ), array( 'v' => 'برای هر زیرمقیاس از ۱ تا ۳ نقطه برش (تا ۶ بازه) تعیین کنید: «از» شامل و «تا» غیرشامل است. آخرین بازه می‌تواند «تا» خالی داشته باشد.', 's' => 7 ) ),
			array( array( 'v' => '۴) برگه «سوالات»', 's' => 6 ), array( 'v' => 'هر ردیف یک سوال، همراه با متن و امتیاز هر گزینه (‑۵ تا ۷). اگر از گزینه‌های مشترک استفاده می‌کنید، ستون‌های گزینه را خالی بگذارید.', 's' => 7 ) ),
			array( array( 'v' => '۵) برگه «گزینه‌های مشترک»', 's' => 6 ), array( 'v' => 'اختیاری: اگر همه سوالات گزینه‌های یکسان (مثلاً لیکرت ۵ درجه‌ای) دارند، فقط این برگه را پر کنید تا نیازی به تکرار گزینه‌ها نباشد.', 's' => 7 ) ),
			array( '' ),
			array( array( 'v' => 'نکات مهم', 's' => 6 ) ),
			array( '· امتیاز هر گزینه عددی بین ۵- تا ۷ است (ممکن است اعشاری هم باشد مثل ۱٫۵).' ),
			array( '· برای سوال معکوس، ستون «معکوس» را «بله» بگذارید؛ نمره به‌صورت خودکار معکوس می‌شود.' ),
			array( '· شرط نمایش: مثلاً «29=بله» یعنی این سوال فقط وقتی نمایش داده شود که پاسخ سوال ۲۹ «بله» باشد.' ),
			array( '· تصویر: می‌توانید آدرس کامل تصویر (https://…) یا نام فایل موجود در کتابخانه رسانه را وارد کنید.' ),
			array( '· اگر ستون «زیرمقیاس» خالی باشد، سوال در نمره کل لحاظ می‌شود اما وارد هیچ زیرمقیاسی نمی‌شود.' ),
			array( '· ستون «نوع پاسخ»: «گزینه‌ای» برای سوال امتیازدار و «متنی»/«متن آزاد» برای کادر نوشتاری بدون گزینه و بدون نمره است.' ),
			array( '· تعداد گزینه‌ها در هر سوال می‌تواند متفاوت باشد؛ کافی است ستون‌های گزینه همان سوال را پر کنید.' ),
			array( '' ),
			array( array( 'v' => 'پس از تکمیل، فایل را در صفحه «ورود از اکسل» در پنل بارگذاری کنید.', 's' => 7 ) ),
		);
		$writer->add_sheet( 'راهنما', $guide, array( 'header_rows' => 0, 'col_widths' => array( 140 ), 'freeze_row' => 0 ) );

		/* ---------------- شیت پرسشنامه ---------------- */
		$meta_rows = array( array( array( 'v' => 'کلید', 's' => 1 ), array( 'v' => 'مقدار', 's' => 1 ) ) );
		$meta      = array(
			'عنوان پرسشنامه'    => $is_export ? $form->title : 'پرسشنامه نمونه',
			'کد پرسشنامه'       => $is_export ? $form->code : 'QUESTIONNAIRE-SAMPLE',
			'توضیحات'           => $is_export ? $form->description : 'قالب قابل ویرایش برای ساخت پرسشنامه.',
			'تعداد گزینه پیش‌فرض' => $is_export ? $form->default_option_count : $option_count,
			'حالت امتیازدهی'      => $is_export ? $form->scoring_mode : 'option',
			'نمایش نمره کل'      => $is_export ? ( $form->show_total ? 'بله' : 'خیر' ) : 'بله',
			'عنوان نمره کل'      => 'اضطراب کل',
			'تعداد سوال در هر صفحه' => $is_export ? $form->items_per_page : 20,
			'نمایش نمودار'       => 'بله',
			'موتور نمودار'       => $is_export ? $form->chart_engine : 'both',
			'متن معرفی'         => $is_export ? $form->intro_html : 'لطفاً میزان موافقت خود را با هر یک از جملات زیر علامت بزنید.',
			'متن رضایت‌نامه'     => $is_export ? $form->consent_html : '',
			'متن پایان گزارش'    => $is_export ? $form->report_footer_html : '',
			'وضعیت'             => $is_export ? $form->status : 'draft',
		);
		foreach ( $meta as $k => $v ) {
			$meta_rows[] = array( array( 'v' => $k, 's' => 6 ), array( 'v' => (string) $v, 's' => 2 ) );
		}
		$writer->add_sheet( 'پرسشنامه', $meta_rows, array( 'header_rows' => 1, 'col_widths' => array( 30, 70 ) ) );

		/* ---------------- زیرمقیاس‌ها ---------------- */
		$sub_rows = array(
			array(
				array( 'v' => 'نام (کد)', 's' => 1 ),
				array( 'v' => 'عنوان نمایشی', 's' => 1 ),
				array( 'v' => 'توضیح', 's' => 1 ),
				array( 'v' => 'رنگ', 's' => 1 ),
				array( 'v' => 'در نمره کل لحاظ شود', 's' => 1 ),
			),
		);
		$subs = array();
		if ( $is_export ) {
			foreach ( PsyQ_DB::get_subscales( $form->id ) as $s ) {
				$subs[] = $s;
			}
		}
		if ( $subs ) {
			foreach ( $subs as $s ) {
				$sub_rows[] = array( $s->name, $s->title, $s->description, $s->color, $s->include_in_total ? 'بله' : 'خیر' );
			}
		} else {
			$sample = array(
				array( 'SEP', 'اضطراب جدایی', 'نگرانی و ترس هنگام جدا شدن از والدین', '#3b82f6', 'بله' ),
				array( 'GAD', 'اضطراب فراگیر', 'نگرانی مفرط و غیرقابل کنترل', '#8b5cf6', 'بله' ),
				array( 'SOC', 'اضطراب اجتماعی', 'ترس از موقعیت‌های اجتماعی و ارزیابی دیگران', '#ec4899', 'بله' ),
				array( 'PHY', 'ترس از آسیب جسمی', 'ترس از بیماری و آسیب جسمانی', '#f59e0b', 'بله' ),
				array( 'OCD', 'وسواس فکری-عملی', 'افکار مزاحم و رفتارهای تکراری', '#10b981', 'بله' ),
				array( 'PTSD', 'اضطراب پس از سانحه', 'علائم پس از تجربه حادثه آسیب‌زا', '#ef4444', 'بله' ),
			);
			foreach ( $sample as $r ) {
				$sub_rows[] = $r;
			}
		}
		$writer->add_sheet( 'زیرمقیاس‌ها', $sub_rows, array( 'header_rows' => 1, 'col_widths' => array( 14, 26, 44, 12, 18 ) ) );

		/* ---------------- نقاط برش ---------------- */
		$band_rows = array(
			array(
				array( 'v' => 'زیرمقیاس', 's' => 1 ),
				array( 'v' => 'از (شامل)', 's' => 1 ),
				array( 'v' => 'تا (غیرشامل)', 's' => 1 ),
				array( 'v' => 'برچسب سطح', 's' => 1 ),
				array( 'v' => 'شدت', 's' => 1 ),
				array( 'v' => 'رنگ', 's' => 1 ),
				array( 'v' => 'تفسیر', 's' => 1 ),
			),
		);
		if ( $is_export ) {
			foreach ( $subs as $s ) {
				foreach ( PsyQ_DB::get_bands( $s->id ) as $b ) {
					$band_rows[] = array( array( 'v' => $s->name, 's' => 2 ), (float) $b->min_value, (float) $b->max_value, $b->label, $b->severity, $b->color, $b->interpretation );
				}
			}
		} else {
			$sample_bands = array(
				array( 'SEP', 0, 4, 'طبیعی', 'normal', '#16a34a', 'در محدوده بهنجار قرار دارد؛ نشانه‌ای از اضطراب جدایی قابل توجه دیده نمی‌شود.' ),
				array( 'SEP', 4, 7, 'خفیف', 'mild', '#84cc16', 'نشانه‌های خفیف اضطراب جدایی وجود دارد؛ پیگیری و آموزش مهارت‌های مقابله پیشنهاد می‌شود.' ),
				array( 'SEP', 7, 10, 'متوسط', 'moderate', '#f59e0b', 'اضطراب جدایی در سطح متوسط است؛ مشاوره تخصصی و مداخله رفتاری لازم است.' ),
				array( 'SEP', 10, 999, 'شدید', 'severe', '#ef4444', 'نشانه‌های شدید اضطراب جدایی گزارش شده است؛ ارجاع به روان‌شناس کودک ضروری است.' ),
			);
			foreach ( $sample_bands as $r ) {
				$band_rows[] = $r;
			}
		}
		$writer->add_sheet( 'نقاط برش', $band_rows, array( 'header_rows' => 1, 'col_widths' => array( 14, 12, 14, 16, 12, 12, 70 ) ) );

		/* ---------------- سوالات ---------------- */
		$item_header = array(
			array( 'v' => 'شماره', 's' => 1 ),
			array( 'v' => 'متن سوال', 's' => 1 ),
			array( 'v' => 'نوع پاسخ', 's' => 1 ),
			array( 'v' => 'زیرمقیاس', 's' => 1 ),
			array( 'v' => 'تصویر سوال', 's' => 1 ),
			array( 'v' => 'معکوس', 's' => 1 ),
			array( 'v' => 'اجباری', 's' => 1 ),
			array( 'v' => 'شرط نمایش', 's' => 1 ),
			array( 'v' => 'یادداشت', 's' => 1 ),
		);
		for ( $i = 1; $i <= $option_count; $i++ ) {
			$item_header[] = array( 'v' => 'گزینه ' . $i . ' متن', 's' => 1 );
			$item_header[] = array( 'v' => 'گزینه ' . $i . ' امتیاز', 's' => 1 );
			$item_header[] = array( 'v' => 'گزینه ' . $i . ' تصویر', 's' => 1 );
		}
		$item_rows = array( $item_header );

		if ( $is_export ) {
			foreach ( PsyQ_DB::get_items( $form->id ) as $it ) {
				$sub_name = '';
				foreach ( $subs as $s ) {
					if ( (int) $s->id === (int) $it->subscale_id ) {
						$sub_name = $s->name;
						break;
					}
				}
				$row = array(
					array( 'v' => (int) $it->number, 's' => 3 ),
					array( 'v' => $it->text, 's' => 2 ),
					array( 'v' => isset( $it->answer_type ) && 'text' === $it->answer_type ? 'متنی' : 'گزینه‌ای', 's' => 2 ),
					array( 'v' => $sub_name, 's' => 2 ),
					array( 'v' => $it->image_url, 's' => 2 ),
					$it->reversed ? 'بله' : 'خیر',
					$it->is_required ? 'بله' : 'خیر',
					$it->condition,
					$it->note,
				);
				$opts = PsyQ_DB::get_options( $it->id );
				for ( $i = 0; $i < $option_count; $i++ ) {
					if ( isset( $opts[ $i ] ) && '' !== trim( (string) $opts[ $i ]->label ) ) {
						$row[] = array( 'v' => $opts[ $i ]->label, 's' => 2 );
						$row[] = (float) $opts[ $i ]->value;
						$row[] = $opts[ $i ]->image_url;
					} else {
						$row[] = array( 'v' => '', 's' => 2 );
						$row[] = array( 'v' => '', 's' => 3 );
						$row[] = array( 'v' => '', 's' => 2 );
					}
				}
				$item_rows[] = $row;
			}
		} else {
			// ردیف نمونه.
			$sample_items = array(
				array( 1, 'برایش مشکل است که احساس نگرانی‌اش را متوقف کند.', 'GAD', '', 'خیر', 'بله', '', '' ),
				array( 2, 'دوست ندارد بدون شما یا جایی غیر از خانه خودتان بخوابد.', 'SEP', '', 'خیر', 'بله', '', '' ),
				array( 29, 'آیا کودک شما تا به حال حادثه‌ای بد یا ضربه‌آور را تجربه کرده است؟', 'PTSD', 'شرط-نمایش', 'خیر', 'بله', '', 'این سوال دروازه‌ای است' ),
				array( 30, 'در مورد آن حادثه کابوس یا خواب‌های بدی می‌بیند.', 'PTSD', '', 'خیر', 'بله', '29=بله', 'فقط اگر پاسخ ۲۹ بله باشد' ),
			);
			$labels = array( 'اصلاً', 'کمی', 'زیاد', 'خیلی زیاد', 'همیشه', 'به‌ندرت', 'گاهی', 'اغلب', 'بله', 'خیر' );
			foreach ( $sample_items as $si ) {
				$row = array(
					array( 'v' => $si[0], 's' => 3 ),
					array( 'v' => $si[1], 's' => 2 ),
					array( 'v' => 'گزینه‌ای', 's' => 2 ),
					array( 'v' => $si[2], 's' => 2 ),
					array( 'v' => $si[3], 's' => 2 ),
					$si[4],
					$si[5],
					$si[6],
					$si[7],
				);
				for ( $i = 0; $i < $option_count; $i++ ) {
					$row[] = array( 'v' => isset( $labels[ $i ] ) ? $labels[ $i ] : ( 'گزینه ' . ( $i + 1 ) ), 's' => 2 );
					$row[] = (float) $i;
					$row[] = '';
				}
				$item_rows[] = $row;
			}
		}

		$widths = array( 8, 60, 14, 14, 24, 10, 10, 16, 24 );
		for ( $i = 0; $i < $option_count; $i++ ) {
			$widths[] = 20;
			$widths[] = 10;
			$widths[] = 22;
		}
		$writer->add_sheet(
			'سوالات',
			$item_rows,
			array(
				'header_rows' => 1,
				'col_widths'  => $widths,
				'landscape'   => true,
				'validations' => array(
					array(
						'sqref'   => 'F2:G' . ( count( $item_rows ) + 200 ),
						'options' => array( 'بله', 'خیر' ),
					),
				),
			)
		);

		/* ---------------- گزینه‌های مشترک ---------------- */
		$shared_rows = array(
			array(
				array( 'v' => 'ردیف', 's' => 1 ),
				array( 'v' => 'متن گزینه', 's' => 1 ),
				array( 'v' => 'امتیاز', 's' => 1 ),
				array( 'v' => 'تصویر گزینه', 's' => 1 ),
			),
		);
		if ( $is_export ) {
			// تشخیص گزینه‌های مشترک بین همه سوالات.
			$items      = PsyQ_DB::get_items( $form->id );
			$signatures = array();
			$all_same   = true;
			$first      = null;
			foreach ( $items as $it ) {
				$opts = PsyQ_DB::get_options( $it->id );
				if ( ! $opts ) {
					continue;
				}
				$sig = wp_json_encode( wp_list_pluck( $opts, 'label' ) );
				$val = wp_json_encode( wp_list_pluck( $opts, 'value' ) );
				$signatures[ $sig . $val ] = true;
				if ( null === $first ) {
					$first = $opts;
				}
			}
			if ( count( $signatures ) > 1 ) {
				$all_same = false;
			}
			if ( $all_same && $first ) {
				$i = 1;
				foreach ( $first as $o ) {
					$shared_rows[] = array( array( 'v' => $i, 's' => 3 ), array( 'v' => $o->label, 's' => 2 ), (float) $o->value, array( 'v' => $o->image_url, 's' => 2 ) );
					$i++;
				}
			}
		} else {
			$preset = PsyQ_DB::option_presets();
			$labels = isset( $preset[ $option_count ] ) ? $preset[ $option_count ] : array();
			for ( $i = 1; $i <= $option_count; $i++ ) {
				$shared_rows[] = array(
					array( 'v' => $i, 's' => 3 ),
					array( 'v' => isset( $labels[ $i - 1 ] ) ? $labels[ $i - 1 ] : ( 'گزینه ' . $i ), 's' => 2 ),
					(float) ( $i - 1 ),
					'',
				);
			}
		}
		$writer->add_sheet( 'گزینه‌های مشترک', $shared_rows, array( 'header_rows' => 1, 'col_widths' => array( 8, 30, 12, 34 ) ) );

		$path = self::tmp_path( $is_export ? 'export' : 'template' );
		$writer->save( $path );
		return $path;
	}

	private static function tmp_path( $prefix = 'psyq' ) {
		$dir = trailingslashit( get_temp_dir() ) . 'psyq';
		if ( ! file_exists( $dir ) ) {
			wp_mkdir_p( $dir );
		}
		return trailingslashit( $dir ) . $prefix . '-' . wp_generate_password( 8, false, false ) . '.xlsx';
	}

	/**
	 * ارسال فایل برای دانلود.
	 *
	 * @param string $path     مسیر.
	 * @param string $filename نام دانلود.
	 */
	public static function stream( $path, $filename ) {
		if ( ! file_exists( $path ) ) {
			wp_die( esc_html__( 'فایل یافت نشد.', 'psyq' ) );
		}
		nocache_headers();
		header( 'Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' );
		header( 'Content-Disposition: attachment; filename="' . sanitize_file_name( $filename ) . '"; filename*=UTF-8\'\'' . rawurlencode( $filename ) );
		header( 'Content-Length: ' . filesize( $path ) );
		readfile( $path ); // phpcs:ignore
		@unlink( $path ); // phpcs:ignore
		exit;
	}

	/* ==================================================================
	 * نمونه‌های آماده PAS والد و SCAS-Parent
	 * ================================================================== */

	/**
	 * ساخت پرسشنامه نمونه از طریق همان مسیر ورود اکسل.
	 *
	 * @param string $status وضعیت.
	 * @return array|WP_Error
	 */
	public static function create_sample( $status = 'draft', $type = 'pas34' ) {
		$path   = self::build_sample_file( $type );
		$result = self::import( $path, array( 'mode' => 'new', 'status' => $status ) );
		@unlink( $path ); // phpcs:ignore
		return $result;
	}

	/**
	 * نام استاندارد نمونه‌ها.
	 *
	 * @param string $type pas34|scasp38 (نام‌های قدیمی sample هم به pas34 نگاشت می‌شوند).
	 * @return string
	 */
	public static function sample_type( $type ) {
		$type = self::norm( $type );
		return in_array( $type, array( 'scasp38', 'sample-scas', 'scas-p', 'scas-parent', 'scas38', '38' ), true ) ? 'scasp38' : 'pas34';
	}

	/**
	 * ساخت و ذخیره فایل اکسل نمونه.
	 *
	 * pas34: مقیاس اضطراب پیش‌دبستانی اسپنس، نسخه والد، با مسیر PTSD مشروط.
	 * scasp38: SCAS-Parent استاندارد ۳۸ گویه‌ای، با سؤال باز اختیاری.
	 *
	 * @return string مسیر فایل موقت.
	 * @throws Exception در صورت خطا.
	 */
	public static function build_sample_file( $type = 'pas34' ) {
		return 'scasp38' === self::sample_type( $type ) ? self::build_scas_parent_sample_file() : self::build_pas_parent_sample_file();
	}

	/**
	 * ساخت فایل نمونه PAS والد (۳۴ گویه نمره‌دار + فیلد شرح رویداد).
	 *
	 * @return string
	 */
	private static function build_pas_parent_sample_file() {
		$writer = new PsyQ_XLSX_Writer();

		/* پرسشنامه */
		$meta = array( array( array( 'v' => 'کلید', 's' => 1 ), array( 'v' => 'مقدار', 's' => 1 ) ) );
		$fields = array(
			'عنوان پرسشنامه'      => 'مقیاس اضطراب پیش‌دبستانی اسپنس — نسخه والد (PAS-style)',
			'کد پرسشنامه'         => 'SPENCE-PAS-PARENT-34',
			'توضیحات'             => 'نمونه PAS-style والد/پیش‌دبستانی: ۲۸ گویه هسته با طیف ۰ تا ۴، مسیر مشروط اضطراب پس از سانحه و یک فیلد اختیاری برای شرح رویداد. نمره کل هسته ۰ تا ۱۱۲ است؛ PTSD جداگانه گزارش می‌شود. این فرم SCAS-Parent رسمی ۳۸ گویه‌ای نیست و ترجمه، نقاط برش و تفسیر آن باید توسط متخصص تأیید شود.',
			'تعداد گزینه پیش‌فرض'   => 5,
			'نمایش نمره کل'        => 'بله',
			'عنوان نمره کل'        => 'اضطراب کل',
			'تعداد سوال در هر صفحه' => 20,
			'نمایش نمودار'         => 'بله',
			'متن معرفی'            => 'لطفاً بر اساس رفتار و تجربه کودک، میزان درستی هر جمله را علامت بزنید. سؤال‌های مربوط به رویداد آسیب‌زا فقط در صورت پاسخ «بله» به سؤال ۲۹ نمایش داده می‌شوند. این فرم نمونه PAS-style است و با SCAS-Parent رسمی ۳۸ گویه‌ای تفاوت دارد.',
			'متن رضایت‌نامه'        => 'با تکمیل این پرسشنامه، موافقت خود را با استفاده از پاسخ‌هایم جهت تهیه کارنامه اعلام می‌کنم.',
			'متن پایان گزارش'       => '<h4>تذکر حرفه‌ای</h4><p>این فرم نمونه PAS-style است، SCAS-Parent رسمی ۳۸ گویه‌ای نیست و نمره یا نقطه برش آن به‌تنهایی تشخیص بالینی محسوب نمی‌شود. ترجمه، حق استفاده، هنجارها و تفسیر را با متخصص مسئول تأیید کنید.</p><h4>راهکارهای پیشنهادی</h4><ul><li>آموزش شناخت و آگاهی از هیجانات به کودک</li><li>استفاده از تکنیک‌های ذهن‌آگاهی مختص کودکان</li><li>استفاده از تن‌آرامی پیش‌رونده و آموزش تنفس دیافراگمی</li><li>ایفای نقش موقعیت‌های اضطراب‌زا</li><li>بازی‌درمانی و شن‌درمانی</li></ul><h4>معرفی کتاب</h4><ul><li>کتاب کمک به کودک مضطرب (رانلد راپی و همکاران)</li><li>کتاب کودک مضطرب شما (جان دسی)</li><li>کتاب از علائم تا درمان اضطراب کودک و نوجوان (نصیره مقدم‌فر)</li></ul>',
			'وضعیت'               => 'draft',
		);
		foreach ( $fields as $k => $v ) {
			$meta[] = array( array( 'v' => $k, 's' => 6 ), array( 'v' => (string) $v, 's' => 2 ) );
		}
		$writer->add_sheet( 'پرسشنامه', $meta, array( 'header_rows' => 1, 'col_widths' => array( 30, 80 ) ) );

		/* زیرمقیاس‌ها */
		$subs = array(
			array( 'SEP', 'اضطراب جدایی', 'دلبستگی و اضطراب هنگام جدا شدن از والدین', '#3b82f6', 'بله' ),
			array( 'GAD', 'اضطراب فراگیر', 'نگرانی مفرط، غیرقابل کنترل و مداوم', '#8b5cf6', 'بله' ),
			array( 'SOC', 'اضطراب اجتماعی', 'ترس از ارزیابی منفی در موقعیت‌های اجتماعی', '#ec4899', 'بله' ),
			array( 'PHY', 'ترس از آسیب جسمی', 'ترس از بیماری، آسیب و موقعیت‌های خطرناک', '#f59e0b', 'بله' ),
			array( 'OCD', 'وسواس فکری-عملی', 'افکار مزاحم و رفتارهای تکراری', '#10b981', 'بله' ),
			array( 'PTSD', 'اضطراب پس از سانحه', 'علائم پس از تجربه حادثه آسیب‌زا؛ جدا از نمره کل هسته گزارش می‌شود.', '#ef4444', 'خیر' ),
		);
		$sub_rows = array( array( array( 'v' => 'نام (کد)', 's' => 1 ), array( 'v' => 'عنوان نمایشی', 's' => 1 ), array( 'v' => 'توضیح', 's' => 1 ), array( 'v' => 'رنگ', 's' => 1 ), array( 'v' => 'در نمره کل لحاظ شود', 's' => 1 ) ) );
		foreach ( $subs as $r ) {
			$sub_rows[] = $r;
		}
		$writer->add_sheet( 'زیرمقیاس‌ها', $sub_rows, array( 'header_rows' => 1, 'col_widths' => array( 12, 24, 46, 12, 18 ) ) );

		/* نقاط برش */
		$cut = array(
			'SEP'  => array( 0, 4, 8, 12, 20 ),
			'GAD'  => array( 0, 5, 10, 15, 20 ),
			'SOC'  => array( 0, 6, 12, 18, 24 ),
			'PHY'  => array( 0, 7, 14, 21, 28 ),
			'OCD'  => array( 0, 5, 10, 15, 20 ),
			'PTSD' => array( 0, 6, 12, 18, 21 ),
		);
		$titles  = array( 'طبیعی', 'خفیف', 'متوسط', 'شدید' );
		$colors  = array( '#16a34a', '#84cc16', '#f59e0b', '#ef4444' );
		$sevs    = array( 'normal', 'mild', 'moderate', 'severe' );
		$band_rows = array( array( array( 'v' => 'زیرمقیاس', 's' => 1 ), array( 'v' => 'از (شامل)', 's' => 1 ), array( 'v' => 'تا (غیرشامل)', 's' => 1 ), array( 'v' => 'برچسب سطح', 's' => 1 ), array( 'v' => 'شدت', 's' => 1 ), array( 'v' => 'رنگ', 's' => 1 ), array( 'v' => 'تفسیر', 's' => 1 ) ) );
		foreach ( $cut as $code => $points ) {
			$name = '';
			foreach ( $subs as $sr ) {
				if ( $sr[0] === $code ) {
					$name = $sr[1];
					break;
				}
			}
			$texts = array(
				'نمره {score} از {max} در محدوده بهنجار است؛ نشانه‌ای قابل توجه از ' . $name . ' دیده نمی‌شود.',
				'نشانه‌های خفیف ' . $name . ' وجود دارد (نمره {score} از {max} — {percent}). آموزش مهارت‌های مقابله و پیگیری دوره‌ای پیشنهاد می‌شود.',
				'نمره {score} از {max} در سطح متوسط است؛ ' . $name . ' از نظر بالینی قابل توجه است و مشاوره تخصصی کودک توصیه می‌شود.',
				'نمره {score} از {max} در محدوده شدید است؛ نشانه‌های ' . $name . ' به‌طور معنادار وجود دارد و ارجاع به روان‌شناس کودک ضروری است.',
			);
			for ( $i = 0; $i < 4; $i++ ) {
				$band_rows[] = array( array( 'v' => $code, 's' => 2 ), (float) $points[ $i ], (float) $points[ $i + 1 ], $titles[ $i ], $sevs[ $i ], $colors[ $i ], $texts[ $i ] );
			}
		}
		// نمره کل.
		$band_rows[] = array( array( 'v' => 'نمره کل', 's' => 2 ), 0, 60, 'پایین‌تر از حد قابل توجه', 'normal', '#16a34a', 'نمره کل {score} از {max} است؛ در مجموع نشانه‌های اضطراب در سطح قابل توجه نیست.' );
		$band_rows[] = array( array( 'v' => 'نمره کل', 's' => 2 ), 60, 90, 'قابل توجه', 'moderate', '#f59e0b', 'نمره کل {score} از {max} است؛ اضطراب در سطح متوسط قرار دارد و دریافت کمک تخصصی توصیه می‌شود.' );
		$band_rows[] = array( array( 'v' => 'نمره کل', 's' => 2 ), 90, 999, 'شدید', 'severe', '#ef4444', 'نمره کل {score} از {max} است؛ نشانه‌های اضطراب در سطح شدید گزارش شده است.' );
		$writer->add_sheet( 'نقاط برش', $band_rows, array( 'header_rows' => 1, 'col_widths' => array( 12, 12, 14, 20, 12, 12, 70 ) ) );

		/* سوالات */
		$items = self::sample_items();
		$item_header = array( array( 'v' => 'شماره', 's' => 1 ), array( 'v' => 'متن سوال', 's' => 1 ), array( 'v' => 'نوع پاسخ', 's' => 1 ), array( 'v' => 'زیرمقیاس', 's' => 1 ), array( 'v' => 'تصویر سوال', 's' => 1 ), array( 'v' => 'معکوس', 's' => 1 ), array( 'v' => 'اجباری', 's' => 1 ), array( 'v' => 'شرط نمایش', 's' => 1 ), array( 'v' => 'یادداشت', 's' => 1 ) );
		for ( $i = 1; $i <= 5; $i++ ) {
			$item_header[] = array( 'v' => 'گزینه ' . $i . ' متن', 's' => 1 );
			$item_header[] = array( 'v' => 'گزینه ' . $i . ' امتیاز', 's' => 1 );
			$item_header[] = array( 'v' => 'گزینه ' . $i . ' تصویر', 's' => 1 );
		}
		$item_rows = array( $item_header );
		foreach ( $items as $it ) {
			$row = array( array( 'v' => $it['number'], 's' => 3 ), array( 'v' => $it['text'], 's' => 2 ), ( isset( $it['answer_type'] ) && 'text' === $it['answer_type'] ) ? 'متنی' : 'گزینه‌ای', array( 'v' => $it['sub'], 's' => 2 ), '', $it['reversed'] ? 'بله' : 'خیر', ! empty( $it['required'] ) ? 'بله' : 'خیر', $it['cond'], $it['note'] );
			foreach ( $it['options'] as $o ) {
				$row[] = array( 'v' => $o[0], 's' => 2 );
				$row[] = (float) $o[1];
				$row[] = '';
			}
			$item_rows[] = $row;
		}
		$widths = array( 8, 60, 14, 14, 20, 10, 10, 14, 26 );
		for ( $i = 0; $i < 5; $i++ ) {
			$widths[] = 20;
			$widths[] = 10;
			$widths[] = 20;
		}
		$writer->add_sheet( 'سوالات', $item_rows, array( 'header_rows' => 1, 'col_widths' => $widths, 'landscape' => true ) );

		$path = self::tmp_path( 'sample' );
		$writer->save( $path );
		return $path;
	}


	/**
	 * ساخت فایل نمونه SCAS-Parent (۳۸ گویه نمره‌دار + سؤال باز اختیاری).
	 *
	 * متن فارسی داخل نمونه، قابل ویرایش است. پیش از استفاده تشخیصی، آن را با
	 * ترجمه معتبر و هنجارهای سن/جنس مورد تأیید متخصص تطبیق دهید.
	 *
	 * @return string
	 */
	private static function build_scas_parent_sample_file() {
		$writer = new PsyQ_XLSX_Writer();

		$meta = array( array( array( 'v' => 'کلید', 's' => 1 ), array( 'v' => 'مقدار', 's' => 1 ) ) );
		$fields = array(
			'عنوان پرسشنامه'      => 'مقیاس اضطراب کودکان اسپنس — نسخه والد (SCAS-Parent)',
			'کد پرسشنامه'         => 'SCAS-PARENT-38',
			'توضیحات'             => 'فرم والد SCAS-Parent با ۳۸ گویه نمره‌دار، ۶ زیرمقیاس و یک سؤال باز اختیاری. پاسخ هر گویه: هرگز، گاهی، اغلب یا همیشه (۰ تا ۳). نمره کل خام ۰ تا ۱۱۴ است. متن فارسی، حقوق استفاده، هنجارهای سن/جنس و تفسیر را پیش از استفاده حرفه‌ای با منبع معتبر و متخصص تأیید کنید.',
			'تعداد گزینه پیش‌فرض'   => 4,
			'نمایش نمره کل'        => 'بله',
			'عنوان نمره کل'        => 'نمره کل اضطراب (خام)',
			'تعداد سوال در هر صفحه' => 19,
			'نمایش نمودار'         => 'بله',
			'متن معرفی'            => 'لطفاً مشخص کنید هر عبارت تا چه اندازه و با چه فراوانی درباره کودک شما صدق می‌کند. پاسخ‌ها «هرگز، گاهی، اغلب، همیشه» هستند. سؤال باز پایانی اختیاری و بدون نمره است.',
			'متن رضایت‌نامه'        => 'با تکمیل پرسشنامه، رضایت خود را برای ثبت پاسخ‌ها و تهیه کارنامه اعلام می‌کنم.',
			'متن پایان گزارش'       => '<h4>تذکر حرفه‌ای</h4><p>این کارنامه نمره خام را نمایش می‌دهد و به‌تنهایی تشخیص بالینی نیست. تفسیر SCAS-Parent باید با هنجار سن و جنس، مصاحبه بالینی و نظر روان‌شناس کودک انجام شود.</p><h4>پیشنهاد اولیه</h4><p>در صورت نگرانی پایدار یا اختلال در عملکرد کودک، برای ارزیابی تکمیلی با متخصص سلامت روان کودک مشورت کنید.</p>',
			'وضعیت'               => 'draft',
		);
		foreach ( $fields as $k => $v ) {
			$meta[] = array( array( 'v' => $k, 's' => 6 ), array( 'v' => (string) $v, 's' => 2 ) );
		}
		$writer->add_sheet( 'پرسشنامه', $meta, array( 'header_rows' => 1, 'col_widths' => array( 30, 92 ) ) );

		$subs = array(
			array( 'GAD', 'اضطراب فراگیر', 'نگرانی‌های مکرر، احساس ترس و علائم بدنی هنگام نگرانی (۶ گویه، ۰ تا ۱۸).', '#8b5cf6', 'بله' ),
			array( 'PHY', 'ترس از آسیب جسمی', 'ترس از تاریکی، حیوانات، پزشک، ارتفاع و حشرات (۵ گویه، ۰ تا ۱۵).', '#f59e0b', 'بله' ),
			array( 'SEP', 'اضطراب جدایی', 'نگرانی و ترس هنگام دوری از والد یا خانه (۶ گویه، ۰ تا ۱۸).', '#3b82f6', 'بله' ),
			array( 'SOC', 'اضطراب اجتماعی', 'ترس از ارزیابی دیگران و موقعیت‌های عملکردی/اجتماعی (۶ گویه، ۰ تا ۱۸).', '#ec4899', 'بله' ),
			array( 'PAN', 'حملات هراس و گذرهراسی', 'نشانه‌های ناگهانی هراس، اجتناب از سفر، ازدحام و مکان‌های بسته (۹ گویه، ۰ تا ۲۷).', '#ef4444', 'بله' ),
			array( 'OCD', 'وسواس فکری-عملی', 'افکار مزاحم، وارسی و رفتارهای تکراری/آیینی (۶ گویه، ۰ تا ۱۸).', '#10b981', 'بله' ),
		);
		$sub_rows = array( array( array( 'v' => 'نام (کد)', 's' => 1 ), array( 'v' => 'عنوان نمایشی', 's' => 1 ), array( 'v' => 'توضیح', 's' => 1 ), array( 'v' => 'رنگ', 's' => 1 ), array( 'v' => 'در نمره کل لحاظ شود', 's' => 1 ) ) );
		foreach ( $subs as $sub ) {
			$sub_rows[] = $sub;
		}
		$writer->add_sheet( 'زیرمقیاس‌ها', $sub_rows, array( 'header_rows' => 1, 'col_widths' => array( 12, 28, 74, 12, 18 ) ) );

		// نقاط برش خام جهان‌شمول در این ابزار وجود ندارد؛ برگه عمداً فقط سرستون دارد.
		// مدیر می‌تواند پس از انتخاب هنجار معتبر فارسی، بازه‌های سن/جنس مناسب را وارد کند.
		$band_rows = array( array( array( 'v' => 'زیرمقیاس', 's' => 1 ), array( 'v' => 'از (شامل)', 's' => 1 ), array( 'v' => 'تا (غیرشامل)', 's' => 1 ), array( 'v' => 'برچسب سطح', 's' => 1 ), array( 'v' => 'شدت', 's' => 1 ), array( 'v' => 'رنگ', 's' => 1 ), array( 'v' => 'تفسیر', 's' => 1 ) ) );
		$writer->add_sheet( 'نقاط برش', $band_rows, array( 'header_rows' => 1, 'col_widths' => array( 14, 12, 14, 24, 12, 12, 76 ) ) );

		$items = self::scas_parent_items();
		$item_header = array(
			array( 'v' => 'شماره', 's' => 1 ), array( 'v' => 'متن سوال', 's' => 1 ), array( 'v' => 'نوع پاسخ', 's' => 1 ), array( 'v' => 'زیرمقیاس', 's' => 1 ), array( 'v' => 'تصویر سوال', 's' => 1 ), array( 'v' => 'معکوس', 's' => 1 ), array( 'v' => 'اجباری', 's' => 1 ), array( 'v' => 'شرط نمایش', 's' => 1 ), array( 'v' => 'یادداشت', 's' => 1 )
		);
		for ( $i = 1; $i <= 4; $i++ ) {
			$item_header[] = array( 'v' => 'گزینه ' . $i . ' متن', 's' => 1 );
			$item_header[] = array( 'v' => 'گزینه ' . $i . ' امتیاز', 's' => 1 );
			$item_header[] = array( 'v' => 'گزینه ' . $i . ' تصویر', 's' => 1 );
		}
		$item_rows = array( $item_header );
		foreach ( $items as $it ) {
			$row = array(
				array( 'v' => $it['number'], 's' => 3 ),
				array( 'v' => $it['text'], 's' => 2 ),
				'text' === $it['answer_type'] ? 'متنی' : 'گزینه‌ای',
				array( 'v' => $it['sub'], 's' => 2 ),
				'',
				'خیر',
				! empty( $it['required'] ) ? 'بله' : 'خیر',
				'',
				$it['note'],
			);
			foreach ( $it['options'] as $opt ) {
				$row[] = array( 'v' => $opt[0], 's' => 2 );
				$row[] = (float) $opt[1];
				$row[] = '';
			}
			$item_rows[] = $row;
		}
		$widths = array( 8, 74, 14, 14, 18, 10, 10, 16, 42 );
		for ( $i = 0; $i < 4; $i++ ) {
			$widths[] = 18;
			$widths[] = 10;
			$widths[] = 18;
		}
		$writer->add_sheet( 'سوالات', $item_rows, array( 'header_rows' => 1, 'col_widths' => $widths, 'landscape' => true ) );

		$path = self::tmp_path( 'scasp38' );
		$writer->save( $path );
		return $path;
	}

	/**
	 * گویه‌های SCAS-Parent؛ ۳۸ گویه نمره‌دار و یک پاسخ باز اختیاری.
	 *
	 * @return array
	 */
	public static function scas_parent_items() {
		$map = array(
			'GAD' => array( 1, 3, 4, 18, 20, 22 ),
			'PHY' => array( 2, 16, 21, 23, 29 ),
			'SEP' => array( 5, 8, 11, 14, 15, 38 ),
			'SOC' => array( 6, 7, 9, 10, 26, 31 ),
			'PAN' => array( 12, 19, 25, 27, 28, 30, 32, 33, 34 ),
			'OCD' => array( 13, 17, 24, 35, 36, 37 ),
		);
		$texts = array(
			1  => 'کودک من درباره چیزهای مختلف نگران می‌شود.',
			2  => 'کودک من از تاریکی می‌ترسد.',
			3  => 'وقتی کودک من مشکلی دارد، از احساس عجیب یا ناراحت‌کننده در شکمش شکایت می‌کند.',
			4  => 'کودک من از احساس ترس شکایت می‌کند.',
			5  => 'کودک من از تنها ماندن در خانه می‌ترسد.',
			6  => 'کودک من هنگام امتحان یا آزمون دادن می‌ترسد.',
			7  => 'کودک من از استفاده از سرویس بهداشتی عمومی می‌ترسد.',
			8  => 'کودک من درباره دور بودن از من یا ما نگران می‌شود.',
			9  => 'کودک من می‌ترسد که در مقابل دیگران کار احمقانه یا خجالت‌آوری انجام دهد.',
			10 => 'کودک من نگران است که در مدرسه عملکرد بدی داشته باشد.',
			11 => 'کودک من نگران است اتفاق بسیار بدی برای یکی از اعضای خانواده بیفتد.',
			12 => 'کودک من ناگهان و بدون دلیل احساس می‌کند نمی‌تواند نفس بکشد.',
			13 => 'کودک من مدام وارسی می‌کند که کارها را درست انجام داده باشد؛ مثلاً خاموش بودن کلید یا قفل بودن در.',
			14 => 'کودک من اگر مجبور باشد تنها بخوابد می‌ترسد.',
			15 => 'کودک من صبح‌ها به دلیل عصبی یا ترسیده بودن، برای رفتن به مدرسه مشکل دارد.',
			16 => 'کودک من از سگ‌ها می‌ترسد.',
			17 => 'کودک من نمی‌تواند افکار بد یا بی‌معنی را از ذهنش بیرون کند.',
			18 => 'وقتی کودک من مشکلی دارد، از تند زدن قلبش شکایت می‌کند.',
			19 => 'کودک من ناگهان و بدون دلیل شروع به لرزیدن یا تکان خوردن می‌کند.',
			20 => 'کودک من نگران است اتفاق بدی برای خودش بیفتد.',
			21 => 'کودک من از رفتن نزد پزشک یا دندان‌پزشک می‌ترسد.',
			22 => 'وقتی کودک من مشکلی دارد، احساس لرزش می‌کند.',
			23 => 'کودک من از ارتفاع می‌ترسد؛ مثلاً بودن در بالای یک صخره یا جای بلند.',
			24 => 'کودک من برای جلوگیری از اتفاق بد، مجبور است افکار ویژه‌ای مانند اعداد یا کلمات را در ذهنش مرور کند.',
			25 => 'کودک من اگر مجبور باشد با خودرو، اتوبوس یا قطار سفر کند می‌ترسد.',
			26 => 'کودک من نگران است دیگران درباره او چه فکر می‌کنند.',
			27 => 'کودک من از مکان‌های شلوغ مانند مرکز خرید، سینما، اتوبوس یا زمین بازی شلوغ می‌ترسد.',
			28 => 'کودک من ناگهان و بدون هیچ دلیل روشنی خیلی می‌ترسد.',
			29 => 'کودک من از حشرات یا عنکبوت‌ها می‌ترسد.',
			30 => 'کودک من ناگهان و بدون دلیل احساس سرگیجه یا غش کردن می‌کند.',
			31 => 'کودک من هنگام صحبت کردن جلوی کلاس می‌ترسد.',
			32 => 'کودک من از تند شدن ناگهانی ضربان قلبش بدون دلیل شکایت می‌کند.',
			33 => 'کودک من نگران است ناگهان وقتی چیزی برای ترس وجود ندارد، احساس ترس کند.',
			34 => 'کودک من از بودن در مکان‌های کوچک و بسته مانند تونل یا اتاق کوچک می‌ترسد.',
			35 => 'کودک من مجبور است بعضی کارها را بارها انجام دهد؛ مانند شستن دست‌ها، تمیز کردن یا چیدن وسایل با ترتیب خاص.',
			36 => 'افکار یا تصویرهای بد یا بی‌معنی در ذهن کودک من او را آزار می‌دهند.',
			37 => 'کودک من مجبور است برای جلوگیری از اتفاق بد، کارها را دقیقاً به روش خاصی انجام دهد.',
			38 => 'کودک من اگر مجبور باشد یک شب دور از خانه بماند می‌ترسد.',
		);
		$options = array( array( 'هرگز', 0 ), array( 'گاهی', 1 ), array( 'اغلب', 2 ), array( 'همیشه', 3 ) );
		$out = array();
		foreach ( $texts as $number => $text ) {
			$sub = '';
			foreach ( $map as $code => $numbers ) {
				if ( in_array( $number, $numbers, true ) ) {
					$sub = $code;
					break;
				}
			}
			$out[] = array(
				'number'      => $number,
				'text'        => $text,
				'sub'         => $sub,
				'answer_type' => 'choice',
				'required'    => true,
				'note'        => '',
				'options'     => $options,
			);
		}
		$out[] = array(
			'number'      => 39,
			'text'        => 'آیا چیز دیگری هست که کودک شما واقعاً از آن می‌ترسد؟ اگر مایلید، آن را به‌اختصار بنویسید.',
			'sub'         => '',
			'answer_type' => 'text',
			'required'    => false,
			'note'        => 'سؤال باز اختیاری؛ در نمره‌گذاری ۳۸ گویه SCAS-Parent دخالت ندارد.',
			'options'     => array(),
		);
		return $out;
	}

	/**
	 * داده سؤال‌های نمونه و تولید ردیف‌های اکسل.
	 *
	 * @return array
	 */
	public static function sample_items() {
		$map = array(
			'SEP'  => array( 6, 12, 16, 22, 25 ),
			'GAD'  => array( 1, 4, 8, 14, 28 ),
			'SOC'  => array( 2, 5, 11, 15, 19, 23 ),
			'PHY'  => array( 7, 10, 13, 17, 20, 24, 26 ),
			'OCD'  => array( 3, 9, 18, 21, 27 ),
			'PTSD' => array( 30, 31, 32, 33, 34 ),
		);
		$texts = array(
			1  => 'برایش مشکل است که احساس نگرانی‌اش را متوقف کند.',
			2  => 'از این که کاری انجام دهد که در نظر دیگران احمق به نظر برسد، نگران است.',
			3  => 'مرتباً وارسی می‌کند که کارها را درست انجام داده باشد.',
			4  => 'به دلیل نگرانی، بی‌قرار و ناراحت است و تنش دارد.',
			5  => 'از اینکه از بزرگسالی (مربی پیش‌دبستان یا مهد کودک) کمک بخواهد می‌ترسد.',
			6  => 'دوست ندارد بدون شما یا جایی غیر از خانه خودتان بخوابد.',
			7  => 'از بلندی (مکان‌های مرتفع) می‌ترسد.',
			8  => 'به خاطر ترس و نگرانی در خوابیدن مشکل دارد.',
			9  => 'هر روز دست‌هایش را بارها می‌شوید.',
			10 => 'از مکان‌های بسته یا شلوغ می‌ترسد.',
			11 => 'از ملاقات یا صحبت کردن با افراد ناآشنا می‌ترسد.',
			12 => 'از اینکه برای پدر و مادرش اتفاق بدی بیفتد، نگران است.',
			13 => 'از رعد و برق می‌ترسد.',
			14 => 'بیشتر روز را صرف نگرانی در مورد چیزهای مختلف می‌کند.',
			15 => 'از صحبت کردن، اجرای نمایش و شعر خواندن جلوی دیگران می‌ترسد.',
			16 => 'نگران است که مبادا اتفاق بدی برایش بیفتد که دیگر شما را نبیند.',
			17 => 'از رفتن به استخر و شنا کردن عصبی می‌شود.',
			18 => 'احساس می‌کند برای جلوگیری از اتفاق بد، باید وسایل را با ترتیب خاصی بچیند.',
			19 => 'از اینکه در مقابل کارهای دیگران کار شرم‌آوری انجام دهد نگران است.',
			20 => 'از حشرات و عنکبوت‌ها می‌ترسد.',
			21 => 'افکار یا تصاویر بد و بی‌دلیلی دارد که مرتباً به ذهنش می‌آید.',
			22 => 'زمانی که او را در مهد کودک ترک می‌کنید، ناراحت و نگران می‌شود.',
			23 => 'از وارد شدن به گروه همسالان و شرکت در فعالیت‌های آنها می‌ترسد.',
			24 => 'از حیوانات خانگی می‌ترسد.',
			25 => 'کابوس‌هایی درباره جدا شدن از شما می‌بیند.',
			26 => 'از تاریکی می‌ترسد.',
			27 => 'برای جلوگیری از اتفاق بد، افکار خاصی (کلمات یا اعداد) را در ذهنش مرور می‌کند.',
			28 => 'در مواقعی که ضروری به نظر می‌رسد، مرتباً از دیگران اطمینان و تأیید می‌خواهد.',
			29 => 'آیا کودک شما تا به حال حادثه‌ای بد یا ضربه‌آور (مثلاً مرگ یکی از اعضای خانواده یا تصادف) را تجربه کرده است؟',
			30 => 'در مورد آن حادثه کابوس یا خواب‌های بدی می‌بیند.',
			31 => 'آن حادثه را به خاطر می‌آورد و ناراحت و پریشان می‌شود.',
			32 => 'وقتی چیزی از آن حادثه را به خاطرش می‌آورد، ناراحت می‌شود.',
			33 => 'ناگهان طوری رفتار می‌کند که انگار دوباره آن حادثه را تجربه کرده است.',
			34 => 'وقتی آن حادثه یادآوری می‌شود، علائم ترس (عرق کردن، لرزیدن یا بالارفتن ضربان قلب) را نشان می‌دهد.',
		);
		$likert = array( array( 'اصلاً درست نیست', 0 ), array( 'کمی درست است', 1 ), array( 'تا حدودی درست است', 2 ), array( 'خیلی درست است', 3 ), array( 'همیشه درست است', 4 ) );

		$out = array();
		foreach ( $texts as $num => $text ) {
			$sub = 'GAD';
			foreach ( $map as $code => $nums ) {
				if ( in_array( $num, $nums, true ) ) {
					$sub = $code;
					break;
				}
			}
			$is_gate = ( 29 === $num );
			if ( $is_gate ) {
				// سؤال دروازه‌ای صرفاً مسیر PTSD را فعال می‌کند و وارد هیچ نمره‌ای نمی‌شود.
				$sub = '';
			}
			$out[] = array(
				'number'      => $num,
				'text'        => $text,
				'sub'         => $sub,
				'answer_type' => 'choice',
				'reversed'    => false,
				'required'    => true,
				'cond'        => ( $num >= 30 ) ? '29=بله' : '',
				'note'        => $is_gate ? 'پاسخ «خیر» به این سوال، سؤال‌های ۳۰ تا ۳۴ و کادر شرح رویداد را پنهان می‌کند.' : '',
				'options'     => $is_gate ? array( array( 'بله', 0 ), array( 'خیر', 0 ) ) : $likert,
			);
			if ( $is_gate ) {
				// فیلد مکمل و بدون نمره؛ شماره ۲۹ تکراری است تا کنار سؤال دروازه‌ای بماند.
				$out[] = array(
					'number'      => 29,
					'text'        => 'در صورت پاسخ «بله»، لطفاً حادثه یا رویداد آسیب‌زا را به‌اختصار توضیح دهید (اختیاری).',
					'sub'         => '',
					'answer_type' => 'text',
					'reversed'    => false,
					'required'    => false,
					'cond'        => '29=بله',
					'note'        => 'این توضیح در نمره‌گذاری دخالت ندارد و فقط برای مشاهده متخصص ذخیره می‌شود.',
					'options'     => array(),
				);
			}
		}
		return $out;
	}

	/* ==================================================================
	 * ورود از اکسل
	 * ================================================================== */

	/**
	 * درون‌ریزی فایل اکسل.
	 *
	 * @param string $file مسیر فایل آپلودشده.
	 * @param array  $args گزینه‌ها: form_id, mode (replace|append|new), status.
	 * @return array|WP_Error
	 */
	public static function import( $file, $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'form_id' => 0,
				'mode'    => 'new',
				'status'  => 'draft',
			)
		);

		$reader = new PsyQ_XLSX_Reader();
		try {
			$names = $reader->sheet_names( $file );
			$data  = self::read_all_sheets( $reader, $file, $names );
		} catch ( Exception $e ) {
			return new WP_Error( 'psyq_excel', $e->getMessage() );
		}

		$warnings = array();

		// از ساخته‌شدن یک فرم خالی در صورت انتخاب شیت/سرستون نامعتبر جلوگیری کن.
		$valid_item_rows = 0;
		foreach ( $data['items'] as $candidate_item ) {
			$candidate_text = isset( $candidate_item['text'] ) ? trim( wp_strip_all_tags( (string) $candidate_item['text'] ) ) : '';
			if ( '' !== $candidate_text ) {
				$valid_item_rows++;
			}
		}
		if ( ! $valid_item_rows ) {
			return new WP_Error(
				'psyq_no_items',
				__( 'هیچ سؤال معتبری در فایل پیدا نشد. برگه «سوالات» باید دست‌کم ستون‌های «شماره» و «متن سوال» و یک ردیف سؤال داشته باشد.', 'psyq' )
			);
		}

		/* ------------- متادیتای پرسشنامه ------------- */
		$meta = array();
		if ( ! empty( $data['meta'] ) ) {
			foreach ( $data['meta'] as $row ) {
				$k = trim( isset( $row[0] ) ? $row[0] : '' );
				$v = isset( $row[1] ) ? trim( $row[1] ) : '';
				if ( '' !== $k ) {
					$meta[ $k ] = $v;
				}
			}
		}

		$form_data = array(
			'title'       => self::meta_get( $meta, array( 'عنوان پرسشنامه', 'عنوان', 'title' ), 'پرسشنامه بدون عنوان' ),
			'code'        => self::meta_get( $meta, array( 'کد پرسشنامه', 'کد', 'code' ), 'form-' . wp_rand( 1000, 9999 ) ),
			'description' => self::meta_get( $meta, array( 'توضیحات', 'شرح' ), '' ),
			'intro_html'  => self::meta_get( $meta, array( 'متن معرفی', 'معرفی' ), '' ),
			'consent_html' => self::meta_get( $meta, array( 'متن رضایت‌نامه', 'رضایت‌نامه' ), '' ),
			'report_footer_html' => self::meta_get( $meta, array( 'متن پایان گزارش', 'پانویس گزارش' ), '' ),
			'status'      => self::meta_get( $meta, array( 'وضعیت' ), $args['status'] ),
			'chart_engine' => self::meta_get( $meta, array( 'موتور نمودار' ), 'both' ),
			'items_per_page' => (int) self::meta_get( $meta, array( 'تعداد سوال در هر صفحه' ), 20 ),
			'default_option_count' => (int) self::meta_get( $meta, array( 'تعداد گزینه پیش‌فرض' ), 4 ),
			'show_total'  => self::meta_yes( self::meta_get( $meta, array( 'نمایش نمره کل' ), 'بله' ) ) ? 1 : 0,
			'show_charts' => self::meta_yes( self::meta_get( $meta, array( 'نمایش نمودار' ), 'بله' ) ) ? 1 : 0,
		);
		if ( ! in_array( $form_data['status'], array( 'draft', 'publish', 'private' ), true ) ) {
			$form_data['status'] = $args['status'];
		}
		if ( ! in_array( $form_data['chart_engine'], array( 'svg', 'chartjs', 'both' ), true ) ) {
			$form_data['chart_engine'] = 'both';
		}

		/* ------------- ساخت یا به‌روزرسانی فرم ------------- */
		$created_new_form = false;
		if ( $args['form_id'] ) {
			$form_id = (int) $args['form_id'];
			PsyQ_DB::save_form( $form_data, $form_id );
		} else {
			$form_id = PsyQ_DB::save_form( $form_data );
			$created_new_form = (bool) $form_id;
		}
		if ( ! $form_id ) {
			return new WP_Error( 'psyq_save', __( 'ذخیره پرسشنامه ناموفق بود.', 'psyq' ) );
		}

		if ( 'replace' === $args['mode'] || 'new' === $args['mode'] ) {
			PsyQ_DB::clear_items( $form_id );
			foreach ( PsyQ_DB::get_subscales( $form_id, true ) as $old ) {
				PsyQ_DB::delete_subscale( $old->id );
			}
		}

		/* ------------- زیرمقیاس‌ها ------------- */
		$sub_map = array(); // name => id
		if ( 'append' === $args['mode'] ) {
			foreach ( PsyQ_DB::get_subscales( $form_id ) as $s ) {
				$sub_map[ self::norm( $s->name ) ] = (int) $s->id;
			}
		}
		$order = 0;
		foreach ( $data['subs'] as $row ) {
			$name  = trim( isset( $row[0] ) ? $row[0] : '' );
			$title = trim( isset( $row[1] ) ? $row[1] : '' );
			if ( '' === $name && '' === $title ) {
				continue;
			}
			if ( '' === $name ) {
				$name = $title;
			}
			if ( '' === $title ) {
				$title = $name;
			}
			$key = self::norm( $name );
			if ( isset( $sub_map[ $key ] ) ) {
				continue;
			}
			$sid = PsyQ_DB::save_subscale(
				$form_id,
				array(
					'name'             => $name,
					'title'            => $title,
					'description'      => isset( $row[2] ) ? $row[2] : '',
					'color'            => isset( $row[3] ) && preg_match( '/^#[0-9a-f]{3,8}$/i', trim( $row[3] ) ) ? trim( $row[3] ) : self::auto_color( $order ),
					'include_in_total' => self::meta_yes( isset( $row[4] ) ? $row[4] : 'بله' ) ? 1 : 0,
					'sort_order'       => $order,
				)
			);
			$sub_map[ $key ] = (int) $sid;
			$order++;
		}

		/* ------------- نقاط برش ------------- */
		$band_count = 0;
		$total_bands = array();
		foreach ( $data['bands'] as $row ) {
			$sub_name = trim( isset( $row[0] ) ? $row[0] : '' );
			if ( '' === $sub_name ) {
				continue;
			}
			$key = self::norm( $sub_name );
			if ( ! isset( $sub_map[ $key ] ) ) {
				// ممکن است «نمره کل» باشد.
				if ( in_array( self::norm( $sub_name ), array( 'نمره کل', 'کل', 'total' ), true ) ) {
					$total_bands[] = $row;
					continue;
				}
				$warnings[] = sprintf( 'نقطه برش برای زیرمقیاس ناشناخته «%s» نادیده گرفته شد.', $sub_name );
				continue;
			}
			$sid = $sub_map[ $key ];
			PsyQ_DB::save_band(
				$form_id,
				$sid,
				array(
					'min_value'      => self::num( isset( $row[1] ) ? $row[1] : 0 ),
					'max_value'      => '' === trim( (string) ( isset( $row[2] ) ? $row[2] : '' ) ) ? 99999 : self::num( $row[2] ),
					'label'          => isset( $row[3] ) ? $row[3] : '',
					'severity'       => isset( $row[4] ) ? self::severity( $row[4] ) : 'normal',
					'color'          => isset( $row[5] ) && preg_match( '/^#[0-9a-f]{3,8}$/i', trim( $row[5] ) ) ? trim( $row[5] ) : '#64748b',
					'interpretation' => isset( $row[6] ) ? $row[6] : '',
				),
				$band_count
			);
			$band_count++;
		}

		/* ------------- نمره کل ------------- */
		$total_title = self::meta_get( $meta, array( 'عنوان نمره کل' ), __( 'نمره کل', 'psyq' ) );
		$total_row   = PsyQ_DB::get_total_subscale( $form_id );
		if ( $total_row ) {
			$total_id = (int) $total_row->id;
			PsyQ_DB::delete_bands( $total_id );
			global $wpdb;
			$wpdb->update( PsyQ_DB::table( 'subscales' ), array( 'title' => $total_title ), array( 'id' => $total_id ) );
		} else {
			global $wpdb;
			$wpdb->insert(
				PsyQ_DB::table( 'subscales' ),
				array(
					'form_id'          => $form_id,
					'name'             => '__TOTAL__',
					'title'            => $total_title,
					'description'      => '',
					'color'            => '#0f172a',
					'sort_order'       => 999,
					'include_in_total' => 1,
				)
			);
			$total_id = (int) $wpdb->insert_id;
		}
		foreach ( $total_bands as $row ) {
			PsyQ_DB::save_band(
				$form_id,
				$total_id,
				array(
					'min_value'      => self::num( isset( $row[1] ) ? $row[1] : 0 ),
					'max_value'      => '' === trim( (string) ( isset( $row[2] ) ? $row[2] : '' ) ) ? 99999 : self::num( $row[2] ),
					'label'          => isset( $row[3] ) ? $row[3] : '',
					'severity'       => isset( $row[4] ) ? self::severity( $row[4] ) : 'normal',
					'color'          => isset( $row[5] ) && trim( $row[5] ) ? trim( $row[5] ) : '#0f172a',
					'interpretation' => isset( $row[6] ) ? $row[6] : '',
				),
				$band_count
			);
			$band_count++;
		}

		/* ------------- گزینه‌های مشترک ------------- */
		$shared = array();
		foreach ( $data['shared'] as $row ) {
			$label = trim( isset( $row[1] ) ? $row[1] : '' );
			if ( '' === $label ) {
				continue;
			}
			$shared[] = array(
				'label'     => $label,
				'value'     => self::num( isset( $row[2] ) ? $row[2] : 0 ),
				'image_url' => isset( $row[3] ) ? trim( $row[3] ) : '',
				'image_id'  => 0,
			);
		}

		/* ------------- سوالات ------------- */
		$items_created = 0;
		$opts_created  = 0;
		$item_order    = 'append' === $args['mode'] ? count( PsyQ_DB::get_items( $form_id ) ) : 0;
		$numbers_used  = array();

		foreach ( $data['items'] as $row ) {
			$number      = isset( $row['number'] ) ? trim( $row['number'] ) : '';
			$text        = isset( $row['text'] ) ? trim( $row['text'] ) : '';
			$answer_type = self::answer_type( isset( $row['answer_type'] ) ? $row['answer_type'] : '' );
			if ( '' === $text && '' === $number ) {
				continue;
			}
			$number_int = (int) psyq_normalize_digits( preg_replace( '/[^\d۰-۹]/u', '', (string) $number ) );
			if ( $number_int <= 0 ) {
				$number_int = $item_order + 1;
			}
			// یک پاسخ متنی مشروط می‌تواند زیر سؤال دروازه‌ای همان شماره قرار گیرد
			// (نمونه: شرح حادثه زیر سؤال ۲۹). در این حالت شماره تکراری مجاز است.
			$cond_raw = isset( $row['condition'] ) ? trim( (string) $row['condition'] ) : '';
			$is_followup_text = 'text' === $answer_type && preg_match( '/^' . preg_quote( (string) $number_int, '/' ) . '\s*(?:=|!=|>=|<=|>|<)/u', $cond_raw );
			if ( ! $is_followup_text ) {
				while ( isset( $numbers_used[ $number_int ] ) ) {
					$number_int++;
				}
			}
			$numbers_used[ $number_int ] = true;

			$sub_name = isset( $row['subscale'] ) ? trim( $row['subscale'] ) : '';
			$sub_id   = 0;
			if ( '' !== $sub_name ) {
				$key = self::norm( $sub_name );
				if ( isset( $sub_map[ $key ] ) ) {
					$sub_id = $sub_map[ $key ];
				} else {
					// تطبیق با عنوان نمایشی.
					foreach ( $sub_map as $k => $id ) {
						$s = PsyQ_DB::get_subscale( $id );
						if ( $s && self::norm( $s->title ) === $key ) {
							$sub_id = (int) $id;
							break;
						}
					}
					if ( ! $sub_id ) {
						// ساخت خودکار زیرمقیاس جدید.
						$sub_id = PsyQ_DB::save_subscale(
							$form_id,
							array(
								'name'       => $sub_name,
								'title'      => $sub_name,
								'color'      => self::auto_color( count( $sub_map ) ),
								'sort_order' => count( $sub_map ),
							)
						);
						$sub_map[ $key ] = (int) $sub_id;
						$warnings[]      = sprintf( 'زیرمقیاس «%s» به صورت خودکار ساخته شد (در برگه زیرمقیاس‌ها تعریف نشده بود).', $sub_name );
					}
				}
			}

			$img = self::resolve_image( isset( $row['image'] ) ? $row['image'] : '' );

			$item_id = PsyQ_DB::save_item(
				$form_id,
				array(
					'number'       => $number_int,
					'sort_order'   => $item_order,
					'text'         => $text,
					'subscale_id'  => $sub_id,
					'image_id'     => $img['image_id'],
					'image_url'    => $img['image_url'],
					'answer_type'  => $answer_type,
					'option_count' => 'text' === $answer_type ? 0 : ( count( $row['options'] ) ? count( $row['options'] ) : count( $shared ) ),
					'scoring'      => 'inherit',
					'reversed'     => self::meta_yes( isset( $row['reversed'] ) ? $row['reversed'] : 'خیر' ) ? 1 : 0,
					'is_required'  => self::meta_yes( isset( $row['required'] ) ? $row['required'] : 'بله' ) ? 1 : 0,
					'condition'    => isset( $row['condition'] ) ? trim( $row['condition'] ) : '',
					'note'         => isset( $row['note'] ) ? trim( $row['note'] ) : '',
				)
			);
			if ( ! $item_id ) {
				global $wpdb;
				$detail = ! empty( $wpdb->last_error ) ? ' — ' . wp_strip_all_tags( $wpdb->last_error ) : '';
				// در ورودِ فرم تازه، شکست ذخیره سؤال نباید یک فرم خالی پشت سر بگذارد.
				if ( $created_new_form ) {
					PsyQ_DB::delete_form( $form_id );
				}
				return new WP_Error(
					'psyq_item_save',
					sprintf( __( 'ذخیره سؤال شماره %d ناموفق بود. ساختار پایگاه‌داده افزونه را به‌روزرسانی و دوباره تلاش کنید%s', 'psyq' ), $number_int, $detail )
				);
			}
			$items_created++;
			$item_order++;

			$use = 'text' === $answer_type ? array() : ( ! empty( $row['options'] ) ? $row['options'] : $shared );
			$oi  = 0;
			foreach ( $use as $o ) {
				$oimg = self::resolve_image( isset( $o['image_url'] ) ? $o['image_url'] : '' );
				PsyQ_DB::save_option(
					$item_id,
					$form_id,
					array(
						'label'      => $o['label'],
						'value'      => max( -5, min( 7, (float) $o['value'] ) ),
						'sort_order' => $oi,
						'image_url'  => $oimg['image_url'],
						'image_id'   => $oimg['image_id'],
					)
				);
				$oi++;
				$opts_created++;
			}

			if ( 'choice' === $answer_type && empty( $row['options'] ) && empty( $shared ) ) {
				$warnings[] = sprintf( 'سوال شماره %s هیچ گزینه‌ای ندارد.', $number_int );
			}
		}

		PsyQ_Scoring::clear_cache();

		return array(
			'form_id'  => $form_id,
			'items'    => $items_created,
			'options'  => $opts_created,
			'subs'     => count( $sub_map ),
			'bands'    => $band_count,
			'warnings' => $warnings,
		);
	}

	/**
	 * خواندن همه برگه‌ها با تشخیص نام.
	 */
	private static function read_all_sheets( $reader, $file, $names ) {
		$out = array(
			'meta'   => array(),
			'subs'   => array(),
			'bands'  => array(),
			'items'  => array(),
			'shared' => array(),
		);

		$map = array();
		foreach ( $names as $i => $name ) {
			$n            = self::norm( $name );
			$type         = self::sheet_type( $n );
			$map[ $type ] = $i;
		}

		// اگر نام برگه‌ها ناشناخته بود، حدس بر اساس محتوا.
		if ( ! isset( $map['items'] ) ) {
			foreach ( $names as $i => $name ) {
				$rows = $reader->read( $file, $i );
				if ( ! $rows ) {
					continue;
				}
				$header = $rows[0];
				$joined = implode( ' ', $header );
				if ( false !== mb_strpos( $joined, 'سوال' ) || false !== mb_strpos( $joined, 'گویه' ) ) {
					$map['items'] = $i;
					break;
				}
			}
		}
		if ( ! isset( $map['items'] ) ) {
			$map['items'] = 0;
		}

		foreach ( array( 'meta', 'subs', 'bands', 'items', 'shared' ) as $type ) {
			if ( ! isset( $map[ $type ] ) ) {
				continue;
			}
			$rows = $reader->read( $file, $map[ $type ] );
			if ( ! $rows ) {
				continue;
			}
			if ( 'items' === $type ) {
				$out['items'] = self::parse_items( $rows );
			} elseif ( 'meta' === $type ) {
				$out['meta'] = $rows;
			} else {
				// حذف ردیف سرستون.
				$out[ $type ] = array_slice( $rows, 1 );
			}
		}

		// اگر برگه زیرمقیاس نبود، از ستون زیرمقیاس سوالات استخراج کن.
		if ( empty( $out['subs'] ) && ! empty( $out['items'] ) ) {
			$seen = array();
			foreach ( $out['items'] as $row ) {
				$s = trim( $row['subscale'] );
				if ( '' !== $s && ! isset( $seen[ $s ] ) ) {
					$seen[ $s ]   = true;
					$out['subs'][] = array( $s, $s, '', self::auto_color( count( $seen ) ), 'بله' );
				}
			}
		}

		return $out;
	}

	private static function sheet_type( $n ) {
		if ( false !== strpos( $n, 'سوال' ) || false !== strpos( $n, 'گویه' ) || false !== strpos( $n, 'items' ) ) {
			return 'items';
		}
		if ( false !== strpos( $n, 'زیرمقیاس' ) || false !== strpos( $n, 'زیرمقیاسها' ) || false !== strpos( $n, 'subscal' ) ) {
			return 'subs';
		}
		if ( false !== strpos( $n, 'برش' ) || false !== strpos( $n, 'بازه' ) || false !== strpos( $n, 'band' ) ) {
			return 'bands';
		}
		if ( false !== strpos( $n, 'مشترک' ) || false !== strpos( $n, 'shared' ) ) {
			return 'shared';
		}
		if ( false !== strpos( $n, 'پرسشنامه' ) && false === strpos( $n, 'راهنما' ) || false !== strpos( $n, 'فرم' ) || false !== strpos( $n, 'meta' ) ) {
			return 'meta';
		}
		return 'other';
	}

	/**
	 * تجزیه برگه سوالات بر اساس سرستون‌های پویا.
	 *
	 * @param array $rows ردیف‌ها.
	 * @return array
	 */
	private static function parse_items( $rows ) {
		if ( empty( $rows ) ) {
			return array();
		}
		// یافتن ردیف سرستون.
		$header_index = 0;
		foreach ( $rows as $i => $r ) {
			$joined = self::norm( implode( ' ', $r ) );
			if ( false !== strpos( $joined, 'سوال' ) || false !== strpos( $joined, 'گویه' ) || false !== strpos( $joined, 'گزینه' ) ) {
				$header_index = $i;
				break;
			}
			if ( $i > 8 ) {
				break;
			}
		}
		$header = $rows[ $header_index ];
		$cols   = array();
		$opt_cols = array(); // index => array(text=>, value=>, image=>)

		foreach ( $header as $ci => $h ) {
			$hn = self::norm( $h );
			if ( '' === $hn ) {
				continue;
			}
			if ( self::match_any( $hn, array( 'شماره سوال', 'شماره', 'ردیف', '#' ) ) ) {
				$cols['number'] = $ci;
			} elseif ( false !== strpos( $hn, 'نوع پاسخ' ) || false !== strpos( $hn, 'نوع سوال' ) || false !== strpos( $hn, 'answer type' ) ) {
				$cols['answer_type'] = $ci;
			} elseif ( false !== strpos( $hn, 'زیرمقیاس' ) || false !== strpos( $hn, 'زیر مقیاس' ) ) {
				$cols['subscale'] = $ci;
			} elseif ( false !== strpos( $hn, 'معکوس' ) ) {
				$cols['reversed'] = $ci;
			} elseif ( false !== strpos( $hn, 'اجباری' ) || false !== strpos( $hn, 'الزامی' ) ) {
				$cols['required'] = $ci;
			} elseif ( false !== strpos( $hn, 'شرط' ) ) {
				$cols['condition'] = $ci;
			} elseif ( false !== strpos( $hn, 'یادداشت' ) || false !== strpos( $hn, 'توضیح' ) ) {
				$cols['note'] = $ci;
			} elseif ( false !== strpos( $hn, 'تصویر' ) || false !== strpos( $hn, 'عکس' ) ) {
				// تصویر گزینه یا سوال.
				if ( preg_match( '/گزینه\s*(\d+)/u', $hn, $m ) ) {
					$opt_cols[ (int) $m[1] ]['image'] = $ci;
				} else {
					$cols['image'] = $ci;
				}
			} elseif ( preg_match( '/گزینه\s*(\d+)/u', $hn, $m ) ) {
				$idx = (int) $m[1];
				if ( false !== strpos( $hn, 'امتیاز' ) || false !== strpos( $hn, 'نمره' ) ) {
					$opt_cols[ $idx ]['value'] = $ci;
				} else {
					$opt_cols[ $idx ]['text'] = $ci;
				}
			} elseif ( false !== strpos( $hn, 'متن سوال' ) || false !== strpos( $hn, 'متن گویه' ) || 'سوال' === $hn || 'گویه' === $hn ) {
				$cols['text'] = $ci;
			}
		}

		// حالت جایگزین: ستون‌های «گزینه ۱: متن/امتیاز» با شماره فارسی.
		if ( empty( $opt_cols ) ) {
			foreach ( $header as $ci => $h ) {
				$hn = self::norm( $h );
				if ( preg_match( '/^(?:گزینه|opt)\s*۰?(\d+)$/u', $hn, $m ) ) {
					$opt_cols[ (int) $m[1] ]['text'] = $ci;
				}
			}
		}

		ksort( $opt_cols );

		if ( ! isset( $cols['text'] ) ) {
			$cols['text'] = 1;
		}
		if ( ! isset( $cols['number'] ) ) {
			$cols['number'] = 0;
		}

		$out = array();
		for ( $i = $header_index + 1; $i < count( $rows ); $i++ ) {
			$row = $rows[ $i ];
			$get = function ( $key ) use ( $row, $cols ) {
				return isset( $cols[ $key ], $row[ $cols[ $key ] ] ) ? $row[ $cols[ $key ] ] : '';
			};
			$text = trim( $get( 'text' ) );
			$num  = trim( $get( 'number' ) );
			if ( '' === $text && '' === $num ) {
				continue;
			}

			$options = array();
			$blank_gap  = false;
			foreach ( $opt_cols as $idx => $c ) {
				$label = isset( $c['text'], $row[ $c['text'] ] ) ? trim( $row[ $c['text'] ] ) : '';
				$image = isset( $c['image'], $row[ $c['image'] ] ) ? trim( $row[ $c['image'] ] ) : '';
				if ( '' === $label && '' === $image ) {
					// فاصله خالی پس از شروع گزینه‌ها → پایان گزینه‌های این سوال.
					if ( ! empty( $options ) ) {
						$blank_gap = true;
					}
					continue;
				}
				if ( $blank_gap ) {
					break;
				}
				$value = isset( $c['value'], $row[ $c['value'] ] ) ? trim( $row[ $c['value'] ] ) : '';
				$options[] = array(
					'label'     => '' === $label ? '' : $label,
					'value'     => '' === $value ? 0 : self::num( $value ),
					'image_url' => $image,
				);
				$blank_gap = false;
			}

			$out[] = array(
				'number'      => $num,
				'text'        => $text,
				'answer_type' => trim( $get( 'answer_type' ) ),
				'subscale'  => trim( $get( 'subscale' ) ),
				'image'     => trim( $get( 'image' ) ),
				'reversed'  => trim( $get( 'reversed' ) ),
				'required'  => trim( $get( 'required' ) ),
				'condition' => trim( $get( 'condition' ) ),
				'note'      => trim( $get( 'note' ) ),
				'options'   => $options,
			);
		}
		return $out;
	}

	/* ==================================================================
	 * خروجی نتایج
	 * ================================================================== */

	/**
	 * خروجی اکسل پاسخ‌ها و نمرات.
	 *
	 * @param int   $form_id شناسه.
	 * @param array $responses ردیف‌های پاسخ.
	 * @return string مسیر فایل.
	 */
	public static function export_results( $form_id, $responses = null ) {
		$form = PsyQ_DB::get_form( $form_id );
		if ( ! $form ) {
			return '';
		}
		if ( null === $responses ) {
			$responses = PsyQ_DB::get_responses( array( 'form_id' => $form_id, 'limit' => 5000 ) );
		}
		$subs = PsyQ_DB::get_subscales( $form_id );

		$header = array(
			array( 'v' => 'ردیف', 's' => 1 ),
			array( 'v' => 'تاریخ', 's' => 1 ),
			array( 'v' => 'نام', 's' => 1 ),
			array( 'v' => 'نام خانوادگی', 's' => 1 ),
			array( 'v' => 'جنسیت', 's' => 1 ),
			array( 'v' => 'سن', 's' => 1 ),
			array( 'v' => 'تحصیلات', 's' => 1 ),
			array( 'v' => 'موبایل', 's' => 1 ),
			array( 'v' => 'ایمیل', 's' => 1 ),
			array( 'v' => 'مدت پاسخ‌دهی (ثانیه)', 's' => 1 ),
		);
		foreach ( $subs as $s ) {
			$header[] = array( 'v' => $s->title . ' — نمره', 's' => 1 );
			$header[] = array( 'v' => $s->title . ' — سطح', 's' => 1 );
		}
		$header[] = array( 'v' => 'نمره کل', 's' => 1 );

		$rows = array( $header );
		$i    = 1;
		foreach ( $responses as $r ) {
			$scores = json_decode( (string) $r->scores, true );
			$row    = array(
				array( 'v' => $i, 's' => 3 ),
				array( 'v' => mysql2date( 'Y/m/d H:i', $r->created_at ), 's' => 2 ),
				array( 'v' => $r->first_name, 's' => 2 ),
				array( 'v' => $r->last_name, 's' => 2 ),
				array( 'v' => 'male' === $r->gender ? 'مرد' : ( 'female' === $r->gender ? 'زن' : $r->gender ), 's' => 2 ),
				( $r->age ? (int) $r->age : '' ),
				array( 'v' => $r->education, 's' => 2 ),
				array( 'v' => $r->phone, 's' => 2 ),
				array( 'v' => $r->email, 's' => 2 ),
				(int) $r->duration_sec,
			);
			foreach ( $subs as $s ) {
				$sc = isset( $scores['subscales'][ $s->id ] ) ? $scores['subscales'][ $s->id ] : null;
				if ( $sc ) {
					$row[] = (float) $sc['score'];
					$row[] = array( 'v' => isset( $sc['band']['label'] ) ? $sc['band']['label'] : '', 's' => 2 );
				} else {
					$row[] = '';
					$row[] = '';
				}
			}
			$row[] = (float) $r->raw_total;
			$rows[] = $row;
			$i++;
		}

		$writer = new PsyQ_XLSX_Writer();
		$widths = array( 8, 16, 16, 18, 10, 8, 18, 16, 24, 20 );
		foreach ( $subs as $s ) {
			$widths[] = 14;
			$widths[] = 16;
		}
		$widths[] = 14;
		$writer->add_sheet( 'پاسخ‌ها', $rows, array( 'header_rows' => 1, 'col_widths' => $widths, 'landscape' => true ) );

		// شیت خام پاسخ‌های تک‌سوالی.
		$items = PsyQ_DB::get_items( $form_id );
		$raw   = array( array( array( 'v' => 'ردیف', 's' => 1 ), array( 'v' => 'تاریخ', 's' => 1 ) ) );
		foreach ( $items as $it ) {
			$is_text = isset( $it->answer_type ) && 'text' === $it->answer_type;
			$raw[0][] = array( 'v' => 'س' . $it->number . ( $is_text ? ' — پاسخ متنی' : '' ), 's' => 1 );
		}
		$j = 1;
		foreach ( $responses as $r ) {
			$answers = json_decode( (string) $r->answers, true );
			$line    = array( array( 'v' => $j, 's' => 3 ), array( 'v' => mysql2date( 'Y/m/d H:i', $r->created_at ), 's' => 2 ) );
			foreach ( $items as $it ) {
				$aid   = isset( $answers[ $it->id ] ) ? $answers[ $it->id ] : null;
				$label = '';
				if ( isset( $it->answer_type ) && 'text' === $it->answer_type ) {
					$label = is_scalar( $aid ) ? (string) $aid : '';
				} elseif ( null !== $aid ) {
					foreach ( PsyQ_DB::get_options( $it->id ) as $o ) {
						if ( (int) $o->id === (int) $aid ) {
							$label = $o->label . ' (' . PsyQ_Scoring::fmt( $o->value ) . ')';
							break;
						}
					}
				}
				$line[] = array( 'v' => $label, 's' => 2 );
			}
			$raw[] = $line;
			$j++;
		}
		$w = array( 8, 16 );
		foreach ( $items as $it ) {
			$w[] = 22;
		}
		$writer->add_sheet( 'پاسخ خام', $raw, array( 'header_rows' => 1, 'col_widths' => $w, 'landscape' => true ) );

		$path = self::tmp_path( 'results' );
		$writer->save( $path );
		return $path;
	}

	/* ==================================================================
	 * کمکی‌ها
	 * ================================================================== */

	public static function norm( $s ) {
		$s = (string) $s;
		$s = str_replace( array( "\xE2\x80\x8C", "\xEF\xBB\xBF", "\xE2\x80\x8F", "\xE2\x80\x8E" ), '', $s );
		$s = psyq_normalize_digits( $s );
		$s = str_replace( array( 'ي', 'ك', 'ۀ', 'ة', 'أ', 'إ', 'آ' ), array( 'ی', 'ک', 'ه', 'ه', 'ا', 'ا', 'ا' ), $s );
		$s = preg_replace( '/[\s\x{200B}]+/u', ' ', $s );
		$s = trim( $s );
		return mb_strtolower( $s, 'UTF-8' );
	}

	private static function match_any( $haystack, $needles ) {
		foreach ( $needles as $n ) {
			if ( $haystack === self::norm( $n ) ) {
				return true;
			}
		}
		return false;
	}

	public static function meta_get( $meta, $keys, $default = '' ) {
		foreach ( $keys as $k ) {
			if ( isset( $meta[ $k ] ) && '' !== trim( (string) $meta[ $k ] ) ) {
				return trim( (string) $meta[ $k ] );
			}
		}
		// تطبیق نرم.
		foreach ( $meta as $mk => $mv ) {
			foreach ( $keys as $k ) {
				if ( self::norm( $mk ) === self::norm( $k ) && '' !== trim( (string) $mv ) ) {
					return trim( (string) $mv );
				}
			}
		}
		return $default;
	}

	public static function meta_yes( $v ) {
		$v = self::norm( $v );
		return in_array( $v, array( 'بله', 'بلی', 'درست', 'yes', 'y', '1', 'true', 'فعال', 'دارد' ), true );
	}

	public static function meta_bool( $v ) {
		return self::meta_yes( $v );
	}

	/**
	 * نوع پاسخ سوال در فایل اکسل.
	 * متن آزاد در نمره‌گذاری دخالت ندارد اما در پاسخ آزمودنی ذخیره می‌شود.
	 */
	public static function answer_type( $value ) {
		$value = self::norm( $value );
		return in_array( $value, array( 'text', 'textarea', 'open', 'long text', 'متنی', 'متن', 'متن آزاد', 'متنازاد', 'پاسخ متنی', 'پاسخمتنی', 'تشریحی', 'آزاد' ), true ) ? 'text' : 'choice';
	}

	public static function num( $v ) {
		$v = trim( psyq_normalize_digits( (string) $v ) );
		$v = str_replace( array( '−', '–', '—', '٫', ',' ), array( '-', '-', '-', '.', '.' ), $v );
		$v = preg_replace( '/[^0-9\.\-\+]/', '', $v );
		return (float) $v;
	}

	private static function severity( $v ) {
		$v = self::norm( $v );
		$map = array(
			'normal'     => array( 'normal', 'طبیعی', 'بهنجار', 'نرمال', 'سالم' ),
			'mild'       => array( 'mild', 'خفیف', 'کم' ),
			'moderate'   => array( 'moderate', 'متوسط', 'میانه', 'مرزی' ),
			'severe'     => array( 'severe', 'شدید', 'زیاد' ),
			'critical'   => array( 'critical', 'بحرانی', 'بسیار شدید', 'خیلی شدید' ),
			'borderline' => array( 'borderline', 'مرزی' ),
		);
		foreach ( $map as $key => $words ) {
			if ( in_array( $v, $words, true ) ) {
				return $key;
			}
		}
		return 'normal';
	}

	private static function auto_color( $i ) {
		$colors = array( '#3b82f6', '#8b5cf6', '#ec4899', '#f59e0b', '#10b981', '#ef4444', '#0ea5e9', '#a855f7', '#14b8a6', '#f97316', '#6366f1', '#84cc16' );
		return $colors[ $i % count( $colors ) ];
	}

	/**
	 * تبدیل مقدار ستون تصویر به شناسه/آدرس معتبر.
	 *
	 * @param string $val مقدار.
	 * @return array
	 */
	public static function resolve_image( $val ) {
		$val = trim( (string) $val );
		if ( '' === $val || 'شرط-نمایش' === $val ) {
			return array( 'image_id' => 0, 'image_url' => '' );
		}
		if ( ctype_digit( $val ) ) {
			$url = wp_get_attachment_url( (int) $val );
			if ( $url ) {
				return array( 'image_id' => (int) $val, 'image_url' => $url );
			}
		}
		if ( preg_match( '#^https?://#i', $val ) ) {
			return array( 'image_id' => 0, 'image_url' => esc_url_raw( $val ) );
		}
		// جست‌وجو در کتابخانه رسانه بر اساس نام فایل.
		global $wpdb;
		$like = '%' . $wpdb->esc_like( basename( $val ) ) . '%';
		$id   = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_wp_attached_file' AND meta_value LIKE %s LIMIT 1",
				$like
			)
		);
		if ( $id ) {
			return array( 'image_id' => (int) $id, 'image_url' => wp_get_attachment_url( (int) $id ) );
		}
		return array( 'image_id' => 0, 'image_url' => esc_url_raw( $val ) );
	}
}
