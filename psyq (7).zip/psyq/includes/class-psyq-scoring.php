<?php
/**
 * موتور نمره‌گذاری، برش‌بندی و تولید تفسیر.
 *
 * @package PsyQ
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class PsyQ_Scoring {

	/** @var array کش بسته‌های پرسشنامه در یک درخواست */
	private static $cache = array();

	/**
	 * ساخت بسته کامل پرسشنامه (فرم + زیرمقیاس‌ها + سوالات + گزینه‌ها).
	 *
	 * @param int $form_id شناسه.
	 * @return array|false
	 */
	public static function bundle( $form_id ) {
		$form_id = (int) $form_id;
		if ( isset( self::$cache[ $form_id ] ) ) {
			return self::$cache[ $form_id ];
		}
		$form = PsyQ_DB::get_form( $form_id );
		if ( ! $form ) {
			return false;
		}

		$subs_raw  = PsyQ_DB::get_subscales( $form_id );
		$subscales = array();
		foreach ( $subs_raw as $s ) {
			$subscales[ (int) $s->id ] = array(
				'id'               => (int) $s->id,
				'name'             => $s->name,
				'title'            => $s->title ? $s->title : $s->name,
				'description'      => $s->description,
				'color'            => $s->color ? $s->color : '#4f46e5',
				'sort_order'       => (int) $s->sort_order,
				'include_in_total' => (int) $s->include_in_total,
				'bands'            => array(),
			);
			foreach ( PsyQ_DB::get_bands( (int) $s->id ) as $b ) {
				$subscales[ (int) $s->id ]['bands'][] = self::normalize_band( $b );
			}
		}

		$items = array();
		$opts  = PsyQ_DB::get_options_for_form( $form_id );
		$by_item = array();
		foreach ( $opts as $o ) {
			$by_item[ (int) $o->item_id ][] = array(
				'id'        => (int) $o->id,
				'label'     => $o->label,
				'value'     => (float) $o->value,
				'image_url' => $o->image_url,
				'image_id'  => (int) $o->image_id,
				'order'     => (int) $o->sort_order,
			);
		}

		foreach ( PsyQ_DB::get_items( $form_id ) as $it ) {
			$list = isset( $by_item[ (int) $it->id ] ) ? $by_item[ (int) $it->id ] : array();
			usort(
				$list,
				function ( $a, $b ) {
					return $a['order'] <=> $b['order'];
				}
			);
			$values = wp_list_pluck( $list, 'value' );
			$items[] = array(
				'id'           => (int) $it->id,
				'number'       => (int) $it->number,
				'text'         => $it->text,
				'answer_type'  => isset( $it->answer_type ) && 'text' === $it->answer_type ? 'text' : 'choice',
				'note'         => $it->note,
				'image_url'    => $it->image_url,
				'image_id'     => (int) $it->image_id,
				'subscale_id'  => (int) $it->subscale_id,
				'option_count' => (int) $it->option_count,
				'scoring'      => $it->scoring ? $it->scoring : 'inherit',
				'reversed'     => (int) $it->reversed,
				'is_required'  => (int) $it->is_required,
				'condition'    => self::parse_condition( $it->condition ),
				'options'      => $list,
				'min_value'    => $values ? min( $values ) : 0,
				'max_value'    => $values ? max( $values ) : 0,
			);
		}

		// زیرمقیاس مخفی «نمره کل».
		$total_row = PsyQ_DB::get_total_subscale( $form_id );
		$total     = null;
		if ( $total_row ) {
			$total = array(
				'id'    => (int) $total_row->id,
				'title' => $total_row->title ? $total_row->title : __( 'نمره کل', 'psyq' ),
				'color' => $total_row->color ? $total_row->color : '#0f172a',
				'bands' => array(),
			);
			foreach ( PsyQ_DB::get_bands( (int) $total_row->id ) as $b ) {
				$total['bands'][] = self::normalize_band( $b );
			}
		}

		$bundle = array(
			'form'       => $form,
			'subscales'  => $subscales,
			'items'      => $items,
			'total'      => $total,
			'total_used' => (int) $form->show_total === 1,
		);
		self::$cache[ $form_id ] = $bundle;
		return $bundle;
	}

	public static function clear_cache() {
		self::$cache = array();
	}

	private static function normalize_band( $b ) {
		return array(
			'id'             => (int) $b->id,
			'min'            => (float) $b->min_value,
			'max'            => (float) $b->max_value,
			'label'          => $b->label,
			'severity'       => $b->severity,
			'color'          => $b->color ? $b->color : '#22c55e',
			'interpretation' => $b->interpretation,
			'order'          => (int) $b->sort_order,
		);
	}

	/**
	 * تجزیه شرط نمایش سوال. مثال: 29=بله یا 29!=خیر یا 29>0
	 *
	 * @param string $raw شرط خام.
	 * @return array|null
	 */
	public static function parse_condition( $raw ) {
		$raw = trim( (string) $raw );
		if ( '' === $raw ) {
			return null;
		}
		if ( ! preg_match( '/^(\d+)\s*(=|!=|>=|<=|>|<)\s*(.+)$/u', $raw, $m ) ) {
			return null;
		}
		return array(
			'item' => (int) $m[1],
			'op'   => $m[2],
			'val'  => trim( $m[3] ),
			'raw'  => $raw,
		);
	}

	/**
	 * آیا سوال باید نمایش داده شود؟
	 *
	 * @param array $item    سوال.
	 * @param array $answers پاسخ‌ها (item_number => option_id|label).
	 * @param array $bundle  بسته.
	 * @return bool
	 */
	public static function is_item_visible( $item, $answers, $bundle ) {
		if ( empty( $item['condition'] ) ) {
			return true;
		}
		$c        = $item['condition'];
		$ref_item = null;
		foreach ( $bundle['items'] as $cand ) {
			if ( (int) $cand['number'] !== (int) $c['item'] ) {
				continue;
			}
			// شماره تکراری برای پیوست متنی مجاز است؛ شرط باید از سؤال گزینه‌ایِ
			// دروازه‌ای خوانده شود، نه از textarea با همان شماره.
			if ( 'text' === ( $cand['answer_type'] ?? 'choice' ) ) {
				if ( null === $ref_item ) {
					$ref_item = $cand;
				}
				continue;
			}
			$ref_item = $cand;
			break;
		}
		if ( ! $ref_item ) {
			return true;
		}
		$key = (int) $ref_item['id'];
		if ( ! isset( $answers[ $key ] ) || '' === $answers[ $key ] ) {
			return false;
		}
		$answer   = $answers[ $key ];
		$opt_text = '';
		$opt_val  = null;
		foreach ( $ref_item['options'] as $o ) {
			if ( (int) $o['id'] === (int) $answer ) {
				$opt_text = $o['label'];
				$opt_val  = $o['value'];
				break;
			}
		}
		$cond_val = $c['val'];
		switch ( $c['op'] ) {
			case '=':
				return ( $opt_text === $cond_val ) || ( null !== $opt_val && is_numeric( $cond_val ) && (float) $opt_val === (float) $cond_val );
			case '!=':
				return ! ( ( $opt_text === $cond_val ) || ( null !== $opt_val && is_numeric( $cond_val ) && (float) $opt_val === (float) $cond_val ) );
			default:
				if ( null === $opt_val || ! is_numeric( $cond_val ) ) {
					return true;
				}
				$v = (float) $opt_val;
				$t = (float) $cond_val;
				if ( '>' === $c['op'] ) {
					return $v > $t;
				}
				if ( '<' === $c['op'] ) {
					return $v < $t;
				}
				if ( '>=' === $c['op'] ) {
					return $v >= $t;
				}
				return $v <= $t;
		}
	}

	/**
	 * نمره‌گذاری پاسخ‌ها.
	 *
	 * @param int   $form_id شناسه پرسشنامه.
	 * @param array $answers آرایه: item_id => option_id.
	 * @return array|WP_Error
	 */
	public static function score( $form_id, $answers ) {
		$bundle = self::bundle( $form_id );
		if ( ! $bundle ) {
			return new WP_Error( 'psyq_no_form', __( 'پرسشنامه یافت نشد.', 'psyq' ) );
		}

		$detail     = array();
		$sub_scores = array();
		$sub_max    = array();
		$sub_min    = array();
		$sub_count  = array();

		foreach ( $bundle['subscales'] as $sid => $s ) {
			$sub_scores[ $sid ] = 0.0;
			$sub_max[ $sid ]    = 0.0;
			$sub_min[ $sid ]    = 0.0;
			$sub_count[ $sid ]  = 0;
		}

		$answered = 0;

		foreach ( $bundle['items'] as $item ) {
			if ( ! self::is_item_visible( $item, $answers, $bundle ) ) {
				$detail[ $item['id'] ] = array(
					'item_id'    => $item['id'],
					'number'     => $item['number'],
					'option_id'  => null,
					'label'      => '',
					'value'      => null,
					'earned'     => null,
					'reversed'   => false,
					'subscale'   => (int) $item['subscale_id'],
					'answer_type' => $item['answer_type'] ?? 'choice',
					'skipped'    => true,
				);
				continue;
			}

			// پاسخ متنی: ثبت می‌شود اما در نمره، بیشینه و نمودار وارد نمی‌شود.
			if ( 'text' === ( $item['answer_type'] ?? 'choice' ) ) {
				$raw_text = isset( $answers[ $item['id'] ] ) ? trim( (string) $answers[ $item['id'] ] ) : '';
				if ( '' !== $raw_text ) {
					$answered++;
				}
				$detail[ $item['id'] ] = array(
					'item_id'     => $item['id'],
					'number'      => $item['number'],
					'option_id'   => null,
					'label'       => $raw_text,
					'value'       => null,
					'earned'      => null,
					'reversed'    => false,
					'subscale'    => (int) $item['subscale_id'],
					'answer_type' => 'text',
					'skipped'     => false,
				);
				continue;
			}

			$opt_id = isset( $answers[ $item['id'] ] ) ? $answers[ $item['id'] ] : null;
			$chosen = null;
			foreach ( $item['options'] as $o ) {
				if ( null !== $opt_id && (int) $o['id'] === (int) $opt_id ) {
					$chosen = $o;
					break;
				}
			}

			$earned   = null;
			$reversed = false;
			if ( $chosen ) {
				$answered++;
				$earned = (float) $chosen['value'];
				// نمره‌گذاری معکوس بر پایه کمینه/بیشینه همان سوال.
				if ( ! empty( $item['reversed'] ) ) {
					$earned   = ( $item['min_value'] + $item['max_value'] ) - $earned;
					$reversed = true;
				}
				$sid = (int) $item['subscale_id'];
				if ( isset( $sub_scores[ $sid ] ) ) {
					$sub_scores[ $sid ] += $earned;
					$sub_count[ $sid ]++;
				}
			}

			// بیشینه/کمینه ممکن برای زیرمقیاس (فقط سوالات نمایش‌داده‌شده).
			$sid = (int) $item['subscale_id'];
			if ( isset( $sub_scores[ $sid ] ) && $item['options'] ) {
				$sub_max[ $sid ] += $item['max_value'];
				$sub_min[ $sid ] += $item['min_value'];
			}

			$detail[ $item['id'] ] = array(
				'item_id'   => $item['id'],
				'number'    => $item['number'],
				'option_id' => $chosen ? $chosen['id'] : null,
				'label'     => $chosen ? $chosen['label'] : '',
				'value'     => $chosen ? (float) $chosen['value'] : null,
				'earned'    => $earned,
				'reversed'  => $reversed,
				'subscale'  => $sid,
				'answer_type' => 'choice',
				'skipped'   => false,
			);
		}

		// ساخت خروجی زیرمقیاس‌ها.
		$out_sub = array();
		$total_score = 0.0;
		$total_max   = 0.0;
		$total_min   = 0.0;
		foreach ( $bundle['subscales'] as $sid => $s ) {
			$score = round( $sub_scores[ $sid ], 2 );
			$max   = round( $sub_max[ $sid ], 2 );
			$min   = round( $sub_min[ $sid ], 2 );
			$band  = self::resolve_band( $score, $s['bands'] );

			if ( ! empty( $s['include_in_total'] ) ) {
				$total_score += $score;
				$total_max   += $max;
				$total_min   += $min;
			}

			$out_sub[ $sid ] = array(
				'id'          => $sid,
				'name'        => $s['name'],
				'title'       => $s['title'],
				'description' => $s['description'],
				'color'       => $s['color'],
				'score'       => $score,
				'max'         => $max,
				'min'         => $min,
				'percent'     => $max > $min ? round( ( $score - $min ) / ( $max - $min ) * 100, 1 ) : 0,
				'raw_percent' => $max > 0 ? round( $score / $max * 100, 1 ) : 0,
				'item_count'  => $sub_count[ $sid ],
				'answered'    => $sub_count[ $sid ],
				'in_total'    => (int) $s['include_in_total'],
				'band'        => $band,
				'bands'       => $s['bands'],
			);
		}

		// نمره کل.
		$total = null;
		if ( ! empty( $bundle['total_used'] ) && $bundle['total'] ) {
			$total = array(
				'id'          => $bundle['total']['id'],
				'title'       => $bundle['total']['title'],
				'color'       => $bundle['total']['color'],
				'score'       => round( $total_score, 2 ),
				'max'         => round( $total_max, 2 ),
				'min'         => round( $total_min, 2 ),
				'percent'     => $total_max > $total_min ? round( ( $total_score - $total_min ) / ( $total_max - $total_min ) * 100, 1 ) : 0,
				'band'        => self::resolve_band( round( $total_score, 2 ), $bundle['total']['bands'] ),
				'bands'       => $bundle['total']['bands'],
			);
		}

		return array(
			'form_id'        => (int) $form_id,
			'form_title'     => $bundle['form']->title,
			'items'          => $detail,
			'subscales'      => $out_sub,
			'total'          => $total,
			'answered_count' => $answered,
			'item_count'     => count( $bundle['items'] ),
			'grand_total'    => round( $total_score, 2 ),
			'scored_at'      => current_time( 'mysql' ),
		);
	}

	/**
	 * یافتن بازه (نقطه برش) متناسب با نمره.
	 *
	 * @param float $score نمره.
	 * @param array $bands بازه‌ها.
	 * @return array|null
	 */
	public static function resolve_band( $score, $bands ) {
		if ( empty( $bands ) ) {
			return null;
		}
		usort(
			$bands,
			function ( $a, $b ) {
				return $a['min'] <=> $b['min'];
			}
		);
		$last = end( $bands );
		foreach ( $bands as $b ) {
			if ( $score >= $b['min'] && $score < $b['max'] ) {
				return $b;
			}
		}
		if ( $score >= $last['min'] ) {
			$last['max'] = max( $last['max'], $score );
			return $last;
		}
		$first = reset( $bands );
		return $first;
	}

	/* ==================================================================
	 * تولید گزارش
	 * ================================================================== */

	/**
	 * ساخت HTML گزارش تفسیری.
	 *
	 * @param int   $form_id شناسه.
	 * @param array $scores  خروجی score().
	 * @param array $args    گزینه‌ها: response (ردیف پاسخ), context (admin|front).
	 * @return string
	 */
	public static function render_report( $form_id, $scores, $args = array() ) {
		$bundle = self::bundle( $form_id );
		$form   = $bundle ? $bundle['form'] : null;
		$engine = $form ? $form->chart_engine : 'both';
		$show_charts = $form ? (int) $form->show_charts : 1;

		$response = isset( $args['response'] ) ? $args['response'] : null;
		$is_admin = isset( $args['context'] ) && 'admin' === $args['context'];

		$subs = $scores['subscales'];
		$total = $scores['total'];

		ob_start();
		?>
		<div class="psyq-report" dir="rtl">
			<header class="psyq-report__head">
				<div class="psyq-report__title">
					<h2><?php echo esc_html( $form ? $form->title : $scores['form_title'] ); ?></h2>
					<p class="psyq-report__sub"><?php esc_html_e( 'گزارش تفسیری نتیجه آزمون', 'psyq' ); ?>
						<?php if ( $response ) : ?>
							· <?php echo esc_html( mysql2date( 'Y/m/d H:i', $response->created_at ) ); ?>
						<?php endif; ?>
					</p>
					<?php if ( $response && ( $response->first_name || $response->last_name ) ) : ?>
						<p class="psyq-report__meta">
							<?php echo esc_html( trim( $response->first_name . ' ' . $response->last_name ) ); ?>
							<?php if ( ! empty( $response->age ) ) : ?> · <?php echo esc_html( (int) $response->age ); ?> <?php esc_html_e( 'سال', 'psyq' ); ?><?php endif; ?>
							<?php if ( ! empty( $response->gender ) ) : ?> · <?php echo esc_html( 'male' === $response->gender ? __( 'مرد', 'psyq' ) : ( 'female' === $response->gender ? __( 'زن', 'psyq' ) : $response->gender ) ); ?><?php endif; ?>
						</p>
					<?php endif; ?>
				</div>
				<div class="psyq-report__badge">
					<span><?php esc_html_e( 'تعداد پاسخ‌های ثبت‌شده', 'psyq' ); ?></span>
					<strong><?php echo esc_html( $scores['answered_count'] ); ?> / <?php echo esc_html( $scores['item_count'] ); ?></strong>
				</div>
			</header>

			<?php /* ---------------- جدول نمرات ---------------- */ ?>
			<section class="psyq-report__section">
				<h3 class="psyq-report__h3"><?php esc_html_e( 'نمرات زیرمقیاس‌ها', 'psyq' ); ?></h3>
				<div class="psyq-table-wrap">
					<table class="psyq-table">
						<thead>
							<tr>
								<th><?php esc_html_e( 'زیرمقیاس', 'psyq' ); ?></th>
								<th><?php esc_html_e( 'نمره', 'psyq' ); ?></th>
								<th><?php esc_html_e( 'بازه ممکن', 'psyq' ); ?></th>
								<th><?php esc_html_e( 'درصد', 'psyq' ); ?></th>
								<th><?php esc_html_e( 'سطح / تفسیر', 'psyq' ); ?></th>
							</tr>
						</thead>
						<tbody>
						<?php foreach ( $subs as $s ) : ?>
							<tr>
								<td>
									<span class="psyq-dot" style="background:<?php echo esc_attr( $s['color'] ); ?>"></span>
									<?php echo esc_html( $s['title'] ); ?>
								</td>
								<td><strong><?php echo esc_html( self::fmt( $s['score'] ) ); ?></strong></td>
								<td class="psyq-muted"><?php echo esc_html( self::fmt( $s['min'] ) . ' – ' . self::fmt( $s['max'] ) ); ?></td>
								<td><?php echo esc_html( $s['percent'] ); ?>%</td>
								<td>
									<?php if ( ! empty( $s['band'] ) ) : ?>
										<span class="psyq-pill" style="background:<?php echo esc_attr( $s['band']['color'] ); ?>1a;color:<?php echo esc_attr( $s['band']['color'] ); ?>;border-color:<?php echo esc_attr( $s['band']['color'] ); ?>55">
											<?php echo esc_html( $s['band']['label'] ); ?>
										</span>
									<?php else : ?>
										<span class="psyq-muted">—</span>
									<?php endif; ?>
								</td>
							</tr>
						<?php endforeach; ?>
						<?php if ( $total ) : ?>
							<tr class="psyq-tr-total">
								<td><strong><?php echo esc_html( $total['title'] ); ?></strong></td>
								<td><strong><?php echo esc_html( self::fmt( $total['score'] ) ); ?></strong></td>
								<td class="psyq-muted"><?php echo esc_html( self::fmt( $total['min'] ) . ' – ' . self::fmt( $total['max'] ) ); ?></td>
								<td><?php echo esc_html( $total['percent'] ); ?>%</td>
								<td>
									<?php if ( ! empty( $total['band'] ) ) : ?>
										<span class="psyq-pill" style="background:<?php echo esc_attr( $total['band']['color'] ); ?>1a;color:<?php echo esc_attr( $total['band']['color'] ); ?>;border-color:<?php echo esc_attr( $total['band']['color'] ); ?>55">
											<?php echo esc_html( $total['band']['label'] ); ?>
										</span>
									<?php else : ?>
										<span class="psyq-muted">—</span>
									<?php endif; ?>
								</td>
							</tr>
						<?php endif; ?>
						</tbody>
					</table>
				</div>
			</section>

			<?php if ( $show_charts ) : ?>
			<section class="psyq-report__section">
				<h3 class="psyq-report__h3"><?php esc_html_e( 'نمودار میله‌ای زیرمقیاس‌ها', 'psyq' ); ?></h3>
				<div class="psyq-chart" data-engine="<?php echo esc_attr( $engine ); ?>">
					<div class="psyq-chart__svg">
						<?php echo PsyQ_Charts::bar_svg( $subs, $total ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					</div>
					<?php if ( 'svg' !== $engine ) : ?>
						<div class="psyq-chart__live"><canvas id="psyqBar<?php echo esc_attr( wp_rand( 1000, 9999 ) ); ?>" data-chart='<?php echo esc_attr( wp_json_encode( PsyQ_Charts::bar_data( $subs, $total, $form ) ) ); ?>'></canvas></div>
						<button type="button" class="psyq-chart-toggle"><?php esc_html_e( 'نمای تعاملی / نسخه چاپی', 'psyq' ); ?></button>
					<?php endif; ?>
				</div>
			</section>

			<section class="psyq-report__section">
				<h3 class="psyq-report__h3"><?php esc_html_e( 'هیستوگرام توزیع پاسخ‌ها', 'psyq' ); ?></h3>
				<p class="psyq-muted psyq-small"><?php esc_html_e( 'این نمودار نشان می‌دهد پاسخ‌های شما در طیف امتیازهای گزینه‌ها چگونه توزیع شده‌اند.', 'psyq' ); ?></p>
				<div class="psyq-chart" data-engine="<?php echo esc_attr( $engine ); ?>">
					<div class="psyq-chart__svg">
						<?php echo PsyQ_Charts::histogram_svg( $scores ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					</div>
					<?php if ( 'svg' !== $engine ) : ?>
						<div class="psyq-chart__live"><canvas data-chart='<?php echo esc_attr( wp_json_encode( PsyQ_Charts::histogram_data( $scores ) ) ); ?>'></canvas></div>
						<button type="button" class="psyq-chart-toggle"><?php esc_html_e( 'نمای تعاملی / نسخه چاپی', 'psyq' ); ?></button>
					<?php endif; ?>
				</div>
			</section>
			<?php endif; ?>

			<?php /* ---------------- تفسیر تفصیلی ---------------- */ ?>
			<section class="psyq-report__section">
				<h3 class="psyq-report__h3"><?php esc_html_e( 'تفسیر تفصیلی', 'psyq' ); ?></h3>
				<div class="psyq-interps">
					<?php foreach ( $subs as $s ) : ?>
						<article class="psyq-interp" style="border-inline-start-color:<?php echo esc_attr( $s['color'] ); ?>">
							<header>
								<h4><?php echo esc_html( $s['title'] ); ?></h4>
								<div class="psyq-interp__scores">
									<span><?php echo esc_html( self::fmt( $s['score'] ) ); ?> <?php esc_html_e( 'از', 'psyq' ); ?> <?php echo esc_html( self::fmt( $s['max'] ) ); ?></span>
									<?php if ( ! empty( $s['band'] ) ) : ?>
										<span class="psyq-pill" style="background:<?php echo esc_attr( $s['band']['color'] ); ?>1a;color:<?php echo esc_attr( $s['band']['color'] ); ?>;border-color:<?php echo esc_attr( $s['band']['color'] ); ?>55"><?php echo esc_html( $s['band']['label'] ); ?></span>
									<?php endif; ?>
								</div>
							</header>
							<div class="psyq-interp__meter">
								<span style="width:<?php echo esc_attr( max( 0, min( 100, $s['percent'] ) ) ); ?>%;background:<?php echo esc_attr( $s['color'] ); ?>"></span>
							</div>
							<div class="psyq-interp__body">
								<?php
								$text = '';
								if ( ! empty( $s['band'] ) && ! empty( $s['band']['interpretation'] ) ) {
									$text = $s['band']['interpretation'];
								} elseif ( ! empty( $s['description'] ) ) {
									$text = $s['description'];
								}
								echo wp_kses_post( wpautop( self::replace_tokens( $text, $s, $scores ) ) );
								?>
							</div>
						</article>
					<?php endforeach; ?>

					<?php if ( $total ) : ?>
						<article class="psyq-interp psyq-interp--total">
							<header>
								<h4><?php echo esc_html( $total['title'] ); ?></h4>
								<div class="psyq-interp__scores">
									<span><?php echo esc_html( self::fmt( $total['score'] ) ); ?> <?php esc_html_e( 'از', 'psyq' ); ?> <?php echo esc_html( self::fmt( $total['max'] ) ); ?></span>
									<?php if ( ! empty( $total['band'] ) ) : ?>
										<span class="psyq-pill" style="background:<?php echo esc_attr( $total['band']['color'] ); ?>1a;color:<?php echo esc_attr( $total['band']['color'] ); ?>;border-color:<?php echo esc_attr( $total['band']['color'] ); ?>55"><?php echo esc_html( $total['band']['label'] ); ?></span>
									<?php endif; ?>
								</div>
							</header>
							<div class="psyq-interp__body">
								<?php echo wp_kses_post( wpautop( self::replace_tokens( ! empty( $total['band'] ) ? $total['band']['interpretation'] : '', $total, $scores ) ) ); ?>
							</div>
						</article>
					<?php endif; ?>
				</div>
			</section>

			<?php if ( $form && $form->report_footer_html ) : ?>
				<section class="psyq-report__section psyq-report__footer">
					<?php echo wp_kses_post( $form->report_footer_html ); ?>
				</section>
			<?php endif; ?>

			<?php if ( ! empty( $args['answers_table'] ) ) : ?>
				<section class="psyq-report__section">
					<h3 class="psyq-report__h3"><?php esc_html_e( 'پاسخ‌های ثبت‌شده', 'psyq' ); ?></h3>
					<div class="psyq-table-wrap">
						<table class="psyq-table psyq-table--answers">
							<thead><tr><th>#</th><th><?php esc_html_e( 'سوال', 'psyq' ); ?></th><th><?php esc_html_e( 'پاسخ', 'psyq' ); ?></th><th><?php esc_html_e( 'امتیاز', 'psyq' ); ?></th></tr></thead>
							<tbody>
							<?php foreach ( $scores['items'] as $d ) : ?>
								<?php
								$item_text = '';
								foreach ( $bundle['items'] as $bi ) {
									if ( $bi['id'] === $d['item_id'] ) {
										$item_text = $bi['text'];
										break;
									}
								}
								?>
								<tr>
									<td><?php echo esc_html( $d['number'] ); ?></td>
									<td class="psyq-td-text"><?php echo esc_html( wp_trim_words( wp_strip_all_tags( $item_text ), 30 ) ); ?></td>
									<td><?php echo $d['skipped'] ? '<em class="psyq-muted">' . esc_html__( 'نمایش داده نشد', 'psyq' ) . '</em>' : esc_html( $d['label'] ); ?></td>
									<td><?php echo ( null === $d['earned'] ) ? '—' : esc_html( self::fmt( $d['earned'] ) ); ?><?php echo ! empty( $d['reversed'] ) ? ' <span class="psyq-muted">(معکوس)</span>' : ''; ?></td>
								</tr>
							<?php endforeach; ?>
							</tbody>
						</table>
					</div>
				</section>
			<?php endif; ?>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * جایگذاری متغیرها در متن تفسیر:
	 * {score} {max} {min} {percent} {name} - و نام سایر زیرمقیاس‌ها با {نام_زیرمقیاس}.
	 */
	public static function replace_tokens( $text, $s, $scores ) {
		if ( '' === trim( (string) $text ) ) {
			return '';
		}
		$map = array(
			'{score}'   => self::fmt( $s['score'] ),
			'{max}'     => self::fmt( $s['max'] ),
			'{min}'     => self::fmt( $s['min'] ),
			'{percent}' => $s['percent'] . '%',
			'{name}'    => $s['title'],
			'{level}'   => ! empty( $s['band'] ) ? $s['band']['label'] : '',
		);
		$out = str_replace( array_keys( $map ), array_values( $map ), (string) $text );

		// {نام زیرمقیاس} برای ارجاع متقابل.
		foreach ( $scores['subscales'] as $other ) {
			$out = str_replace( '{' . $other['name'] . '}', self::fmt( $other['score'] ), $out );
		}
		return $out;
	}

	/**
	 * قالب‌بندی عدد (حذف صفرهای اضافی).
	 */
	public static function fmt( $n ) {
		$n = (float) $n;
		if ( floor( $n ) === $n ) {
			return (string) (int) $n;
		}
		return rtrim( rtrim( number_format( $n, 2, '.', '' ), '0' ), '.' );
	}

	/**
	 * بازه‌های پیش‌فرض بر اساس بیشینه یک زیرمقیاس.
	 *
	 * @param float $max بیشینه.
	 * @param int   $count تعداد بازه.
	 * @return array
	 */
	public static function suggest_bands( $max, $count = 4 ) {
		$max   = (float) $max;
		$count = max( 2, min( 6, (int) $count ) );
		$labels = array(
			__( 'طبیعی', 'psyq' ),
			__( 'خفیف', 'psyq' ),
			__( 'متوسط', 'psyq' ),
			__( 'شدید', 'psyq' ),
			__( 'بسیار شدید', 'psyq' ),
			__( 'بحرانی', 'psyq' ),
		);
		$colors = array( '#16a34a', '#84cc16', '#f59e0b', '#f97316', '#ef4444', '#991b1b' );
		$out    = array();
		$step   = $max > 0 ? $max / $count : 1;
		for ( $i = 0; $i < $count; $i++ ) {
			$min = round( $i * $step, 2 );
			$top = ( $i === $count - 1 ) ? $max : round( ( $i + 1 ) * $step, 2 );
			$out[] = array(
				'min'   => $min,
				'max'   => $top,
				'label' => isset( $labels[ $i ] ) ? $labels[ $i ] : ( $i + 1 ),
				'color' => isset( $colors[ $i ] ) ? $colors[ $i ] : '#64748b',
			);
		}
		return $out;
	}
}
