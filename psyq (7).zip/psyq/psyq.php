<?php
/**
 * Plugin Name:       PsyQ — سازنده و مفسر پرسشنامه‌های روان‌شناسی
 * Plugin URI:        https://example.com/psyq
 * Description:       ساخت پرسشنامه با هر تعداد گزینه (۲ تا ۷ و بیشتر)، امتیازدهی مجزا برای هر گزینه (‑۵ تا ۷)، تصویر برای سوال و گزینه، زیرمقیاس‌ها، ۱ تا ۳ نقطه برش با تفسیر مستقل، ورود/خروج اکسل و گزارش تفسیری با نمودار میله‌ای و هیستوگرام.
 * Version:           1.1.3
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            PsyQ
 * Text Domain:       psyq
 * Domain Path:       /languages
 * License:           GPL-2.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'PSYQ_VERSION', '1.1.3' );
define( 'PSYQ_FILE', __FILE__ );
define( 'PSYQ_DIR', plugin_dir_path( __FILE__ ) );
define( 'PSYQ_URL', plugin_dir_url( __FILE__ ) );
define( 'PSYQ_DB_VERSION', '1.1.1' );

require_once PSYQ_DIR . 'includes/class-psyq-db.php';
require_once PSYQ_DIR . 'includes/class-psyq-xlsx-reader.php';
require_once PSYQ_DIR . 'includes/class-psyq-xlsx-writer.php';
require_once PSYQ_DIR . 'includes/class-psyq-scoring.php';
require_once PSYQ_DIR . 'includes/class-psyq-excel.php';
require_once PSYQ_DIR . 'includes/class-psyq-charts.php';
require_once PSYQ_DIR . 'includes/class-psyq-admin.php';
require_once PSYQ_DIR . 'includes/class-psyq-frontend.php';
require_once PSYQ_DIR . 'includes/class-psyq-ajax.php';

/**
 * راه‌اندازی افزونه.
 */
function psyq_boot() {
	load_plugin_textdomain( 'psyq', false, dirname( plugin_basename( PSYQ_FILE ) ) . '/languages' );

	PsyQ_DB::maybe_upgrade();

	PsyQ_Admin::init();
	PsyQ_Frontend::init();
	PsyQ_Ajax::init();
}
add_action( 'plugins_loaded', 'psyq_boot' );

/**
 * فعال‌سازی: ساخت جدول‌ها و پیش‌فرض‌ها.
 */
function psyq_activate() {
	PsyQ_DB::install();
	update_option( 'psyq_db_version', PSYQ_DB_VERSION, false );
}
register_activation_hook( __FILE__, 'psyq_activate' );

/**
 * غیرفعال‌سازی (داده‌ها پاک نمی‌شوند).
 */
function psyq_deactivate() {
	flush_rewrite_rules();
}
register_deactivation_hook( __FILE__, 'psyq_deactivate' );

/**
 * لینک تنظیمات در فهرست افزونه‌ها.
 */
function psyq_action_links( $links ) {
	$links[] = '<a href="' . esc_url( admin_url( 'admin.php?page=psyq' ) ) . '">' . esc_html__( 'پیشخوان', 'psyq' ) . '</a>';
	$links[] = '<a href="' . esc_url( admin_url( 'admin.php?page=psyq-settings' ) ) . '">' . esc_html__( 'تنظیمات', 'psyq' ) . '</a>';
	return $links;
}
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'psyq_action_links' );

/**
 * بارگذاری فایل ترجمه اعداد فارسی/عربی به لاتین (کمکی).
 *
 * @param string $s ورودی.
 * @return string
 */
function psyq_normalize_digits( $s ) {
	$fa = array( '۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹', '٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩', '٫' );
	$en = array( '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '.' );
	return str_replace( $fa, $en, (string) $s );
}
